import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ContactMapSection.tsx");const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=383ccf5c";
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=d79d3615";
import { MapPin, Phone, Mail, Clock, Send, CheckCircle2, MessageCircle, Building } from "/node_modules/.vite/deps/lucide-react.js?v=a18529f7";
import { useTheme } from "/src/context/ThemeContext.tsx";
var _jsxFileName = "D:/Aravind-Works/Dentel clinic/src/components/ContactMapSection.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=383ccf5c";
var _s = $RefreshSig$();
export const ContactMapSection = () => {
	_s();
	const { config } = useTheme();
	const [selectedBranchIndex, setSelectedBranchIndex] = useState(0);
	const [formSubmitted, setFormSubmitted] = useState(false);
	const [formData, setFormData] = useState({
		name: "",
		phone: "",
		email: "",
		treatment: "General Consultation",
		message: ""
	});
	const currentBranch = config.contact.branches[selectedBranchIndex] || config.contact.branches[0];
	const handleSubmit = (e) => {
		e.preventDefault();
		setFormSubmitted(true);
		setTimeout(() => {
			setFormSubmitted(false);
			setFormData({
				name: "",
				phone: "",
				email: "",
				treatment: "General Consultation",
				message: ""
			});
		}, 4e3);
	};
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "contact",
		className: "py-20 bg-slate-100/70 dark:bg-slate-900/50 relative",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "text-center max-w-3xl mx-auto space-y-3",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-100 dark:bg-sky-950/80 text-sky-800 dark:text-sky-300 text-xs font-bold uppercase tracking-wider",
							children: [/* @__PURE__ */ _jsxDEV(MapPin, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 45,
								columnNumber: 13
							}, this), "Studio Locations & Direct Contact"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 44,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight",
							children: ["Visit Our Modern ", /* @__PURE__ */ _jsxDEV("span", {
								className: "text-gradient",
								children: "Dental Studios"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 49,
								columnNumber: 30
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-slate-600 dark:text-slate-300 text-sm sm:text-base",
							children: "Located conveniently in healthcare hubs with full valet parking and accessible ramp access."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-8 flex justify-center gap-3",
					children: config.contact.branches.map((b, idx) => /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setSelectedBranchIndex(idx),
						className: `px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition cursor-pointer ${selectedBranchIndex === idx ? "bg-sky-500 text-white shadow-md" : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700"}`,
						children: [/* @__PURE__ */ _jsxDEV(Building, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: b.name }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 15
						}, this)]
					}, idx, true, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "lg:col-span-6 space-y-6",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "glass-card rounded-3xl p-6 border border-slate-200/90 dark:border-slate-800 space-y-4",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-lg font-bold text-slate-900 dark:text-white",
									children: currentBranch.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 83,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "inline-flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950 px-2.5 py-0.5 rounded-full border border-emerald-200 dark:border-emerald-800",
									children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-emerald-500 animate-pulse" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 87,
										columnNumber: 19
									}, this), "Open Today"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 86,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 82,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-3 text-xs sm:text-sm text-slate-600 dark:text-slate-300",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start gap-3",
										children: [/* @__PURE__ */ _jsxDEV(MapPin, { className: "w-4 h-4 text-sky-500 flex-shrink-0 mt-1" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 94,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: currentBranch.address }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 95,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 93,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ _jsxDEV(Phone, { className: "w-4 h-4 text-sky-500 flex-shrink-0" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 99,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("a", {
											href: `tel:${currentBranch.phone}`,
											className: "font-bold hover:underline text-slate-900 dark:text-white",
											children: currentBranch.phone
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 100,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 98,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ _jsxDEV(Mail, { className: "w-4 h-4 text-sky-500 flex-shrink-0" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 106,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: config.contact.email }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 107,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 105,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start gap-3 pt-2 border-t border-slate-100 dark:border-slate-800",
										children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-4 h-4 text-teal-500 flex-shrink-0 mt-0.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 111,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "font-semibold text-slate-800 dark:text-slate-200",
												children: "Working Hours:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 113,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-xs text-slate-500 dark:text-slate-400",
												children: config.contact.workingHours.weekdays
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 114,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-xs text-slate-500 dark:text-slate-400",
												children: config.contact.workingHours.sunday
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 115,
												columnNumber: 21
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 112,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 110,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 92,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "rounded-3xl overflow-hidden border border-slate-200 dark:border-slate-700 shadow-md h-64 sm:h-72 relative",
							children: /* @__PURE__ */ _jsxDEV("iframe", {
								title: "Branch Location Map",
								src: currentBranch.mapEmbedUrl,
								width: "100%",
								height: "100%",
								style: { border: 0 },
								allowFullScreen: false,
								loading: "lazy",
								referrerPolicy: "no-referrer-when-downgrade"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 123,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 122,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "lg:col-span-6",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "glass-card rounded-3xl p-6 sm:p-8 border border-slate-200/90 dark:border-slate-800 shadow-xl",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-2 mb-6",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xl font-bold text-slate-900 dark:text-white",
									children: "Send A Direct Message / Inquiry"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 141,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-500 dark:text-slate-400",
									children: "Fill in your details below and our patient care team will respond within 15 minutes."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 144,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 140,
								columnNumber: 15
							}, this), formSubmitted ? /* @__PURE__ */ _jsxDEV("div", {
								className: "p-6 rounded-2xl bg-emerald-50 dark:bg-emerald-950/80 border border-emerald-300 dark:border-emerald-800 text-center space-y-3",
								children: [
									/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-10 h-10 text-emerald-500 mx-auto" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 151,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("h4", {
										className: "text-base font-bold text-emerald-900 dark:text-emerald-200",
										children: "Inquiry Received Successfully!"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 152,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-emerald-700 dark:text-emerald-300",
										children: [
											"Thank you! Our dental coordinator will call you back at ",
											formData.phone,
											" shortly."
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 155,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 150,
								columnNumber: 17
							}, this) : /* @__PURE__ */ _jsxDEV("form", {
								onSubmit: handleSubmit,
								className: "space-y-4",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1",
											children: "Your Full Name *"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 163,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											required: true,
											placeholder: "e.g. Meera Nair",
											value: formData.name,
											onChange: (e) => setFormData({
												...formData,
												name: e.target.value
											}),
											className: "w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-sky-500 outline-none"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 166,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 162,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1",
											children: "Phone Number *"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 177,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "tel",
											required: true,
											placeholder: "+91 98765 43210",
											value: formData.phone,
											onChange: (e) => setFormData({
												...formData,
												phone: e.target.value
											}),
											className: "w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-sky-500 outline-none"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 180,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 176,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 161,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1",
											children: "Email Address"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 193,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("input", {
											type: "email",
											placeholder: "meera@example.com",
											value: formData.email,
											onChange: (e) => setFormData({
												...formData,
												email: e.target.value
											}),
											className: "w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-sky-500 outline-none"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 196,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 192,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1",
											children: "Treatment Interest"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 206,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("select", {
											value: formData.treatment,
											onChange: (e) => setFormData({
												...formData,
												treatment: e.target.value
											}),
											className: "w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-sky-500 outline-none",
											children: [
												/* @__PURE__ */ _jsxDEV("option", {
													value: "General Consultation",
													children: "General Consultation"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 214,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Dental Implants",
													children: "Dental Implants"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 215,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Invisalign Aligners",
													children: "Invisalign Aligners"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 216,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Hollywood Smile Veneers",
													children: "Hollywood Smile Veneers"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 217,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Single Visit RCT",
													children: "Single Visit RCT"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 218,
													columnNumber: 25
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "Emergency Toothache",
													children: "Emergency Toothache"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 219,
													columnNumber: 25
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 209,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 205,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 191,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
										className: "block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1",
										children: "Message / Specific Concern"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 225,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("textarea", {
										rows: 3,
										placeholder: "Please let us know if you are experiencing tooth pain, sensitivity, or wish to book a consultation date...",
										value: formData.message,
										onChange: (e) => setFormData({
											...formData,
											message: e.target.value
										}),
										className: "w-full p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-900 dark:text-white focus:ring-2 focus:ring-sky-500 outline-none"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 228,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 224,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "submit",
										className: "w-full py-3.5 rounded-xl font-bold text-white bg-gradient-to-r from-sky-500 to-teal-500 hover:from-sky-600 hover:to-teal-600 shadow-md flex items-center justify-center gap-2 text-xs cursor-pointer",
										children: [/* @__PURE__ */ _jsxDEV(Send, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 241,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Submit Inquiry" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 242,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 237,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 160,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 138,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 75,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 39,
		columnNumber: 5
	}, this);
};
_s(ContactMapSection, "RgeREiXJXlXOoW3w8BS0OBEHINw=", false, function() {
	return [useTheme];
});
_c = ContactMapSection;
var _c;
$RefreshReg$(_c, "ContactMapSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ContactMapSection.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Aravind-Works/Dentel clinic/src/components/ContactMapSection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Aravind-Works/Dentel clinic/src/components/ContactMapSection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Aravind-Works/Dentel clinic/src/components/ContactMapSection.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLGNBQWM7QUFDdkIsU0FDRSxRQUNBLE9BQ0EsTUFDQSxPQUNBLE1BQ0EsY0FDQSxlQUNBLGdCQUNLO0FBQ1AsU0FBUyxnQkFBZ0I7Ozs7QUFFekIsT0FBTyxNQUFNLDBCQUFvQzs7Q0FDL0MsTUFBTSxFQUFFLFdBQVcsU0FBUztDQUM1QixNQUFNLENBQUMscUJBQXFCLDBCQUEwQixTQUFTLENBQUM7Q0FDaEUsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQVMsS0FBSztDQUN4RCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQVM7RUFDdkMsTUFBTTtFQUNOLE9BQU87RUFDUCxPQUFPO0VBQ1AsV0FBVztFQUNYLFNBQVM7Q0FDWCxDQUFDO0NBRUQsTUFBTSxnQkFBZ0IsT0FBTyxRQUFRLFNBQVMsd0JBQXdCLE9BQU8sUUFBUSxTQUFTO0NBRTlGLE1BQU0sZ0JBQWdCLE1BQXVCO0VBQzNDLEVBQUUsZUFBZTtFQUNqQixpQkFBaUIsSUFBSTtFQUNyQixpQkFBaUI7R0FDZixpQkFBaUIsS0FBSztHQUN0QixZQUFZO0lBQUUsTUFBTTtJQUFJLE9BQU87SUFBSSxPQUFPO0lBQUksV0FBVztJQUF3QixTQUFTO0dBQUcsQ0FBQztFQUNoRyxHQUFHLEdBQUk7Q0FDVDtDQUVBLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLElBQUc7RUFBVSxXQUFVO1lBQzlCLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFHRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFELEVBQVEsV0FBVSxjQUFlOzs7O2lCQUFDLG1DQUUvQjs7Ozs7O01BQ0wsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FBa0cscUJBQy9FLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFnQjtPQUFvQjs7OztlQUNuRTs7Ozs7O01BQ0osd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQTBEO01BRXBFOzs7OztLQUNBOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLE9BQU8sUUFBUSxTQUFTLEtBQUssR0FBRyxRQUMvQix3QkFBQyxVQUFEO01BRUUsZUFBZSx1QkFBdUIsR0FBRztNQUN6QyxXQUFXLHlHQUNULHdCQUF3QixNQUNwQixvQ0FDQTtnQkFOUixDQVNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFVBQVc7Ozs7Z0JBQy9CLHdCQUFDLFFBQUQsWUFBTyxFQUFFLEtBQVc7Ozs7Y0FDZDtRQVZEOzs7O1lBVUMsQ0FDVDtJQUNFOzs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FHRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUdFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDWCxjQUFjO1FBQ2I7Ozs7a0JBQ0osd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsb0RBQTBEOzs7O21CQUFDLFlBRXZFOzs7OztnQkFDSDs7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQsRUFBUSxXQUFVLDBDQUEyQzs7OztvQkFDN0Qsd0JBQUMsUUFBRCxZQUFPLGNBQWMsUUFBYzs7OztrQkFDaEM7Ozs7OztTQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUscUNBQXNDOzs7O29CQUN2RCx3QkFBQyxLQUFEO1dBQUcsTUFBTSxPQUFPLGNBQWM7V0FBUyxXQUFVO3FCQUM5QyxjQUFjO1VBQ2Q7Ozs7a0JBQ0E7Ozs7OztTQUVMLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUscUNBQXNDOzs7O29CQUN0RCx3QkFBQyxRQUFELFlBQU8sT0FBTyxRQUFRLE1BQVk7Ozs7a0JBQy9COzs7Ozs7U0FFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLDZDQUE4Qzs7OztvQkFDL0Qsd0JBQUMsT0FBRDtXQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFtRDtXQUFtQjs7Ozs7V0FDckYsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQThDLE9BQU8sUUFBUSxhQUFhO1dBQWM7Ozs7O1dBQ3ZHLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUE4QyxPQUFPLFFBQVEsYUFBYTtXQUFZOzs7OztVQUNsRzs7OztrQkFDRjs7Ozs7O1FBQ0Y7Ozs7O2VBQ0Y7Ozs7O2dCQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLFVBQUQ7UUFDRSxPQUFNO1FBQ04sS0FBSyxjQUFjO1FBQ25CLE9BQU07UUFDTixRQUFPO1FBQ1AsT0FBTyxFQUFFLFFBQVEsRUFBRTtRQUNuQixpQkFBaUI7UUFDakIsU0FBUTtRQUNSLGdCQUFlO09BQ2hCOzs7OztNQUNFOzs7O2NBRUY7Ozs7O2VBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUFtRDtRQUU3RDs7OztrQkFDSix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBNkM7UUFFdkQ7Ozs7Z0JBQ0E7Ozs7O2lCQUVKLGdCQUNDLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsY0FBRCxFQUFjLFdBQVUscUNBQXNDOzs7OztTQUM5RCx3QkFBQyxNQUFEO1VBQUksV0FBVTtvQkFBNkQ7U0FFdkU7Ozs7O1NBQ0osd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWI7V0FBOEQ7V0FDSCxTQUFTO1dBQU07VUFDdkU7Ozs7OztRQUNBOzs7OztrQkFFTCx3QkFBQyxRQUFEO1FBQU0sVUFBVTtRQUFjLFdBQVU7a0JBQXhDO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQWtFO1VBRTVFOzs7O29CQUNQLHdCQUFDLFNBQUQ7V0FDRSxNQUFLO1dBQ0w7V0FDQSxhQUFZO1dBQ1osT0FBTyxTQUFTO1dBQ2hCLFdBQVcsTUFBTSxZQUFZO1lBQUUsR0FBRztZQUFVLE1BQU0sRUFBRSxPQUFPO1dBQU0sQ0FBQztXQUNsRSxXQUFVO1VBQ1g7Ozs7a0JBQ0U7Ozs7b0JBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUFrRTtVQUU1RTs7OztvQkFDUCx3QkFBQyxTQUFEO1dBQ0UsTUFBSztXQUNMO1dBQ0EsYUFBWTtXQUNaLE9BQU8sU0FBUztXQUNoQixXQUFXLE1BQU0sWUFBWTtZQUFFLEdBQUc7WUFBVSxPQUFPLEVBQUUsT0FBTztXQUFNLENBQUM7V0FDbkUsV0FBVTtVQUNYOzs7O2tCQUNFOzs7O2tCQUNGOzs7Ozs7U0FFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBa0U7VUFFNUU7Ozs7b0JBQ1Asd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxhQUFZO1dBQ1osT0FBTyxTQUFTO1dBQ2hCLFdBQVcsTUFBTSxZQUFZO1lBQUUsR0FBRztZQUFVLE9BQU8sRUFBRSxPQUFPO1dBQU0sQ0FBQztXQUNuRSxXQUFVO1VBQ1g7Ozs7a0JBQ0U7Ozs7b0JBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUFrRTtVQUU1RTs7OztvQkFDUCx3QkFBQyxVQUFEO1dBQ0UsT0FBTyxTQUFTO1dBQ2hCLFdBQVcsTUFBTSxZQUFZO1lBQUUsR0FBRztZQUFVLFdBQVcsRUFBRSxPQUFPO1dBQU0sQ0FBQztXQUN2RSxXQUFVO3FCQUhaO1lBS0Usd0JBQUMsVUFBRDthQUFRLE9BQU07dUJBQXVCO1lBQTRCOzs7OztZQUNqRSx3QkFBQyxVQUFEO2FBQVEsT0FBTTt1QkFBa0I7WUFBdUI7Ozs7O1lBQ3ZELHdCQUFDLFVBQUQ7YUFBUSxPQUFNO3VCQUFzQjtZQUEyQjs7Ozs7WUFDL0Qsd0JBQUMsVUFBRDthQUFRLE9BQU07dUJBQTBCO1lBQStCOzs7OztZQUN2RSx3QkFBQyxVQUFEO2FBQVEsT0FBTTt1QkFBbUI7WUFBd0I7Ozs7O1lBQ3pELHdCQUFDLFVBQUQ7YUFBUSxPQUFNO3VCQUFzQjtZQUEyQjs7Ozs7V0FDekQ7Ozs7O2tCQUNMOzs7O2tCQUNGOzs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQWtFO1NBRTVFOzs7O21CQUNQLHdCQUFDLFlBQUQ7VUFDRSxNQUFNO1VBQ04sYUFBWTtVQUNaLE9BQU8sU0FBUztVQUNoQixXQUFXLE1BQU0sWUFBWTtXQUFFLEdBQUc7V0FBVSxTQUFTLEVBQUUsT0FBTztVQUFNLENBQUM7VUFDckUsV0FBVTtTQUNEOzs7O2lCQUNSOzs7OztTQUVMLHdCQUFDLFVBQUQ7VUFDRSxNQUFLO1VBQ0wsV0FBVTtvQkFGWixDQUlFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7b0JBQzNCLHdCQUFDLFFBQUQsWUFBTSxpQkFBb0I7Ozs7a0JBQ3BCOzs7Ozs7UUFDSjs7Ozs7ZUFFTDs7Ozs7O0tBQ0Y7Ozs7YUFFRjs7Ozs7O0dBRUY7Ozs7OztDQUNFOzs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNvbnRhY3RNYXBTZWN0aW9uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBtb3Rpb24gfSBmcm9tICdmcmFtZXItbW90aW9uJztcbmltcG9ydCB7IFxuICBNYXBQaW4sIFxuICBQaG9uZSwgXG4gIE1haWwsIFxuICBDbG9jaywgXG4gIFNlbmQsIFxuICBDaGVja0NpcmNsZTIsIFxuICBNZXNzYWdlQ2lyY2xlLFxuICBCdWlsZGluZ1xufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICdAL2NvbnRleHQvVGhlbWVDb250ZXh0JztcblxuZXhwb3J0IGNvbnN0IENvbnRhY3RNYXBTZWN0aW9uOiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgY29uc3QgeyBjb25maWcgfSA9IHVzZVRoZW1lKCk7XG4gIGNvbnN0IFtzZWxlY3RlZEJyYW5jaEluZGV4LCBzZXRTZWxlY3RlZEJyYW5jaEluZGV4XSA9IHVzZVN0YXRlKDApO1xuICBjb25zdCBbZm9ybVN1Ym1pdHRlZCwgc2V0Rm9ybVN1Ym1pdHRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gIGNvbnN0IFtmb3JtRGF0YSwgc2V0Rm9ybURhdGFdID0gdXNlU3RhdGUoe1xuICAgIG5hbWU6ICcnLFxuICAgIHBob25lOiAnJyxcbiAgICBlbWFpbDogJycsXG4gICAgdHJlYXRtZW50OiAnR2VuZXJhbCBDb25zdWx0YXRpb24nLFxuICAgIG1lc3NhZ2U6ICcnXG4gIH0pO1xuXG4gIGNvbnN0IGN1cnJlbnRCcmFuY2ggPSBjb25maWcuY29udGFjdC5icmFuY2hlc1tzZWxlY3RlZEJyYW5jaEluZGV4XSB8fCBjb25maWcuY29udGFjdC5icmFuY2hlc1swXTtcblxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIHNldEZvcm1TdWJtaXR0ZWQodHJ1ZSk7XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBzZXRGb3JtU3VibWl0dGVkKGZhbHNlKTtcbiAgICAgIHNldEZvcm1EYXRhKHsgbmFtZTogJycsIHBob25lOiAnJywgZW1haWw6ICcnLCB0cmVhdG1lbnQ6ICdHZW5lcmFsIENvbnN1bHRhdGlvbicsIG1lc3NhZ2U6ICcnIH0pO1xuICAgIH0sIDQwMDApO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gaWQ9XCJjb250YWN0XCIgY2xhc3NOYW1lPVwicHktMjAgYmctc2xhdGUtMTAwLzcwIGRhcms6Ymctc2xhdGUtOTAwLzUwIHJlbGF0aXZlXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTd4bCBteC1hdXRvIHB4LTQgc206cHgtNiBsZzpweC04XCI+XG4gICAgICAgIFxuICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIG1heC13LTN4bCBteC1hdXRvIHNwYWNlLXktM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgYmctc2t5LTEwMCBkYXJrOmJnLXNreS05NTAvODAgdGV4dC1za3ktODAwIGRhcms6dGV4dC1za3ktMzAwIHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgPE1hcFBpbiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICBTdHVkaW8gTG9jYXRpb25zICYgRGlyZWN0IENvbnRhY3RcbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0zeGwgc206dGV4dC00eGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICBWaXNpdCBPdXIgTW9kZXJuIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JhZGllbnRcIj5EZW50YWwgU3R1ZGlvczwvc3Bhbj5cbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgdGV4dC1zbSBzbTp0ZXh0LWJhc2VcIj5cbiAgICAgICAgICAgIExvY2F0ZWQgY29udmVuaWVudGx5IGluIGhlYWx0aGNhcmUgaHVicyB3aXRoIGZ1bGwgdmFsZXQgcGFya2luZyBhbmQgYWNjZXNzaWJsZSByYW1wIGFjY2Vzcy5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBCcmFuY2ggU2VsZWN0b3IgVGFicyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IGZsZXgganVzdGlmeS1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICB7Y29uZmlnLmNvbnRhY3QuYnJhbmNoZXMubWFwKChiLCBpZHgpID0+IChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAga2V5PXtpZHh9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkQnJhbmNoSW5kZXgoaWR4KX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yLjUgcm91bmRlZC14bCB0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICBzZWxlY3RlZEJyYW5jaEluZGV4ID09PSBpZHhcbiAgICAgICAgICAgICAgICAgID8gJ2JnLXNreS01MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQnXG4gICAgICAgICAgICAgICAgICA6ICdiZy13aGl0ZSBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCdcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxCdWlsZGluZyBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+e2IubmFtZX08L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIENvbnRhY3QgTGF5b3V0ICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwIGdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLTEyIGdhcC04IGl0ZW1zLXN0YXJ0XCI+XG4gICAgICAgICAgXG4gICAgICAgICAgey8qIExlZnQ6IEluZm8gJiBNYXAgQ29sdW1uICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNiBzcGFjZS15LTZcIj5cbiAgICAgICAgICAgIFxuICAgICAgICAgICAgey8qIEJyYW5jaCBEZXRhaWxzIENhcmQgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdsYXNzLWNhcmQgcm91bmRlZC0zeGwgcC02IGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzkwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICB7Y3VycmVudEJyYW5jaC5uYW1lfVxuICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xIHRleHQtWzExcHhdIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCBiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAgcHgtMi41IHB5LTAuNSByb3VuZGVkLWZ1bGwgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTIwMCBkYXJrOmJvcmRlci1lbWVyYWxkLTgwMFwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC01MDAgYW5pbWF0ZS1wdWxzZVwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIE9wZW4gVG9kYXlcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zIHRleHQteHMgc206dGV4dC1zbSB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICA8TWFwUGluIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1za3ktNTAwIGZsZXgtc2hyaW5rLTAgbXQtMVwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj57Y3VycmVudEJyYW5jaC5hZGRyZXNzfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgIDxQaG9uZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2t5LTUwMCBmbGV4LXNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxhIGhyZWY9e2B0ZWw6JHtjdXJyZW50QnJhbmNoLnBob25lfWB9IGNsYXNzTmFtZT1cImZvbnQtYm9sZCBob3Zlcjp1bmRlcmxpbmUgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgIHtjdXJyZW50QnJhbmNoLnBob25lfVxuICAgICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgPE1haWwgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNreS01MDAgZmxleC1zaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj57Y29uZmlnLmNvbnRhY3QuZW1haWx9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zIHB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtdGVhbC01MDAgZmxleC1zaHJpbmstMCBtdC0wLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtODAwIGRhcms6dGV4dC1zbGF0ZS0yMDBcIj5Xb3JraW5nIEhvdXJzOjwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPntjb25maWcuY29udGFjdC53b3JraW5nSG91cnMud2Vla2RheXN9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+e2NvbmZpZy5jb250YWN0LndvcmtpbmdIb3Vycy5zdW5kYXl9PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEVtYmVkZGVkIEdvb2dsZSBNYXAgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtM3hsIG92ZXJmbG93LWhpZGRlbiBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgc2hhZG93LW1kIGgtNjQgc206aC03MiByZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICA8aWZyYW1lXG4gICAgICAgICAgICAgICAgdGl0bGU9XCJCcmFuY2ggTG9jYXRpb24gTWFwXCJcbiAgICAgICAgICAgICAgICBzcmM9e2N1cnJlbnRCcmFuY2gubWFwRW1iZWRVcmx9XG4gICAgICAgICAgICAgICAgd2lkdGg9XCIxMDAlXCJcbiAgICAgICAgICAgICAgICBoZWlnaHQ9XCIxMDAlXCJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBib3JkZXI6IDAgfX1cbiAgICAgICAgICAgICAgICBhbGxvd0Z1bGxTY3JlZW49e2ZhbHNlfVxuICAgICAgICAgICAgICAgIGxvYWRpbmc9XCJsYXp5XCJcbiAgICAgICAgICAgICAgICByZWZlcnJlclBvbGljeT1cIm5vLXJlZmVycmVyLXdoZW4tZG93bmdyYWRlXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogUmlnaHQ6IFF1aWNrIElucXVpcnkgRm9ybSAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTZcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ2xhc3MtY2FyZCByb3VuZGVkLTN4bCBwLTYgc206cC04IGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzkwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzaGFkb3cteGxcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgbWItNlwiPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgIFNlbmQgQSBEaXJlY3QgTWVzc2FnZSAvIElucXVpcnlcbiAgICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgRmlsbCBpbiB5b3VyIGRldGFpbHMgYmVsb3cgYW5kIG91ciBwYXRpZW50IGNhcmUgdGVhbSB3aWxsIHJlc3BvbmQgd2l0aGluIDE1IG1pbnV0ZXMuXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7Zm9ybVN1Ym1pdHRlZCA/IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiByb3VuZGVkLTJ4bCBiZy1lbWVyYWxkLTUwIGRhcms6YmctZW1lcmFsZC05NTAvODAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTMwMCBkYXJrOmJvcmRlci1lbWVyYWxkLTgwMCB0ZXh0LWNlbnRlciBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy0xMCBoLTEwIHRleHQtZW1lcmFsZC01MDAgbXgtYXV0b1wiIC8+XG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtOTAwIGRhcms6dGV4dC1lbWVyYWxkLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICBJbnF1aXJ5IFJlY2VpdmVkIFN1Y2Nlc3NmdWxseSFcbiAgICAgICAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtZW1lcmFsZC03MDAgZGFyazp0ZXh0LWVtZXJhbGQtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgIFRoYW5rIHlvdSEgT3VyIGRlbnRhbCBjb29yZGluYXRvciB3aWxsIGNhbGwgeW91IGJhY2sgYXQge2Zvcm1EYXRhLnBob25lfSBzaG9ydGx5LlxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgWW91ciBGdWxsIE5hbWUgKlxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIE1lZXJhIE5haXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm5hbWV9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEZvcm1EYXRhKHsgLi4uZm9ybURhdGEsIG5hbWU6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMyByb3VuZGVkLXhsIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXNreS01MDAgb3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFBob25lIE51bWJlciAqXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZWxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiKzkxIDk4NzY1IDQzMjEwXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5waG9uZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgcGhvbmU6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMyByb3VuZGVkLXhsIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXNreS01MDAgb3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICBFbWFpbCBBZGRyZXNzXG4gICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIm1lZXJhQGV4YW1wbGUuY29tXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtmb3JtRGF0YS5lbWFpbH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgZW1haWw6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMyByb3VuZGVkLXhsIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXNreS01MDAgb3V0bGluZS1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIFRyZWF0bWVudCBJbnRlcmVzdFxuICAgICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLnRyZWF0bWVudH1cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Rm9ybURhdGEoeyAuLi5mb3JtRGF0YSwgdHJlYXRtZW50OiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTMgcm91bmRlZC14bCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1za3ktNTAwIG91dGxpbmUtbm9uZVwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkdlbmVyYWwgQ29uc3VsdGF0aW9uXCI+R2VuZXJhbCBDb25zdWx0YXRpb248L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJEZW50YWwgSW1wbGFudHNcIj5EZW50YWwgSW1wbGFudHM8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJJbnZpc2FsaWduIEFsaWduZXJzXCI+SW52aXNhbGlnbiBBbGlnbmVyczwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkhvbGx5d29vZCBTbWlsZSBWZW5lZXJzXCI+SG9sbHl3b29kIFNtaWxlIFZlbmVlcnM8L29wdGlvbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJTaW5nbGUgVmlzaXQgUkNUXCI+U2luZ2xlIFZpc2l0IFJDVDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIkVtZXJnZW5jeSBUb290aGFjaGVcIj5FbWVyZ2VuY3kgVG9vdGhhY2hlPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICBNZXNzYWdlIC8gU3BlY2lmaWMgQ29uY2VyblxuICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8dGV4dGFyZWFcbiAgICAgICAgICAgICAgICAgICAgICByb3dzPXszfVxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUGxlYXNlIGxldCB1cyBrbm93IGlmIHlvdSBhcmUgZXhwZXJpZW5jaW5nIHRvb3RoIHBhaW4sIHNlbnNpdGl2aXR5LCBvciB3aXNoIHRvIGJvb2sgYSBjb25zdWx0YXRpb24gZGF0ZS4uLlwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e2Zvcm1EYXRhLm1lc3NhZ2V9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRGb3JtRGF0YSh7IC4uLmZvcm1EYXRhLCBtZXNzYWdlOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zIHJvdW5kZWQteGwgYmctc2xhdGUtNTAgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctc2t5LTUwMCBvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgICA+PC90ZXh0YXJlYT5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMy41IHJvdW5kZWQteGwgZm9udC1ib2xkIHRleHQtd2hpdGUgYmctZ3JhZGllbnQtdG8tciBmcm9tLXNreS01MDAgdG8tdGVhbC01MDAgaG92ZXI6ZnJvbS1za3ktNjAwIGhvdmVyOnRvLXRlYWwtNjAwIHNoYWRvdy1tZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiB0ZXh0LXhzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFNlbmQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlN1Ym1pdCBJbnF1aXJ5PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn07XG4iXX0=