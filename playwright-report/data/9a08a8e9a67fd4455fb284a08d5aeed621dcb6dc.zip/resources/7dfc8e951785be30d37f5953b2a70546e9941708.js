import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/InteractiveToolsSection.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=383ccf5c";
import { motion, AnimatePresence } from "/node_modules/.vite/deps/framer-motion.js?v=d79d3615";
import { Calculator, HelpCircle, Sparkles, CheckCircle2, CreditCard, Calendar, ArrowRight, ShieldCheck, Zap, Info } from "/node_modules/.vite/deps/lucide-react.js?v=a18529f7";
import { useTheme } from "/src/context/ThemeContext.tsx";
var _jsxFileName = "D:/Aravind-Works/Dentel clinic/src/components/InteractiveToolsSection.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=383ccf5c";
var _s = $RefreshSig$();
export const InteractiveToolsSection = ({ onOpenBooking }) => {
	_s();
	const { config } = useTheme();
	const [activeTab, setActiveTab] = useState("calculator");
	// Calculator State
	const [selectedProcedure, setSelectedProcedure] = useState("implants");
	const [toothCount, setToothCount] = useState(1);
	const [materialGrade, setMaterialGrade] = useState("premium");
	const [emiTenure, setEmiTenure] = useState(12);
	// Procedure cost lookup
	const procedureRates = {
		implants: {
			name: "3D Computer-Guided Implant",
			basePrice: 24999,
			premiumMultiplier: 1.4,
			category: "Restorative"
		},
		invisalign: {
			name: "Invisalign Clear Aligners",
			basePrice: 55e3,
			premiumMultiplier: 1.5,
			category: "Orthodontics"
		},
		veneers: {
			name: "Porcelain Smile Veneer",
			basePrice: 9500,
			premiumMultiplier: 1.6,
			category: "Cosmetic"
		},
		whitening: {
			name: "Laser Teeth Whitening",
			basePrice: 6999,
			premiumMultiplier: 1.2,
			category: "Cosmetic"
		},
		rootcanal: {
			name: "Single-Visit Painless RCT + Crown",
			basePrice: 6500,
			premiumMultiplier: 1.5,
			category: "Restorative"
		}
	};
	const currentProc = procedureRates[selectedProcedure] || procedureRates.implants;
	const unitCost = Math.round(currentProc.basePrice * (materialGrade === "premium" ? currentProc.premiumMultiplier : 1));
	const totalCost = selectedProcedure === "invisalign" || selectedProcedure === "whitening" ? unitCost : unitCost * toothCount;
	const monthlyEmi = Math.round(totalCost / emiTenure);
	// Quiz State
	const [quizStep, setQuizStep] = useState(0);
	const [userAnswers, setUserAnswers] = useState({});
	const [recommendedServiceId, setRecommendedServiceId] = useState(null);
	const handleQuizAnswer = (questionIdx, answerText, matchService) => {
		const updated = {
			...userAnswers,
			[questionIdx]: answerText
		};
		setUserAnswers(updated);
		if (matchService) {
			setRecommendedServiceId(matchService);
		}
		if (questionIdx + 1 < config.symptomQuiz.length) {
			setQuizStep(questionIdx + 1);
		} else {
			setQuizStep(config.symptomQuiz.length);
		}
	};
	const resetQuiz = () => {
		setQuizStep(0);
		setUserAnswers({});
		setRecommendedServiceId(null);
	};
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "cost-calculator",
		className: "py-20 relative bg-white",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "text-center max-w-3xl mx-auto space-y-3",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-100 text-sky-900 text-xs font-bold uppercase tracking-wider border border-sky-200",
							children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3.5 h-3.5 text-sky-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 79,
								columnNumber: 13
							}, this), "Transparent Pricing & Smart Assessment"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight",
							children: ["Interactive Patient ", /* @__PURE__ */ _jsxDEV("span", {
								className: "text-gradient",
								children: "Studio Tools"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 33
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-slate-600 text-sm sm:text-base",
							children: "Calculate your treatment costs with 0% interest EMI options or take our 30-second dental assessment quiz."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-8 flex justify-center",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "p-1.5 bg-slate-100 rounded-2xl flex items-center gap-1 border border-slate-200",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("calculator"),
							className: `px-5 py-3 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition cursor-pointer ${activeTab === "calculator" ? "bg-white text-sky-700 shadow-md border border-slate-200" : "text-slate-600 hover:text-slate-900"}`,
							children: [/* @__PURE__ */ _jsxDEV(Calculator, { className: "w-4 h-4 text-sky-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 101,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Cost & 0% EMI Estimator" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 102,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("quiz"),
							className: `px-5 py-3 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2 transition cursor-pointer ${activeTab === "quiz" ? "bg-white text-sky-700 shadow-md border border-slate-200" : "text-slate-600 hover:text-slate-900"}`,
							children: [/* @__PURE__ */ _jsxDEV(HelpCircle, { className: "w-4 h-4 text-sky-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 113,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Dental Symptom Checker" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 114,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 105,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-8 max-w-4xl mx-auto",
					children: activeTab === "calculator" ? /* @__PURE__ */ _jsxDEV(
						motion.div,
						/* COST CALCULATOR */
						{
							initial: {
								opacity: 0,
								y: 10
							},
							animate: {
								opacity: 1,
								y: 0
							},
							className: "bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xl",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 lg:grid-cols-12 gap-8 items-start",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "lg:col-span-7 space-y-6",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2",
											children: "1. Select Dental Treatment"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 135,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("select", {
											value: selectedProcedure,
											onChange: (e) => setSelectedProcedure(e.target.value),
											className: "w-full p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 font-bold text-sm focus:ring-2 focus:ring-sky-500 outline-none",
											children: [
												/* @__PURE__ */ _jsxDEV("option", {
													value: "implants",
													children: "3D Guided Dental Implant"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 143,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "invisalign",
													children: "Invisalign Clear Aligners"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 144,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "veneers",
													children: "Porcelain Smile Veneers"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 145,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "whitening",
													children: "Zoom 4 Laser Whitening"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 146,
													columnNumber: 23
												}, this),
												/* @__PURE__ */ _jsxDEV("option", {
													value: "rootcanal",
													children: "Painless Root Canal + Crown"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 147,
													columnNumber: 23
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 138,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 134,
											columnNumber: 19
										}, this),
										selectedProcedure !== "invisalign" && selectedProcedure !== "whitening" && /* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between items-center mb-2",
												children: [/* @__PURE__ */ _jsxDEV("label", {
													className: "text-xs font-bold uppercase tracking-wider text-slate-500",
													children: "2. Number of Teeth / Arch Units:"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 155,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-sm font-black text-sky-700 bg-sky-100 px-3 py-0.5 rounded-full border border-sky-200",
													children: [
														toothCount,
														" ",
														toothCount === 1 ? "Tooth" : "Teeth"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 158,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 154,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("input", {
												type: "range",
												min: "1",
												max: "8",
												value: toothCount,
												onChange: (e) => setToothCount(Number(e.target.value)),
												className: "w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-sky-600"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 162,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between text-[11px] text-slate-500 mt-1 font-medium",
												children: [
													/* @__PURE__ */ _jsxDEV("span", { children: "1 Tooth" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 171,
														columnNumber: 25
													}, this),
													/* @__PURE__ */ _jsxDEV("span", { children: "4 Teeth" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 172,
														columnNumber: 25
													}, this),
													/* @__PURE__ */ _jsxDEV("span", { children: "8 Teeth (Full Arch)" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 173,
														columnNumber: 25
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 170,
												columnNumber: 23
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 153,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2",
											children: "3. Select Material & Craftsmanship Grade"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 180,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "grid grid-cols-2 gap-3",
											children: [/* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => setMaterialGrade("standard"),
												className: `p-3.5 rounded-xl border text-left text-xs transition ${materialGrade === "standard" ? "border-sky-500 bg-sky-50 font-bold text-sky-900 ring-2 ring-sky-500/20" : "border-slate-200 text-slate-700 hover:border-slate-300"}`,
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-bold",
													children: "Standard Grade"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 193,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "text-[11px] text-slate-500",
													children: "High Durability Porcelain"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 194,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 184,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => setMaterialGrade("premium"),
												className: `p-3.5 rounded-xl border text-left text-xs transition ${materialGrade === "premium" ? "border-teal-600 bg-teal-50 font-bold text-teal-900 ring-2 ring-teal-500/20" : "border-slate-200 text-slate-700 hover:border-slate-300"}`,
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "font-bold flex items-center gap-1",
													children: ["German Zirconia ", /* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3.5 h-3.5 text-amber-500" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 207,
														columnNumber: 43
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 206,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("div", {
													className: "text-[11px] text-slate-500",
													children: "Translucent Bio-Ceramic"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 209,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 197,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 183,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 179,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
											className: "block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2",
											children: "4. 0% Interest EMI Duration"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 216,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "grid grid-cols-3 gap-2",
											children: [
												6,
												12,
												18
											].map((t) => /* @__PURE__ */ _jsxDEV("button", {
												type: "button",
												onClick: () => setEmiTenure(t),
												className: `py-2.5 px-3 rounded-xl text-xs font-bold border transition ${emiTenure === t ? "bg-sky-600 text-white border-sky-600 shadow-md" : "border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100"}`,
												children: [t, " Months EMI"]
											}, t, true, {
												fileName: _jsxFileName,
												lineNumber: 221,
												columnNumber: 25
											}, this))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 219,
											columnNumber: 21
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 215,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 131,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "lg:col-span-5 bg-gradient-to-br from-sky-50 via-teal-50/50 to-white text-slate-900 p-6 rounded-2xl border border-sky-200 shadow-lg space-y-6",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-[10px] font-extrabold uppercase tracking-wider text-teal-800 bg-teal-100 px-3 py-1 rounded-full border border-teal-300",
												children: "Estimated Investment Breakdown"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 242,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("h4", {
												className: "text-xl font-extrabold text-slate-900 mt-2",
												children: currentProc.name
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 245,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("p", {
												className: "text-xs text-slate-600",
												children: "Includes 3D scan, local wand anesthesia & 10-year warranty."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 248,
												columnNumber: 21
											}, this)
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 241,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-3 pt-3 border-t border-sky-200",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between items-center text-xs",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-slate-600 font-semibold",
													children: "Total Treatment Fee:"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 255,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-2xl font-black text-slate-900",
													children: ["₹", totalCost.toLocaleString()]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 256,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 254,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between items-center text-xs p-3.5 rounded-xl bg-white border border-emerald-300 shadow-sm",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "text-emerald-700 font-bold flex items-center gap-1.5",
													children: [/* @__PURE__ */ _jsxDEV(CreditCard, { className: "w-4 h-4" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 263,
														columnNumber: 25
													}, this), " 0% EMI Payment:"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 262,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-lg font-black text-emerald-700",
													children: [
														"₹",
														monthlyEmi.toLocaleString(),
														" ",
														/* @__PURE__ */ _jsxDEV("span", {
															className: "text-[10px] text-slate-500 font-semibold",
															children: "/ mo"
														}, void 0, false, {
															fileName: _jsxFileName,
															lineNumber: 266,
															columnNumber: 56
														}, this)
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 265,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 261,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 253,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "space-y-2 text-[11px] text-slate-700 font-semibold",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-600" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 273,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Zero Processing Fees or Hidden Charges" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 274,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 272,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-600" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 277,
													columnNumber: 23
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Instant Approval with Star / HDFC Insurance" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 278,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 276,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 271,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											onClick: () => onOpenBooking(selectedProcedure),
											className: "w-full py-4 px-4 rounded-xl font-extrabold text-xs text-white bg-gradient-to-r from-sky-600 to-teal-600 hover:from-sky-700 hover:to-teal-700 shadow-lg flex items-center justify-center gap-2 cursor-pointer",
											children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-4 h-4" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 286,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Lock In This EMI Estimate" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 287,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 282,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 240,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 128,
								columnNumber: 15
							}, this)
						},
						void 0,
						false,
						{
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 13
						},
						this
					) : 
					/* SYMPTOM CHECKER QUIZ */
					/* @__PURE__ */ _jsxDEV(motion.div, {
						initial: {
							opacity: 0,
							y: 10
						},
						animate: {
							opacity: 1,
							y: 0
						},
						className: "bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xl",
						children: quizStep < config.symptomQuiz.length ? /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-6 max-w-2xl mx-auto",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between text-xs text-slate-500",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: [
										"Question ",
										quizStep + 1,
										" of ",
										config.symptomQuiz.length
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 303,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "font-bold text-sky-600",
										children: "30-Sec Dental Assessor"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 304,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 302,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xl font-extrabold text-slate-900",
									children: config.symptomQuiz[quizStep].question
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 307,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-3",
									children: config.symptomQuiz[quizStep].options.map((opt, i) => /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => handleQuizAnswer(quizStep, opt.text, "matchService" in opt ? opt.matchService : undefined),
										className: "w-full p-4 rounded-xl border border-slate-200 bg-slate-50 hover:bg-sky-50 hover:border-sky-500 text-left font-bold text-sm text-slate-900 flex items-center justify-between transition group cursor-pointer",
										children: [/* @__PURE__ */ _jsxDEV("span", { children: opt.text }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 318,
											columnNumber: 25
										}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "w-4 h-4 text-slate-400 group-hover:text-sky-600 group-hover:translate-x-1 transition-transform" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 319,
											columnNumber: 25
										}, this)]
									}, i, true, {
										fileName: _jsxFileName,
										lineNumber: 313,
										columnNumber: 23
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 311,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 301,
							columnNumber: 17
						}, this) : 
						/* QUIZ RESULT RECOMMENDATION */
						/* @__PURE__ */ _jsxDEV("div", {
							className: "text-center space-y-6 max-w-xl mx-auto py-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-md",
									children: /* @__PURE__ */ _jsxDEV(Zap, { className: "w-8 h-8" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 328,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 327,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-extrabold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200",
											children: "Assessment Complete"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 332,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("h3", {
											className: "text-2xl font-black text-slate-900",
											children: ["Recommended Procedure: ", config.services.find((s) => s.id === recommendedServiceId)?.title || "Specialist Dental Consultation"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 335,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-600",
											children: "Based on your inputs, our clinical team recommends an in-person 3D scan and painless diagnostic review."
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 338,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 331,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "p-4 rounded-2xl bg-sky-50 border border-sky-200 text-left text-xs space-y-2",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "font-extrabold text-sky-900 flex items-center gap-1.5",
										children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-4 h-4 text-sky-600" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 345,
											columnNumber: 23
										}, this), "What happens at your consultation:"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 344,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("ul", {
										className: "space-y-1 text-slate-700 list-disc list-inside font-medium",
										children: [
											/* @__PURE__ */ _jsxDEV("li", { children: "Full 3D Intraoral Digital Scanning (No gagging)" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 349,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("li", { children: "Review by Senior Specialist Surgeon" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 350,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("li", { children: "Transparent Cost & 0% EMI options provided beforehand" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 351,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 348,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 343,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex gap-3",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										onClick: resetQuiz,
										className: "py-3 px-4 rounded-xl text-xs font-bold border border-slate-300 text-slate-700 hover:bg-slate-100",
										children: "Retake Quiz"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 356,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => onOpenBooking(recommendedServiceId || undefined),
										className: "flex-1 py-3.5 px-6 rounded-xl font-extrabold text-white bg-gradient-to-r from-sky-600 to-teal-600 hover:from-sky-700 hover:to-teal-700 shadow-lg flex items-center justify-center gap-2 text-xs cursor-pointer",
										children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 366,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Book Recommended Slot" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 367,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 362,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 355,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 326,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 295,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 120,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 74,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 73,
		columnNumber: 5
	}, this);
};
_s(InteractiveToolsSection, "45lZNXJP5es8kBiXoIX9BnV08uc=", false, function() {
	return [useTheme];
});
_c = InteractiveToolsSection;
var _c;
$RefreshReg$(_c, "InteractiveToolsSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/InteractiveToolsSection.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Aravind-Works/Dentel clinic/src/components/InteractiveToolsSection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Aravind-Works/Dentel clinic/src/components/InteractiveToolsSection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Aravind-Works/Dentel clinic/src/components/InteractiveToolsSection.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLFFBQVEsdUJBQXVCO0FBQ3hDLFNBQ0UsWUFDQSxZQUNBLFVBQ0EsY0FDQSxZQUNBLFVBQ0EsWUFDQSxhQUNBLEtBQ0EsWUFDSztBQUNQLFNBQVMsZ0JBQWdCOzs7O0FBT3pCLE9BQU8sTUFBTSwyQkFBbUUsRUFBRSxvQkFBb0I7O0NBQ3BHLE1BQU0sRUFBRSxXQUFXLFNBQVM7Q0FDNUIsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQWdDLFlBQVk7O0NBRzlFLE1BQU0sQ0FBQyxtQkFBbUIsd0JBQXdCLFNBQWlCLFVBQVU7Q0FDN0UsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQWlCLENBQUM7Q0FDdEQsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQWlDLFNBQVM7Q0FDcEYsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQWlCLEVBQUU7O0NBR3JELE1BQU0saUJBQW1IO0VBQ3ZILFVBQVU7R0FBRSxNQUFNO0dBQThCLFdBQVc7R0FBTyxtQkFBbUI7R0FBSyxVQUFVO0VBQWM7RUFDbEgsWUFBWTtHQUFFLE1BQU07R0FBNkIsV0FBVztHQUFPLG1CQUFtQjtHQUFLLFVBQVU7RUFBZTtFQUNwSCxTQUFTO0dBQUUsTUFBTTtHQUEwQixXQUFXO0dBQU0sbUJBQW1CO0dBQUssVUFBVTtFQUFXO0VBQ3pHLFdBQVc7R0FBRSxNQUFNO0dBQXlCLFdBQVc7R0FBTSxtQkFBbUI7R0FBSyxVQUFVO0VBQVc7RUFDMUcsV0FBVztHQUFFLE1BQU07R0FBcUMsV0FBVztHQUFNLG1CQUFtQjtHQUFLLFVBQVU7RUFBYztDQUMzSDtDQUVBLE1BQU0sY0FBYyxlQUFlLHNCQUFzQixlQUFlO0NBQ3hFLE1BQU0sV0FBVyxLQUFLLE1BQU0sWUFBWSxhQUFhLGtCQUFrQixZQUFZLFlBQVksb0JBQW9CLEVBQUU7Q0FDckgsTUFBTSxZQUFZLHNCQUFzQixnQkFBZ0Isc0JBQXNCLGNBQWMsV0FBVyxXQUFXO0NBQ2xILE1BQU0sYUFBYSxLQUFLLE1BQU0sWUFBWSxTQUFTOztDQUduRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQWlCLENBQUM7Q0FDbEQsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQWlDLENBQUMsQ0FBQztDQUN6RSxNQUFNLENBQUMsc0JBQXNCLDJCQUEyQixTQUF3QixJQUFJO0NBRXBGLE1BQU0sb0JBQW9CLGFBQXFCLFlBQW9CLGlCQUEwQjtFQUMzRixNQUFNLFVBQVU7R0FBRSxHQUFHO0lBQWMsY0FBYztFQUFXO0VBQzVELGVBQWUsT0FBTztFQUV0QixJQUFJLGNBQWM7R0FDaEIsd0JBQXdCLFlBQVk7RUFDdEM7RUFFQSxJQUFJLGNBQWMsSUFBSSxPQUFPLFlBQVksUUFBUTtHQUMvQyxZQUFZLGNBQWMsQ0FBQztFQUM3QixPQUFPO0dBQ0wsWUFBWSxPQUFPLFlBQVksTUFBTTtFQUN2QztDQUNGO0NBRUEsTUFBTSxrQkFBa0I7RUFDdEIsWUFBWSxDQUFDO0VBQ2IsZUFBZSxDQUFDLENBQUM7RUFDakIsd0JBQXdCLElBQUk7Q0FDOUI7Q0FFQSxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxJQUFHO0VBQWtCLFdBQVU7WUFDdEMsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUdFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLDJCQUE0Qjs7OztpQkFBQyx3Q0FFOUM7Ozs7OztNQUNMLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkLENBQWtGLHdCQUM1RCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBZ0I7T0FBa0I7Ozs7ZUFDcEU7Ozs7OztNQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUFzQztNQUVoRDs7Ozs7S0FDQTs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDYix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGFBQWEsWUFBWTtPQUN4QyxXQUFXLHVHQUNULGNBQWMsZUFDViw0REFDQTtpQkFMUixDQVFFLHdCQUFDLFlBQUQsRUFBWSxXQUFVLHVCQUF3Qjs7OztpQkFDOUMsd0JBQUMsUUFBRCxZQUFNLDBCQUE2Qjs7OztlQUM3Qjs7Ozs7Z0JBRVIsd0JBQUMsVUFBRDtPQUNFLGVBQWUsYUFBYSxNQUFNO09BQ2xDLFdBQVcsdUdBQ1QsY0FBYyxTQUNWLDREQUNBO2lCQUxSLENBUUUsd0JBQUMsWUFBRCxFQUFZLFdBQVUsdUJBQXdCOzs7O2lCQUM5Qyx3QkFBQyxRQUFELFlBQU0seUJBQTRCOzs7O2VBQzVCOzs7OztjQUNMOzs7Ozs7SUFDRjs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLGNBQWMsZUFFYjtNQUFDLE9BQU87O01BQVI7T0FDRSxTQUFTO1FBQUUsU0FBUztRQUFHLEdBQUc7T0FBRztPQUM3QixTQUFTO1FBQUUsU0FBUztRQUFHLEdBQUc7T0FBRTtPQUM1QixXQUFVO2lCQUVWLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBR0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFHRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtXQUFPLFdBQVU7cUJBQXVFO1VBRWpGOzs7O29CQUNQLHdCQUFDLFVBQUQ7V0FDRSxPQUFPO1dBQ1AsV0FBVyxNQUFNLHFCQUFxQixFQUFFLE9BQU8sS0FBSztXQUNwRCxXQUFVO3FCQUhaO1lBS0Usd0JBQUMsVUFBRDthQUFRLE9BQU07dUJBQVc7WUFBZ0M7Ozs7O1lBQ3pELHdCQUFDLFVBQUQ7YUFBUSxPQUFNO3VCQUFhO1lBQWlDOzs7OztZQUM1RCx3QkFBQyxVQUFEO2FBQVEsT0FBTTt1QkFBVTtZQUErQjs7Ozs7WUFDdkQsd0JBQUMsVUFBRDthQUFRLE9BQU07dUJBQVk7WUFBOEI7Ozs7O1lBQ3hELHdCQUFDLFVBQUQ7YUFBUSxPQUFNO3VCQUFZO1lBQW1DOzs7OztXQUN2RDs7Ozs7a0JBQ0w7Ozs7O1VBR0osc0JBQXNCLGdCQUFnQixzQkFBc0IsZUFDM0Qsd0JBQUMsT0FBRDtXQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsU0FBRDthQUFPLFdBQVU7dUJBQTREO1lBRXRFOzs7O3NCQUNQLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFoQjtjQUNHO2NBQVc7Y0FBRSxlQUFlLElBQUksVUFBVTthQUN2Qzs7Ozs7b0JBQ0g7Ozs7OztXQUNMLHdCQUFDLFNBQUQ7WUFDRSxNQUFLO1lBQ0wsS0FBSTtZQUNKLEtBQUk7WUFDSixPQUFPO1lBQ1AsV0FBVyxNQUFNLGNBQWMsT0FBTyxFQUFFLE9BQU8sS0FBSyxDQUFDO1lBQ3JELFdBQVU7V0FDWDs7Ozs7V0FDRCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZjthQUNFLHdCQUFDLFFBQUQsWUFBTSxVQUFhOzs7OzthQUNuQix3QkFBQyxRQUFELFlBQU0sVUFBYTs7Ozs7YUFDbkIsd0JBQUMsUUFBRCxZQUFNLHNCQUF5Qjs7Ozs7WUFDNUI7Ozs7OztVQUNGOzs7OztVQUlQLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1dBQU8sV0FBVTtxQkFBdUU7VUFFakY7Ozs7b0JBQ1Asd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1lBQ0UsTUFBSztZQUNMLGVBQWUsaUJBQWlCLFVBQVU7WUFDMUMsV0FBVyx3REFDVCxrQkFBa0IsYUFDZCwyRUFDQTtzQkFOUixDQVNFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFZO1lBQW1COzs7O3NCQUM5Qyx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBNkI7WUFBOEI7Ozs7b0JBQ3BFOzs7OztxQkFFUix3QkFBQyxVQUFEO1lBQ0UsTUFBSztZQUNMLGVBQWUsaUJBQWlCLFNBQVM7WUFDekMsV0FBVyx3REFDVCxrQkFBa0IsWUFDZCwrRUFDQTtzQkFOUixDQVNFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQW1ELG9CQUNqQyx3QkFBQyxVQUFELEVBQVUsV0FBVSw2QkFBOEI7Ozs7cUJBQy9EOzs7OztzQkFDTCx3QkFBQyxPQUFEO2FBQUssV0FBVTt1QkFBNkI7WUFBNEI7Ozs7b0JBQ2xFOzs7OzttQkFDTDs7Ozs7a0JBQ0Y7Ozs7O1VBR0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7V0FBTyxXQUFVO3FCQUF1RTtVQUVqRjs7OztvQkFDUCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDWjtZQUFDO1lBQUc7WUFBSTtXQUFFLENBQUMsQ0FBQyxLQUFLLE1BQ2hCLHdCQUFDLFVBQUQ7WUFFRSxNQUFLO1lBQ0wsZUFBZSxhQUFhLENBQUM7WUFDN0IsV0FBVyw4REFDVCxjQUFjLElBQ1YsbURBQ0E7c0JBUFIsQ0FVRyxHQUFFLGFBQ0c7Y0FWRDs7OztrQkFVQyxDQUNUO1VBQ0U7Ozs7a0JBQ0Y7Ozs7O1NBRUY7Ozs7O2tCQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRDtXQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUE4SDtXQUV4STs7Ozs7V0FDTix3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFDWCxZQUFZO1dBQ1g7Ozs7O1dBQ0osd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQXlCO1dBRW5DOzs7OztVQUNBOzs7OztVQUVMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBK0I7WUFBMEI7Ozs7c0JBQ3pFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFoQixDQUFxRCxLQUNqRCxVQUFVLGVBQWUsQ0FDdkI7Ozs7O29CQUNIOzs7OztxQkFFTCx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFoQixDQUNFLHdCQUFDLFlBQUQsRUFBWSxXQUFVLFVBQVc7Ozs7dUJBQUMsa0JBQzlCOzs7OztzQkFDTix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBaEI7Y0FBc0Q7Y0FDbEQsV0FBVyxlQUFlO2NBQUU7Y0FBQyx3QkFBQyxRQUFEO2VBQU0sV0FBVTt5QkFBMkM7Y0FBVTs7Ozs7YUFDaEc7Ozs7O29CQUNIOzs7OzttQkFDRjs7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLDJCQUE0Qjs7OztzQkFDcEQsd0JBQUMsUUFBRCxZQUFNLHlDQUE0Qzs7OztvQkFDL0M7Ozs7O3FCQUNMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmLENBQ0Usd0JBQUMsY0FBRCxFQUFjLFdBQVUsMkJBQTRCOzs7O3NCQUNwRCx3QkFBQyxRQUFELFlBQU0sOENBQWlEOzs7O29CQUNwRDs7Ozs7bUJBQ0Y7Ozs7OztVQUVMLHdCQUFDLFVBQUQ7V0FDRSxlQUFlLGNBQWMsaUJBQWlCO1dBQzlDLFdBQVU7cUJBRlosQ0FJRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7O3FCQUMvQix3QkFBQyxRQUFELFlBQU0sNEJBQStCOzs7O21CQUMvQjs7Ozs7O1NBQ0w7Ozs7O2dCQUVGOzs7Ozs7TUFDSzs7Ozs7Ozs7Ozs7S0FHWix3QkFBQyxPQUFPLEtBQVI7TUFDRSxTQUFTO09BQUUsU0FBUztPQUFHLEdBQUc7TUFBRztNQUM3QixTQUFTO09BQUUsU0FBUztPQUFHLEdBQUc7TUFBRTtNQUM1QixXQUFVO2dCQUVULFdBQVcsT0FBTyxZQUFZLFNBQzdCLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU07VUFBVSxXQUFXO1VBQUU7VUFBSyxPQUFPLFlBQVk7U0FBYTs7OzttQkFDbEUsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXlCO1NBQTRCOzs7O2lCQUNsRTs7Ozs7O1FBRUwsd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1gsT0FBTyxZQUFZLFNBQVMsQ0FBQztRQUM1Qjs7Ozs7UUFFSix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWixPQUFPLFlBQVksU0FBUyxDQUFDLFFBQVEsS0FBSyxLQUFLLE1BQzlDLHdCQUFDLFVBQUQ7VUFFRSxlQUFlLGlCQUFpQixVQUFVLElBQUksTUFBTSxrQkFBa0IsTUFBTSxJQUFJLGVBQWUsU0FBUztVQUN4RyxXQUFVO29CQUhaLENBS0Usd0JBQUMsUUFBRCxZQUFPLElBQUksS0FBVzs7OztvQkFDdEIsd0JBQUMsWUFBRCxFQUFZLFdBQVUsaUdBQWtHOzs7O2tCQUNsSDtZQU5EOzs7O2dCQU1DLENBQ1Q7UUFDRTs7Ozs7T0FDRjs7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ2Isd0JBQUMsS0FBRCxFQUFLLFdBQVUsVUFBVzs7Ozs7UUFDdkI7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBa0k7VUFFNUk7Ozs7O1VBQ04sd0JBQUMsTUFBRDtXQUFJLFdBQVU7cUJBQWQsQ0FBbUQsMkJBQ3pCLE9BQU8sU0FBUyxNQUFLLE1BQUssRUFBRSxPQUFPLG9CQUFvQixDQUFDLEVBQUUsU0FBUyxnQ0FDekY7Ozs7OztVQUNKLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUF5QjtVQUVuQzs7Ozs7U0FDQTs7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLHVCQUF3Qjs7OztvQkFBQyxvQ0FFN0M7Ozs7O21CQUNMLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFkO1dBQ0Usd0JBQUMsTUFBRCxZQUFJLGtEQUFtRDs7Ozs7V0FDdkQsd0JBQUMsTUFBRCxZQUFJLHNDQUF1Qzs7Ozs7V0FDM0Msd0JBQUMsTUFBRCxZQUFJLHdEQUF5RDs7Ozs7VUFDM0Q7Ozs7O2lCQUNEOzs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFVBQUQ7VUFDRSxTQUFTO1VBQ1QsV0FBVTtvQkFDWDtTQUVPOzs7O21CQUNSLHdCQUFDLFVBQUQ7VUFDRSxlQUFlLGNBQWMsd0JBQXdCLFNBQVM7VUFDOUQsV0FBVTtvQkFGWixDQUlFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFVBQVc7Ozs7b0JBQy9CLHdCQUFDLFFBQUQsWUFBTSx3QkFBMkI7Ozs7a0JBQzNCOzs7OztpQkFDTDs7Ozs7O09BQ0Y7Ozs7OztLQUVHOzs7OztJQUVYOzs7OztHQUVGOzs7Ozs7Q0FDRTs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJJbnRlcmFjdGl2ZVRvb2xzU2VjdGlvbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgbW90aW9uLCBBbmltYXRlUHJlc2VuY2UgfSBmcm9tICdmcmFtZXItbW90aW9uJztcbmltcG9ydCB7IFxuICBDYWxjdWxhdG9yLCBcbiAgSGVscENpcmNsZSwgXG4gIFNwYXJrbGVzLCBcbiAgQ2hlY2tDaXJjbGUyLCBcbiAgQ3JlZGl0Q2FyZCwgXG4gIENhbGVuZGFyLCBcbiAgQXJyb3dSaWdodCxcbiAgU2hpZWxkQ2hlY2ssXG4gIFphcCxcbiAgSW5mb1xufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICdAL2NvbnRleHQvVGhlbWVDb250ZXh0JztcbmltcG9ydCB0eXBlIHsgUXVpek9wdGlvbiB9IGZyb20gJ0AvY29uZmlnL3NpdGVDb25maWcnO1xuXG5pbnRlcmZhY2UgSW50ZXJhY3RpdmVUb29sc1NlY3Rpb25Qcm9wcyB7XG4gIG9uT3BlbkJvb2tpbmc6IChzZXJ2aWNlSWQ/OiBzdHJpbmcpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBJbnRlcmFjdGl2ZVRvb2xzU2VjdGlvbjogUmVhY3QuRkM8SW50ZXJhY3RpdmVUb29sc1NlY3Rpb25Qcm9wcz4gPSAoeyBvbk9wZW5Cb29raW5nIH0pID0+IHtcbiAgY29uc3QgeyBjb25maWcgfSA9IHVzZVRoZW1lKCk7XG4gIGNvbnN0IFthY3RpdmVUYWIsIHNldEFjdGl2ZVRhYl0gPSB1c2VTdGF0ZTwnY2FsY3VsYXRvcicgfCAncXVpeic+KCdjYWxjdWxhdG9yJyk7XG5cbiAgLy8gQ2FsY3VsYXRvciBTdGF0ZVxuICBjb25zdCBbc2VsZWN0ZWRQcm9jZWR1cmUsIHNldFNlbGVjdGVkUHJvY2VkdXJlXSA9IHVzZVN0YXRlPHN0cmluZz4oJ2ltcGxhbnRzJyk7XG4gIGNvbnN0IFt0b290aENvdW50LCBzZXRUb290aENvdW50XSA9IHVzZVN0YXRlPG51bWJlcj4oMSk7XG4gIGNvbnN0IFttYXRlcmlhbEdyYWRlLCBzZXRNYXRlcmlhbEdyYWRlXSA9IHVzZVN0YXRlPCdzdGFuZGFyZCcgfCAncHJlbWl1bSc+KCdwcmVtaXVtJyk7XG4gIGNvbnN0IFtlbWlUZW51cmUsIHNldEVtaVRlbnVyZV0gPSB1c2VTdGF0ZTxudW1iZXI+KDEyKTsgLy8gbW9udGhzXG5cbiAgLy8gUHJvY2VkdXJlIGNvc3QgbG9va3VwXG4gIGNvbnN0IHByb2NlZHVyZVJhdGVzOiBSZWNvcmQ8c3RyaW5nLCB7IG5hbWU6IHN0cmluZzsgYmFzZVByaWNlOiBudW1iZXI7IHByZW1pdW1NdWx0aXBsaWVyOiBudW1iZXI7IGNhdGVnb3J5OiBzdHJpbmcgfT4gPSB7XG4gICAgaW1wbGFudHM6IHsgbmFtZTogJzNEIENvbXB1dGVyLUd1aWRlZCBJbXBsYW50JywgYmFzZVByaWNlOiAyNDk5OSwgcHJlbWl1bU11bHRpcGxpZXI6IDEuNCwgY2F0ZWdvcnk6ICdSZXN0b3JhdGl2ZScgfSxcbiAgICBpbnZpc2FsaWduOiB7IG5hbWU6ICdJbnZpc2FsaWduIENsZWFyIEFsaWduZXJzJywgYmFzZVByaWNlOiA1NTAwMCwgcHJlbWl1bU11bHRpcGxpZXI6IDEuNSwgY2F0ZWdvcnk6ICdPcnRob2RvbnRpY3MnIH0sXG4gICAgdmVuZWVyczogeyBuYW1lOiAnUG9yY2VsYWluIFNtaWxlIFZlbmVlcicsIGJhc2VQcmljZTogOTUwMCwgcHJlbWl1bU11bHRpcGxpZXI6IDEuNiwgY2F0ZWdvcnk6ICdDb3NtZXRpYycgfSxcbiAgICB3aGl0ZW5pbmc6IHsgbmFtZTogJ0xhc2VyIFRlZXRoIFdoaXRlbmluZycsIGJhc2VQcmljZTogNjk5OSwgcHJlbWl1bU11bHRpcGxpZXI6IDEuMiwgY2F0ZWdvcnk6ICdDb3NtZXRpYycgfSxcbiAgICByb290Y2FuYWw6IHsgbmFtZTogJ1NpbmdsZS1WaXNpdCBQYWlubGVzcyBSQ1QgKyBDcm93bicsIGJhc2VQcmljZTogNjUwMCwgcHJlbWl1bU11bHRpcGxpZXI6IDEuNSwgY2F0ZWdvcnk6ICdSZXN0b3JhdGl2ZScgfVxuICB9O1xuXG4gIGNvbnN0IGN1cnJlbnRQcm9jID0gcHJvY2VkdXJlUmF0ZXNbc2VsZWN0ZWRQcm9jZWR1cmVdIHx8IHByb2NlZHVyZVJhdGVzLmltcGxhbnRzO1xuICBjb25zdCB1bml0Q29zdCA9IE1hdGgucm91bmQoY3VycmVudFByb2MuYmFzZVByaWNlICogKG1hdGVyaWFsR3JhZGUgPT09ICdwcmVtaXVtJyA/IGN1cnJlbnRQcm9jLnByZW1pdW1NdWx0aXBsaWVyIDogMSkpO1xuICBjb25zdCB0b3RhbENvc3QgPSBzZWxlY3RlZFByb2NlZHVyZSA9PT0gJ2ludmlzYWxpZ24nIHx8IHNlbGVjdGVkUHJvY2VkdXJlID09PSAnd2hpdGVuaW5nJyA/IHVuaXRDb3N0IDogdW5pdENvc3QgKiB0b290aENvdW50O1xuICBjb25zdCBtb250aGx5RW1pID0gTWF0aC5yb3VuZCh0b3RhbENvc3QgLyBlbWlUZW51cmUpO1xuXG4gIC8vIFF1aXogU3RhdGVcbiAgY29uc3QgW3F1aXpTdGVwLCBzZXRRdWl6U3RlcF0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuICBjb25zdCBbdXNlckFuc3dlcnMsIHNldFVzZXJBbnN3ZXJzXSA9IHVzZVN0YXRlPFJlY29yZDxudW1iZXIsIHN0cmluZz4+KHt9KTtcbiAgY29uc3QgW3JlY29tbWVuZGVkU2VydmljZUlkLCBzZXRSZWNvbW1lbmRlZFNlcnZpY2VJZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcblxuICBjb25zdCBoYW5kbGVRdWl6QW5zd2VyID0gKHF1ZXN0aW9uSWR4OiBudW1iZXIsIGFuc3dlclRleHQ6IHN0cmluZywgbWF0Y2hTZXJ2aWNlPzogc3RyaW5nKSA9PiB7XG4gICAgY29uc3QgdXBkYXRlZCA9IHsgLi4udXNlckFuc3dlcnMsIFtxdWVzdGlvbklkeF06IGFuc3dlclRleHQgfTtcbiAgICBzZXRVc2VyQW5zd2Vycyh1cGRhdGVkKTtcblxuICAgIGlmIChtYXRjaFNlcnZpY2UpIHtcbiAgICAgIHNldFJlY29tbWVuZGVkU2VydmljZUlkKG1hdGNoU2VydmljZSk7XG4gICAgfVxuXG4gICAgaWYgKHF1ZXN0aW9uSWR4ICsgMSA8IGNvbmZpZy5zeW1wdG9tUXVpei5sZW5ndGgpIHtcbiAgICAgIHNldFF1aXpTdGVwKHF1ZXN0aW9uSWR4ICsgMSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldFF1aXpTdGVwKGNvbmZpZy5zeW1wdG9tUXVpei5sZW5ndGgpOyAvLyBGaW5hbCByZXN1bHQgc3RlcFxuICAgIH1cbiAgfTtcblxuICBjb25zdCByZXNldFF1aXogPSAoKSA9PiB7XG4gICAgc2V0UXVpelN0ZXAoMCk7XG4gICAgc2V0VXNlckFuc3dlcnMoe30pO1xuICAgIHNldFJlY29tbWVuZGVkU2VydmljZUlkKG51bGwpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gaWQ9XCJjb3N0LWNhbGN1bGF0b3JcIiBjbGFzc05hbWU9XCJweS0yMCByZWxhdGl2ZSBiZy13aGl0ZVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy03eGwgbXgtYXV0byBweC00IHNtOnB4LTYgbGc6cHgtOFwiPlxuICAgICAgICBcbiAgICAgICAgey8qIFNlY3Rpb24gSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIG1heC13LTN4bCBteC1hdXRvIHNwYWNlLXktM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTMuNSBweS0xLjUgcm91bmRlZC1mdWxsIGJnLXNreS0xMDAgdGV4dC1za3ktOTAwIHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBib3JkZXIgYm9yZGVyLXNreS0yMDBcIj5cbiAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXNreS02MDBcIiAvPlxuICAgICAgICAgICAgVHJhbnNwYXJlbnQgUHJpY2luZyAmIFNtYXJ0IEFzc2Vzc21lbnRcbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0zeGwgc206dGV4dC00eGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgdHJhY2tpbmctdGlnaHRcIj5cbiAgICAgICAgICAgIEludGVyYWN0aXZlIFBhdGllbnQgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmFkaWVudFwiPlN0dWRpbyBUb29sczwvc3Bhbj5cbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwIHRleHQtc20gc206dGV4dC1iYXNlXCI+XG4gICAgICAgICAgICBDYWxjdWxhdGUgeW91ciB0cmVhdG1lbnQgY29zdHMgd2l0aCAwJSBpbnRlcmVzdCBFTUkgb3B0aW9ucyBvciB0YWtlIG91ciAzMC1zZWNvbmQgZGVudGFsIGFzc2Vzc21lbnQgcXVpei5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBUb29sIFN3aXRjaGVyIFRhYnMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOCBmbGV4IGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTEuNSBiZy1zbGF0ZS0xMDAgcm91bmRlZC0yeGwgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDBcIj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdjYWxjdWxhdG9yJyl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTUgcHktMyByb3VuZGVkLXhsIHRleHQteHMgc206dGV4dC1zbSBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gJ2NhbGN1bGF0b3InXG4gICAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSB0ZXh0LXNreS03MDAgc2hhZG93LW1kIGJvcmRlciBib3JkZXItc2xhdGUtMjAwJ1xuICAgICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS02MDAgaG92ZXI6dGV4dC1zbGF0ZS05MDAnXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8Q2FsY3VsYXRvciBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2t5LTYwMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPkNvc3QgJiAwJSBFTUkgRXN0aW1hdG9yPC9zcGFuPlxuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdxdWl6Jyl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTUgcHktMyByb3VuZGVkLXhsIHRleHQteHMgc206dGV4dC1zbSBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gJ3F1aXonXG4gICAgICAgICAgICAgICAgICA/ICdiZy13aGl0ZSB0ZXh0LXNreS03MDAgc2hhZG93LW1kIGJvcmRlciBib3JkZXItc2xhdGUtMjAwJ1xuICAgICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS02MDAgaG92ZXI6dGV4dC1zbGF0ZS05MDAnXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8SGVscENpcmNsZSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2t5LTYwMFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPkRlbnRhbCBTeW1wdG9tIENoZWNrZXI8L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFRvb2wgRGlzcGxheSBBcmVhICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTggbWF4LXctNHhsIG14LWF1dG9cIj5cbiAgICAgICAgICB7YWN0aXZlVGFiID09PSAnY2FsY3VsYXRvcicgPyAoXG4gICAgICAgICAgICAvKiBDT1NUIENBTENVTEFUT1IgKi9cbiAgICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogMTAgfX1cbiAgICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCB5OiAwIH19XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtM3hsIHAtNiBzbTpwLTggYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgc2hhZG93LXhsXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGxnOmdyaWQtY29scy0xMiBnYXAtOCBpdGVtcy1zdGFydFwiPlxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgIHsvKiBJbnB1dHMgQ29sdW1uICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNyBzcGFjZS15LTZcIj5cbiAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgey8qIFN0ZXAgMTogU2VsZWN0IFByb2NlZHVyZSAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS01MDAgbWItMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIDEuIFNlbGVjdCBEZW50YWwgVHJlYXRtZW50XG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxzZWxlY3RcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0ZWRQcm9jZWR1cmV9XG4gICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZFByb2NlZHVyZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMy41IHJvdW5kZWQteGwgYmctc2xhdGUtNTAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgdGV4dC1zbGF0ZS05MDAgZm9udC1ib2xkIHRleHQtc20gZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctc2t5LTUwMCBvdXRsaW5lLW5vbmVcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImltcGxhbnRzXCI+M0QgR3VpZGVkIERlbnRhbCBJbXBsYW50PC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cImludmlzYWxpZ25cIj5JbnZpc2FsaWduIENsZWFyIEFsaWduZXJzPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInZlbmVlcnNcIj5Qb3JjZWxhaW4gU21pbGUgVmVuZWVyczwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJ3aGl0ZW5pbmdcIj5ab29tIDQgTGFzZXIgV2hpdGVuaW5nPC9vcHRpb24+XG4gICAgICAgICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cInJvb3RjYW5hbFwiPlBhaW5sZXNzIFJvb3QgQ2FuYWwgKyBDcm93bjwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICB7LyogU3RlcCAyOiBRdWFudGl0eSBTbGlkZXIgKElmIGFwcGxpY2FibGUpICovfVxuICAgICAgICAgICAgICAgICAge3NlbGVjdGVkUHJvY2VkdXJlICE9PSAnaW52aXNhbGlnbicgJiYgc2VsZWN0ZWRQcm9jZWR1cmUgIT09ICd3aGl0ZW5pbmcnICYmIChcbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciBtYi0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDIuIE51bWJlciBvZiBUZWV0aCAvIEFyY2ggVW5pdHM6XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJsYWNrIHRleHQtc2t5LTcwMCBiZy1za3ktMTAwIHB4LTMgcHktMC41IHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLXNreS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3Rvb3RoQ291bnR9IHt0b290aENvdW50ID09PSAxID8gJ1Rvb3RoJyA6ICdUZWV0aCd9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwicmFuZ2VcIlxuICAgICAgICAgICAgICAgICAgICAgICAgbWluPVwiMVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXg9XCI4XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt0b290aENvdW50fVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUb290aENvdW50KE51bWJlcihlLnRhcmdldC52YWx1ZSkpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtMiBiZy1zbGF0ZS0yMDAgcm91bmRlZC1sZyBhcHBlYXJhbmNlLW5vbmUgY3Vyc29yLXBvaW50ZXIgYWNjZW50LXNreS02MDBcIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiB0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBtdC0xIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj4xIFRvb3RoPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+NCBUZWV0aDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPjggVGVldGggKEZ1bGwgQXJjaCk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgey8qIFN0ZXAgMzogTWF0ZXJpYWwgR3JhZGUgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNTAwIG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICAzLiBTZWxlY3QgTWF0ZXJpYWwgJiBDcmFmdHNtYW5zaGlwIEdyYWRlXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TWF0ZXJpYWxHcmFkZSgnc3RhbmRhcmQnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMy41IHJvdW5kZWQteGwgYm9yZGVyIHRleHQtbGVmdCB0ZXh0LXhzIHRyYW5zaXRpb24gJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbWF0ZXJpYWxHcmFkZSA9PT0gJ3N0YW5kYXJkJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1za3ktNTAwIGJnLXNreS01MCBmb250LWJvbGQgdGV4dC1za3ktOTAwIHJpbmctMiByaW5nLXNreS01MDAvMjAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXNsYXRlLTIwMCB0ZXh0LXNsYXRlLTcwMCBob3Zlcjpib3JkZXItc2xhdGUtMzAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWJvbGRcIj5TdGFuZGFyZCBHcmFkZTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMFwiPkhpZ2ggRHVyYWJpbGl0eSBQb3JjZWxhaW48L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0TWF0ZXJpYWxHcmFkZSgncHJlbWl1bScpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0zLjUgcm91bmRlZC14bCBib3JkZXIgdGV4dC1sZWZ0IHRleHQteHMgdHJhbnNpdGlvbiAke1xuICAgICAgICAgICAgICAgICAgICAgICAgICBtYXRlcmlhbEdyYWRlID09PSAncHJlbWl1bSdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdib3JkZXItdGVhbC02MDAgYmctdGVhbC01MCBmb250LWJvbGQgdGV4dC10ZWFsLTkwMCByaW5nLTIgcmluZy10ZWFsLTUwMC8yMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItc2xhdGUtMjAwIHRleHQtc2xhdGUtNzAwIGhvdmVyOmJvcmRlci1zbGF0ZS0zMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICBHZXJtYW4gWmlyY29uaWEgPFNwYXJrbGVzIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYW1iZXItNTAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMFwiPlRyYW5zbHVjZW50IEJpby1DZXJhbWljPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBTdGVwIDQ6IEVNSSBUZW51cmUgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNTAwIG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA0LiAwJSBJbnRlcmVzdCBFTUkgRHVyYXRpb25cbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0zIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAge1s2LCAxMiwgMThdLm1hcCgodCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3R9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRFbWlUZW51cmUodCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB5LTIuNSBweC0zIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgYm9yZGVyIHRyYW5zaXRpb24gJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbWlUZW51cmUgPT09IHRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXNreS02MDAgdGV4dC13aGl0ZSBib3JkZXItc2t5LTYwMCBzaGFkb3ctbWQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItc2xhdGUtMjAwIGJnLXNsYXRlLTUwIHRleHQtc2xhdGUtNzAwIGhvdmVyOmJnLXNsYXRlLTEwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHt0fSBNb250aHMgRU1JXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIENhbGN1bGF0aW9uIE91dHB1dCBDYXJkIC0gQ3Jpc3AgTGlnaHQgR3JhZGllbnQgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi01IGJnLWdyYWRpZW50LXRvLWJyIGZyb20tc2t5LTUwIHZpYS10ZWFsLTUwLzUwIHRvLXdoaXRlIHRleHQtc2xhdGUtOTAwIHAtNiByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNreS0yMDAgc2hhZG93LWxnIHNwYWNlLXktNlwiPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1leHRyYWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtdGVhbC04MDAgYmctdGVhbC0xMDAgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLXRlYWwtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgRXN0aW1hdGVkIEludmVzdG1lbnQgQnJlYWtkb3duXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgbXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50UHJvYy5uYW1lfVxuICAgICAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgSW5jbHVkZXMgM0Qgc2NhbiwgbG9jYWwgd2FuZCBhbmVzdGhlc2lhICYgMTAteWVhciB3YXJyYW50eS5cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zIHB0LTMgYm9yZGVyLXQgYm9yZGVyLXNreS0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwIGZvbnQtc2VtaWJvbGRcIj5Ub3RhbCBUcmVhdG1lbnQgRmVlOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRleHQtc2xhdGUtOTAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICDigrl7dG90YWxDb3N0LnRvTG9jYWxlU3RyaW5nKCl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlciB0ZXh0LXhzIHAtMy41IHJvdW5kZWQteGwgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTMwMCBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNzAwIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8Q3JlZGl0Q2FyZCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz4gMCUgRU1JIFBheW1lbnQ6XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ibGFjayB0ZXh0LWVtZXJhbGQtNzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICDigrl7bW9udGhseUVtaS50b0xvY2FsZVN0cmluZygpfSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LXNlbWlib2xkXCI+LyBtbzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIHRleHQtWzExcHhdIHRleHQtc2xhdGUtNzAwIGZvbnQtc2VtaWJvbGRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5aZXJvIFByb2Nlc3NpbmcgRmVlcyBvciBIaWRkZW4gQ2hhcmdlczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTYwMFwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+SW5zdGFudCBBcHByb3ZhbCB3aXRoIFN0YXIgLyBIREZDIEluc3VyYW5jZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk9wZW5Cb29raW5nKHNlbGVjdGVkUHJvY2VkdXJlKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTQgcHgtNCByb3VuZGVkLXhsIGZvbnQtZXh0cmFib2xkIHRleHQteHMgdGV4dC13aGl0ZSBiZy1ncmFkaWVudC10by1yIGZyb20tc2t5LTYwMCB0by10ZWFsLTYwMCBob3Zlcjpmcm9tLXNreS03MDAgaG92ZXI6dG8tdGVhbC03MDAgc2hhZG93LWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPENhbGVuZGFyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Mb2NrIEluIFRoaXMgRU1JIEVzdGltYXRlPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIC8qIFNZTVBUT00gQ0hFQ0tFUiBRVUlaICovXG4gICAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDEwIH19XG4gICAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLTN4bCBwLTYgc206cC04IGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHNoYWRvdy14bFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtxdWl6U3RlcCA8IGNvbmZpZy5zeW1wdG9tUXVpei5sZW5ndGggPyAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTYgbWF4LXctMnhsIG14LWF1dG9cIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+UXVlc3Rpb24ge3F1aXpTdGVwICsgMX0gb2Yge2NvbmZpZy5zeW1wdG9tUXVpei5sZW5ndGh9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1za3ktNjAwXCI+MzAtU2VjIERlbnRhbCBBc3Nlc3Nvcjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7Y29uZmlnLnN5bXB0b21RdWl6W3F1aXpTdGVwXS5xdWVzdGlvbn1cbiAgICAgICAgICAgICAgICAgIDwvaDM+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgICAgICAgIHtjb25maWcuc3ltcHRvbVF1aXpbcXVpelN0ZXBdLm9wdGlvbnMubWFwKChvcHQsIGkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVRdWl6QW5zd2VyKHF1aXpTdGVwLCBvcHQudGV4dCwgJ21hdGNoU2VydmljZScgaW4gb3B0ID8gb3B0Lm1hdGNoU2VydmljZSA6IHVuZGVmaW5lZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC00IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgYmctc2xhdGUtNTAgaG92ZXI6Ymctc2t5LTUwIGhvdmVyOmJvcmRlci1za3ktNTAwIHRleHQtbGVmdCBmb250LWJvbGQgdGV4dC1zbSB0ZXh0LXNsYXRlLTkwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdHJhbnNpdGlvbiBncm91cCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e29wdC50ZXh0fTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxBcnJvd1JpZ2h0IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1zbGF0ZS00MDAgZ3JvdXAtaG92ZXI6dGV4dC1za3ktNjAwIGdyb3VwLWhvdmVyOnRyYW5zbGF0ZS14LTEgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIC8qIFFVSVogUkVTVUxUIFJFQ09NTUVOREFUSU9OICovXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBzcGFjZS15LTYgbWF4LXcteGwgbXgtYXV0byBweS00XCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC0xMDAgdGV4dC1lbWVyYWxkLTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvIHNoYWRvdy1tZFwiPlxuICAgICAgICAgICAgICAgICAgICA8WmFwIGNsYXNzTmFtZT1cInctOCBoLThcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1leHRyYWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZW1lcmFsZC03MDAgYmctZW1lcmFsZC01MCBweC0zIHB5LTEgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICBBc3Nlc3NtZW50IENvbXBsZXRlXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYmxhY2sgdGV4dC1zbGF0ZS05MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICBSZWNvbW1lbmRlZCBQcm9jZWR1cmU6IHtjb25maWcuc2VydmljZXMuZmluZChzID0+IHMuaWQgPT09IHJlY29tbWVuZGVkU2VydmljZUlkKT8udGl0bGUgfHwgXCJTcGVjaWFsaXN0IERlbnRhbCBDb25zdWx0YXRpb25cIn1cbiAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTYwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIEJhc2VkIG9uIHlvdXIgaW5wdXRzLCBvdXIgY2xpbmljYWwgdGVhbSByZWNvbW1lbmRzIGFuIGluLXBlcnNvbiAzRCBzY2FuIGFuZCBwYWlubGVzcyBkaWFnbm9zdGljIHJldmlldy5cbiAgICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQtMnhsIGJnLXNreS01MCBib3JkZXIgYm9yZGVyLXNreS0yMDAgdGV4dC1sZWZ0IHRleHQteHMgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1za3ktOTAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNreS02MDBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIFdoYXQgaGFwcGVucyBhdCB5b3VyIGNvbnN1bHRhdGlvbjpcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTEgdGV4dC1zbGF0ZS03MDAgbGlzdC1kaXNjIGxpc3QtaW5zaWRlIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGxpPkZ1bGwgM0QgSW50cmFvcmFsIERpZ2l0YWwgU2Nhbm5pbmcgKE5vIGdhZ2dpbmcpPC9saT5cbiAgICAgICAgICAgICAgICAgICAgICA8bGk+UmV2aWV3IGJ5IFNlbmlvciBTcGVjaWFsaXN0IFN1cmdlb248L2xpPlxuICAgICAgICAgICAgICAgICAgICAgIDxsaT5UcmFuc3BhcmVudCBDb3N0ICYgMCUgRU1JIG9wdGlvbnMgcHJvdmlkZWQgYmVmb3JlaGFuZDwvbGk+XG4gICAgICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtyZXNldFF1aXp9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHktMyBweC00IHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgdGV4dC1zbGF0ZS03MDAgaG92ZXI6Ymctc2xhdGUtMTAwXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIFJldGFrZSBRdWl6XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25PcGVuQm9va2luZyhyZWNvbW1lbmRlZFNlcnZpY2VJZCB8fCB1bmRlZmluZWQpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweS0zLjUgcHgtNiByb3VuZGVkLXhsIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgYmctZ3JhZGllbnQtdG8tciBmcm9tLXNreS02MDAgdG8tdGVhbC02MDAgaG92ZXI6ZnJvbS1za3ktNzAwIGhvdmVyOnRvLXRlYWwtNzAwIHNoYWRvdy1sZyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiB0ZXh0LXhzIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxDYWxlbmRhciBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Cb29rIFJlY29tbWVuZGVkIFNsb3Q8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn07XG4iXX0=