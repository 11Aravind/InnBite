import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TrustMetrics.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=383ccf5c";
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=d79d3615";
import { Users, Award, Star, ShieldCheck, HeartPulse, Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=a18529f7";
import { useTheme } from "/src/context/ThemeContext.tsx";
import { DynamicIcon } from "/src/components/DynamicIcon.tsx";
var _jsxFileName = "D:/Aravind-Works/Dentel clinic/src/components/TrustMetrics.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=383ccf5c";
var _s = $RefreshSig$();
export const TrustMetrics = () => {
	_s();
	const { config } = useTheme();
	const metrics = [
		{
			id: "patients",
			label: "Satisfied Smiles Created",
			value: config.metrics.satisfiedPatients,
			subtext: "Across Kochi & NRI Patients",
			icon: Users,
			color: "text-sky-500"
		},
		{
			id: "experience",
			label: "Years of Clinical Excellence",
			value: config.metrics.yearsExperience,
			subtext: "Specialist Senior Surgeons",
			icon: Award,
			color: "text-teal-500"
		},
		{
			id: "rating",
			label: "Google Verified Rating",
			value: `${config.metrics.googleRating} ★`,
			subtext: `Based on ${config.metrics.reviewsCount} Reviews`,
			icon: Star,
			color: "text-amber-500"
		},
		{
			id: "painless",
			label: "Painless Surgery Accuracy",
			value: config.metrics.painlessSuccessRate,
			subtext: "Microscopic & Laser Guided",
			icon: HeartPulse,
			color: "text-emerald-500"
		}
	];
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "py-10 bg-slate-100/70 dark:bg-slate-900/50 border-y border-slate-200/80 dark:border-slate-800/80",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6",
				children: metrics.map((item, index) => {
					const Icon = item.icon;
					return /* @__PURE__ */ _jsxDEV(motion.div, {
						initial: {
							opacity: 0,
							y: 15
						},
						whileInView: {
							opacity: 1,
							y: 0
						},
						viewport: { once: true },
						transition: {
							duration: .4,
							delay: index * .1
						},
						className: "bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-200/90 dark:border-slate-700/80 shadow-sm hover:shadow-md transition",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between mb-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: `p-2.5 rounded-xl bg-slate-100 dark:bg-slate-900 ${item.color}`,
									children: /* @__PURE__ */ _jsxDEV(Icon, { className: "w-5 h-5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 64,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 63,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] font-bold uppercase tracking-wider text-slate-400",
									children: "Verified"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 66,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight",
								children: item.value
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 71,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-xs font-semibold text-slate-700 dark:text-slate-200 mt-1",
								children: item.label
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 74,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-[11px] text-slate-500 dark:text-slate-400 mt-0.5",
								children: item.subtext
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 77,
								columnNumber: 17
							}, this)
						]
					}, item.id, true, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 15
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "mt-8 flex flex-wrap items-center justify-center gap-6 sm:gap-10 text-xs font-medium text-slate-600 dark:text-slate-300",
				children: config.trustBadges.map((badge, idx) => /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(DynamicIcon, {
						name: badge.icon,
						className: "w-4 h-4 text-sky-500 flex-shrink-0"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: badge.title }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 15
					}, this)]
				}, idx, true, {
					fileName: _jsxFileName,
					lineNumber: 88,
					columnNumber: 13
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 86,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 47,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 46,
		columnNumber: 5
	}, this);
};
_s(TrustMetrics, "qQ7g6tIEyataPS75zVi2PFhrMqc=", false, function() {
	return [useTheme];
});
_c = TrustMetrics;
var _c;
$RefreshReg$(_c, "TrustMetrics");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/TrustMetrics.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Aravind-Works/Dentel clinic/src/components/TrustMetrics.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Aravind-Works/Dentel clinic/src/components/TrustMetrics.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Aravind-Works/Dentel clinic/src/components/TrustMetrics.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsY0FBYztBQUN2QixTQUFTLE9BQU8sT0FBTyxNQUFNLGFBQWEsWUFBWSxnQkFBZ0I7QUFDdEUsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxtQkFBbUI7Ozs7QUFFNUIsT0FBTyxNQUFNLHFCQUErQjs7Q0FDMUMsTUFBTSxFQUFFLFdBQVcsU0FBUztDQUU1QixNQUFNLFVBQVU7RUFDZDtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsT0FBTyxPQUFPLFFBQVE7R0FDdEIsU0FBUztHQUNULE1BQU07R0FDTixPQUFPO0VBQ1Q7RUFDQTtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsT0FBTyxPQUFPLFFBQVE7R0FDdEIsU0FBUztHQUNULE1BQU07R0FDTixPQUFPO0VBQ1Q7RUFDQTtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsT0FBTyxHQUFHLE9BQU8sUUFBUSxhQUFhO0dBQ3RDLFNBQVMsWUFBWSxPQUFPLFFBQVEsYUFBYTtHQUNqRCxNQUFNO0dBQ04sT0FBTztFQUNUO0VBQ0E7R0FDRSxJQUFJO0dBQ0osT0FBTztHQUNQLE9BQU8sT0FBTyxRQUFRO0dBQ3RCLFNBQVM7R0FDVCxNQUFNO0dBQ04sT0FBTztFQUNUO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQ2pCLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FHRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNaLFFBQVEsS0FBSyxNQUFNLFVBQVU7S0FDNUIsTUFBTSxPQUFPLEtBQUs7S0FDbEIsT0FDRSx3QkFBQyxPQUFPLEtBQVI7TUFFRSxTQUFTO09BQUUsU0FBUztPQUFHLEdBQUc7TUFBRztNQUM3QixhQUFhO09BQUUsU0FBUztPQUFHLEdBQUc7TUFBRTtNQUNoQyxVQUFVLEVBQUUsTUFBTSxLQUFLO01BQ3ZCLFlBQVk7T0FBRSxVQUFVO09BQUssT0FBTyxRQUFRO01BQUk7TUFDaEQsV0FBVTtnQkFOWjtPQVFFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVcsbURBQW1ELEtBQUs7bUJBQ3RFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLFVBQVc7Ozs7O1FBQ3hCOzs7O2tCQUNMLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFnRTtRQUUxRTs7OztnQkFDSDs7Ozs7O09BRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQ1osS0FBSztPQUNIOzs7OztPQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNaLEtBQUs7T0FDSDs7Ozs7T0FDTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWixLQUFLO09BQ0g7Ozs7O01BQ0s7UUF6QkwsS0FBSzs7OztZQXlCQTtJQUVoQixDQUFDO0dBQ0U7Ozs7YUFHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNaLE9BQU8sWUFBWSxLQUFLLE9BQU8sUUFDOUIsd0JBQUMsT0FBRDtLQUFlLFdBQVU7ZUFBekIsQ0FDRSx3QkFBQyxhQUFEO01BQWEsTUFBTSxNQUFNO01BQU0sV0FBVTtLQUFzQzs7OztlQUMvRSx3QkFBQyxRQUFELFlBQU8sTUFBTSxNQUFZOzs7O2FBQ3RCO09BSEs7Ozs7V0FHTCxDQUNOO0dBQ0U7Ozs7V0FFRjs7Ozs7O0NBQ0U7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiVHJ1c3RNZXRyaWNzLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgbW90aW9uIH0gZnJvbSAnZnJhbWVyLW1vdGlvbic7XG5pbXBvcnQgeyBVc2VycywgQXdhcmQsIFN0YXIsIFNoaWVsZENoZWNrLCBIZWFydFB1bHNlLCBTcGFya2xlcyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJ0AvY29udGV4dC9UaGVtZUNvbnRleHQnO1xuaW1wb3J0IHsgRHluYW1pY0ljb24gfSBmcm9tICdAL2NvbXBvbmVudHMvRHluYW1pY0ljb24nO1xuXG5leHBvcnQgY29uc3QgVHJ1c3RNZXRyaWNzOiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgY29uc3QgeyBjb25maWcgfSA9IHVzZVRoZW1lKCk7XG5cbiAgY29uc3QgbWV0cmljcyA9IFtcbiAgICB7XG4gICAgICBpZDogJ3BhdGllbnRzJyxcbiAgICAgIGxhYmVsOiAnU2F0aXNmaWVkIFNtaWxlcyBDcmVhdGVkJyxcbiAgICAgIHZhbHVlOiBjb25maWcubWV0cmljcy5zYXRpc2ZpZWRQYXRpZW50cyxcbiAgICAgIHN1YnRleHQ6ICdBY3Jvc3MgS29jaGkgJiBOUkkgUGF0aWVudHMnLFxuICAgICAgaWNvbjogVXNlcnMsXG4gICAgICBjb2xvcjogJ3RleHQtc2t5LTUwMCdcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiAnZXhwZXJpZW5jZScsXG4gICAgICBsYWJlbDogJ1llYXJzIG9mIENsaW5pY2FsIEV4Y2VsbGVuY2UnLFxuICAgICAgdmFsdWU6IGNvbmZpZy5tZXRyaWNzLnllYXJzRXhwZXJpZW5jZSxcbiAgICAgIHN1YnRleHQ6ICdTcGVjaWFsaXN0IFNlbmlvciBTdXJnZW9ucycsXG4gICAgICBpY29uOiBBd2FyZCxcbiAgICAgIGNvbG9yOiAndGV4dC10ZWFsLTUwMCdcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiAncmF0aW5nJyxcbiAgICAgIGxhYmVsOiAnR29vZ2xlIFZlcmlmaWVkIFJhdGluZycsXG4gICAgICB2YWx1ZTogYCR7Y29uZmlnLm1ldHJpY3MuZ29vZ2xlUmF0aW5nfSDimIVgLFxuICAgICAgc3VidGV4dDogYEJhc2VkIG9uICR7Y29uZmlnLm1ldHJpY3MucmV2aWV3c0NvdW50fSBSZXZpZXdzYCxcbiAgICAgIGljb246IFN0YXIsXG4gICAgICBjb2xvcjogJ3RleHQtYW1iZXItNTAwJ1xuICAgIH0sXG4gICAge1xuICAgICAgaWQ6ICdwYWlubGVzcycsXG4gICAgICBsYWJlbDogJ1BhaW5sZXNzIFN1cmdlcnkgQWNjdXJhY3knLFxuICAgICAgdmFsdWU6IGNvbmZpZy5tZXRyaWNzLnBhaW5sZXNzU3VjY2Vzc1JhdGUsXG4gICAgICBzdWJ0ZXh0OiAnTWljcm9zY29waWMgJiBMYXNlciBHdWlkZWQnLFxuICAgICAgaWNvbjogSGVhcnRQdWxzZSxcbiAgICAgIGNvbG9yOiAndGV4dC1lbWVyYWxkLTUwMCdcbiAgICB9XG4gIF07XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJweS0xMCBiZy1zbGF0ZS0xMDAvNzAgZGFyazpiZy1zbGF0ZS05MDAvNTAgYm9yZGVyLXkgYm9yZGVyLXNsYXRlLTIwMC84MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAvODBcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctN3hsIG14LWF1dG8gcHgtNCBzbTpweC02IGxnOnB4LThcIj5cbiAgICAgICAgXG4gICAgICAgIHsvKiBTdGF0aXN0aWNzIENhcmRzIEdyaWQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtNCBnYXAtNCBzbTpnYXAtNlwiPlxuICAgICAgICAgIHttZXRyaWNzLm1hcCgoaXRlbSwgaW5kZXgpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IEljb24gPSBpdGVtLmljb247XG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cbiAgICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDE1IH19XG4gICAgICAgICAgICAgICAgd2hpbGVJblZpZXc9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxuICAgICAgICAgICAgICAgIHZpZXdwb3J0PXt7IG9uY2U6IHRydWUgfX1cbiAgICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjQsIGRlbGF5OiBpbmRleCAqIDAuMSB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHAtNSByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC85MCBkYXJrOmJvcmRlci1zbGF0ZS03MDAvODAgc2hhZG93LXNtIGhvdmVyOnNoYWRvdy1tZCB0cmFuc2l0aW9uXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIG1iLTNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgcC0yLjUgcm91bmRlZC14bCBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS05MDAgJHtpdGVtLmNvbG9yfWB9PlxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAgICBWZXJpZmllZFxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBzbTp0ZXh0LTN4bCBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj5cbiAgICAgICAgICAgICAgICAgIHtpdGVtLnZhbHVlfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0yMDAgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAge2l0ZW0ubGFiZWx9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwIG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAge2l0ZW0uc3VidGV4dH1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9KX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIENlcnRpZmljYXRpb25zIEJhciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtNiBzbTpnYXAtMTAgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAge2NvbmZpZy50cnVzdEJhZGdlcy5tYXAoKGJhZGdlLCBpZHgpID0+IChcbiAgICAgICAgICAgIDxkaXYga2V5PXtpZHh9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxEeW5hbWljSWNvbiBuYW1lPXtiYWRnZS5pY29ufSBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2t5LTUwMCBmbGV4LXNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+e2JhZGdlLnRpdGxlfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgPC9kaXY+XG4gICAgPC9zZWN0aW9uPlxuICApO1xufTtcbiJdfQ==