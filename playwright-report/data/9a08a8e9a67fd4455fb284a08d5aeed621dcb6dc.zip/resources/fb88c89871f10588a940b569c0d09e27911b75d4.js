import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PricingInsuranceSection.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=383ccf5c";
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=d79d3615";
import { Check, Flame, CreditCard, ShieldCheck, Calendar, ArrowRight } from "/node_modules/.vite/deps/lucide-react.js?v=a18529f7";
import { useTheme } from "/src/context/ThemeContext.tsx";
var _jsxFileName = "D:/Aravind-Works/Dentel clinic/src/components/PricingInsuranceSection.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=383ccf5c";
var _s = $RefreshSig$();
export const PricingInsuranceSection = ({ onOpenBooking }) => {
	_s();
	const { config } = useTheme();
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "py-20 bg-slate-100/70 dark:bg-slate-900/50 relative",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "text-center max-w-3xl mx-auto space-y-3",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-100 dark:bg-teal-950/80 text-teal-800 dark:text-teal-300 text-xs font-bold uppercase tracking-wider",
							children: [/* @__PURE__ */ _jsxDEV(CreditCard, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 20,
								columnNumber: 13
							}, this), "Transparent Investment & Coverage"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 19,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight",
							children: ["Popular All-Inclusive ", /* @__PURE__ */ _jsxDEV("span", {
								className: "text-gradient",
								children: "Studio Packages"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 24,
								columnNumber: 35
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 23,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-slate-600 dark:text-slate-300 text-sm sm:text-base",
							children: "No unexpected add-ons or hidden charges. Pay upfront or choose 0% interest EMI options."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 26,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 18,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-12 grid grid-cols-1 md:grid-cols-3 gap-8",
					children: config.pricingPlans.map((plan) => /* @__PURE__ */ _jsxDEV(motion.div, {
						initial: {
							opacity: 0,
							y: 20
						},
						whileInView: {
							opacity: 1,
							y: 0
						},
						viewport: { once: true },
						transition: { duration: .4 },
						className: `glass-card rounded-3xl p-6 sm:p-8 relative flex flex-col justify-between border ${plan.popular ? "border-sky-500 ring-2 ring-sky-500/20 shadow-2xl scale-102" : "border-slate-200/90 dark:border-slate-800"}`,
						children: [
							plan.popular && /* @__PURE__ */ _jsxDEV("span", {
								className: "absolute -top-3.5 left-1/2 -translate-x-1/2 bg-gradient-to-r from-sky-500 to-teal-500 text-white font-extrabold text-[10px] uppercase tracking-wider px-3.5 py-1 rounded-full shadow-md flex items-center gap-1",
								children: [/* @__PURE__ */ _jsxDEV(Flame, { className: "w-3 h-3" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 48,
									columnNumber: 19
								}, this), " Most Recommended"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 47,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-6",
								children: [
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] font-bold uppercase tracking-wider text-sky-500",
										children: plan.category
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 54,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("h3", {
										className: "text-xl font-bold text-slate-900 dark:text-white mt-1",
										children: plan.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 57,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 53,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "space-y-1",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-baseline gap-2",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white",
												children: plan.price
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 65,
												columnNumber: 21
											}, this), plan.originalPrice && /* @__PURE__ */ _jsxDEV("span", {
												className: "text-sm font-semibold text-slate-400 line-through",
												children: plan.originalPrice
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 69,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 64,
											columnNumber: 19
										}, this), plan.emiAvailable && plan.emiStartingAt && /* @__PURE__ */ _jsxDEV("div", {
											className: "text-xs font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1",
											children: [/* @__PURE__ */ _jsxDEV(CreditCard, { className: "w-3.5 h-3.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 77,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: plan.emiStartingAt }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 78,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 76,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 63,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ _jsxDEV("ul", {
										className: "space-y-2.5 pt-4 border-t border-slate-100 dark:border-slate-800",
										children: plan.features.map((feat, idx) => /* @__PURE__ */ _jsxDEV("li", {
											className: "flex items-start gap-2.5 text-xs text-slate-600 dark:text-slate-300",
											children: [/* @__PURE__ */ _jsxDEV(Check, { className: "w-4 h-4 text-emerald-500 flex-shrink-0 mt-0.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 87,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: feat }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 88,
												columnNumber: 23
											}, this)]
										}, idx, true, {
											fileName: _jsxFileName,
											lineNumber: 86,
											columnNumber: 21
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 84,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 52,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "pt-6",
								children: /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => onOpenBooking(),
									className: `w-full py-3.5 px-4 rounded-xl font-bold text-xs shadow-md flex items-center justify-center gap-2 cursor-pointer transition ${plan.popular ? "bg-gradient-to-r from-sky-500 to-teal-500 hover:from-sky-600 hover:to-teal-600 text-white" : "bg-slate-900 hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 text-white"}`,
									children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 104,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Book Package Now" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 105,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 96,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 15
							}, this)
						]
					}, plan.id, true, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-16 bg-white dark:bg-slate-800 rounded-3xl p-8 border border-slate-200 dark:border-slate-700 shadow-md",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "text-center max-w-xl mx-auto space-y-2",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-bold uppercase tracking-wider text-sky-500",
								children: "Cashless & Reimbursement Support"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 115,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-xl font-bold text-slate-900 dark:text-white",
								children: "Accepted Health Insurance Partners"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 118,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 dark:text-slate-400",
								children: "We assist with direct cashless claims & official clinical tax receipt documentation."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 121,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 114,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "mt-8 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4",
						children: config.insurancePartners.map((partner, idx) => /* @__PURE__ */ _jsxDEV("div", {
							className: "p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-center font-bold text-xs text-slate-700 dark:text-slate-300 flex items-center justify-center",
							children: partner.name
						}, idx, false, {
							fileName: _jsxFileName,
							lineNumber: 128,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 113,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 5
	}, this);
};
_s(PricingInsuranceSection, "qQ7g6tIEyataPS75zVi2PFhrMqc=", false, function() {
	return [useTheme];
});
_c = PricingInsuranceSection;
var _c;
$RefreshReg$(_c, "PricingInsuranceSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/PricingInsuranceSection.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Aravind-Works/Dentel clinic/src/components/PricingInsuranceSection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Aravind-Works/Dentel clinic/src/components/PricingInsuranceSection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Aravind-Works/Dentel clinic/src/components/PricingInsuranceSection.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsY0FBYztBQUN2QixTQUFTLE9BQU8sT0FBTyxZQUFZLGFBQWEsVUFBVSxrQkFBa0I7QUFDNUUsU0FBUyxnQkFBZ0I7Ozs7QUFNekIsT0FBTyxNQUFNLDJCQUFtRSxFQUFFLG9CQUFvQjs7Q0FDcEcsTUFBTSxFQUFFLFdBQVcsU0FBUztDQUU1QixPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQ2pCLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFHRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxZQUFELEVBQVksV0FBVSxjQUFlOzs7O2lCQUFDLG1DQUVuQzs7Ozs7O01BQ0wsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQsQ0FBa0csMEJBQzFFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFnQjtPQUFxQjs7OztlQUN6RTs7Ozs7O01BQ0osd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQTBEO01BRXBFOzs7OztLQUNBOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLE9BQU8sYUFBYSxLQUFLLFNBQ3hCLHdCQUFDLE9BQU8sS0FBUjtNQUVFLFNBQVM7T0FBRSxTQUFTO09BQUcsR0FBRztNQUFHO01BQzdCLGFBQWE7T0FBRSxTQUFTO09BQUcsR0FBRztNQUFFO01BQ2hDLFVBQVUsRUFBRSxNQUFNLEtBQUs7TUFDdkIsWUFBWSxFQUFFLFVBQVUsR0FBSTtNQUM1QixXQUFXLG1GQUNULEtBQUssVUFDRCwrREFDQTtnQkFUUjtPQVlHLEtBQUssV0FDSix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEIsQ0FDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSxVQUFXOzs7O2tCQUFDLG1CQUN6Qjs7Ozs7O09BR1Isd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQ2IsS0FBSztTQUNGOzs7O21CQUNOLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNYLEtBQUs7U0FDSjs7OztpQkFDRDs7Ozs7U0FHTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQ2IsS0FBSztXQUNGOzs7O3FCQUNMLEtBQUssaUJBQ0osd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQ2IsS0FBSztXQUNGOzs7O21CQUVMOzs7OztvQkFFSixLQUFLLGdCQUFnQixLQUFLLGlCQUN6Qix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFlBQUQsRUFBWSxXQUFVLGNBQWU7Ozs7cUJBQ3JDLHdCQUFDLFFBQUQsWUFBTyxLQUFLLGNBQW9COzs7O21CQUM3Qjs7Ozs7a0JBRUo7Ozs7OztTQUdMLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUNYLEtBQUssU0FBUyxLQUFLLE1BQU0sUUFDeEIsd0JBQUMsTUFBRDtXQUFjLFdBQVU7cUJBQXhCLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsZ0RBQWlEOzs7O3FCQUNsRSx3QkFBQyxRQUFELFlBQU8sS0FBVzs7OzttQkFDaEI7YUFISzs7OztpQkFHTCxDQUNMO1NBQ0M7Ozs7O1FBQ0Q7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLFVBQUQ7U0FDRSxlQUFlLGNBQWM7U0FDN0IsV0FBVyw4SEFDVCxLQUFLLFVBQ0QsOEZBQ0E7bUJBTFIsQ0FRRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7O21CQUMvQix3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7O2lCQUN0Qjs7Ozs7O09BQ0w7Ozs7O01BQ0s7UUF6RUwsS0FBSzs7OztZQXlFQSxDQUNiO0lBQ0U7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTBEO09BRXBFOzs7OztPQUNOLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFtRDtPQUU3RDs7Ozs7T0FDSix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBNkM7T0FFdkQ7Ozs7O01BQ0E7Ozs7O2VBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1osT0FBTyxrQkFBa0IsS0FBSyxTQUFTLFFBQ3RDLHdCQUFDLE9BQUQ7T0FFRSxXQUFVO2lCQUVULFFBQVE7TUFDTixHQUpFOzs7O2FBSUYsQ0FDTjtLQUNFOzs7O2FBQ0Y7Ozs7OztHQUVGOzs7Ozs7Q0FDRTs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQcmljaW5nSW5zdXJhbmNlU2VjdGlvbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IG1vdGlvbiB9IGZyb20gJ2ZyYW1lci1tb3Rpb24nO1xuaW1wb3J0IHsgQ2hlY2ssIEZsYW1lLCBDcmVkaXRDYXJkLCBTaGllbGRDaGVjaywgQ2FsZW5kYXIsIEFycm93UmlnaHQgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICdAL2NvbnRleHQvVGhlbWVDb250ZXh0JztcblxuaW50ZXJmYWNlIFByaWNpbmdJbnN1cmFuY2VTZWN0aW9uUHJvcHMge1xuICBvbk9wZW5Cb29raW5nOiAoc2VydmljZUlkPzogc3RyaW5nKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgUHJpY2luZ0luc3VyYW5jZVNlY3Rpb246IFJlYWN0LkZDPFByaWNpbmdJbnN1cmFuY2VTZWN0aW9uUHJvcHM+ID0gKHsgb25PcGVuQm9va2luZyB9KSA9PiB7XG4gIGNvbnN0IHsgY29uZmlnIH0gPSB1c2VUaGVtZSgpO1xuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicHktMjAgYmctc2xhdGUtMTAwLzcwIGRhcms6Ymctc2xhdGUtOTAwLzUwIHJlbGF0aXZlXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTd4bCBteC1hdXRvIHB4LTQgc206cHgtNiBsZzpweC04XCI+XG4gICAgICAgIFxuICAgICAgICB7LyogU2VjdGlvbiBIZWFkZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgbWF4LXctM3hsIG14LWF1dG8gc3BhY2UteS0zXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCBiZy10ZWFsLTEwMCBkYXJrOmJnLXRlYWwtOTUwLzgwIHRleHQtdGVhbC04MDAgZGFyazp0ZXh0LXRlYWwtMzAwIHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgPENyZWRpdENhcmQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgVHJhbnNwYXJlbnQgSW52ZXN0bWVudCAmIENvdmVyYWdlXG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtM3hsIHNtOnRleHQtNHhsIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSB0cmFja2luZy10aWdodFwiPlxuICAgICAgICAgICAgUG9wdWxhciBBbGwtSW5jbHVzaXZlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JhZGllbnRcIj5TdHVkaW8gUGFja2FnZXM8L3NwYW4+XG4gICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHRleHQtc20gc206dGV4dC1iYXNlXCI+XG4gICAgICAgICAgICBObyB1bmV4cGVjdGVkIGFkZC1vbnMgb3IgaGlkZGVuIGNoYXJnZXMuIFBheSB1cGZyb250IG9yIGNob29zZSAwJSBpbnRlcmVzdCBFTUkgb3B0aW9ucy5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBQcmljaW5nIENhcmRzIEdyaWQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTIgZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtOFwiPlxuICAgICAgICAgIHtjb25maWcucHJpY2luZ1BsYW5zLm1hcCgocGxhbikgPT4gKFxuICAgICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgICAga2V5PXtwbGFuLmlkfVxuICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDIwIH19XG4gICAgICAgICAgICAgIHdoaWxlSW5WaWV3PXt7IG9wYWNpdHk6IDEsIHk6IDAgfX1cbiAgICAgICAgICAgICAgdmlld3BvcnQ9e3sgb25jZTogdHJ1ZSB9fVxuICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjQgfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgZ2xhc3MtY2FyZCByb3VuZGVkLTN4bCBwLTYgc206cC04IHJlbGF0aXZlIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIGJvcmRlciAke1xuICAgICAgICAgICAgICAgIHBsYW4ucG9wdWxhciBcbiAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1za3ktNTAwIHJpbmctMiByaW5nLXNreS01MDAvMjAgc2hhZG93LTJ4bCBzY2FsZS0xMDInIFxuICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXNsYXRlLTIwMC85MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAnXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7cGxhbi5wb3B1bGFyICYmIChcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtdG9wLTMuNSBsZWZ0LTEvMiAtdHJhbnNsYXRlLXgtMS8yIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1za3ktNTAwIHRvLXRlYWwtNTAwIHRleHQtd2hpdGUgZm9udC1leHRyYWJvbGQgdGV4dC1bMTBweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHB4LTMuNSBweS0xIHJvdW5kZWQtZnVsbCBzaGFkb3ctbWQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgIDxGbGFtZSBjbGFzc05hbWU9XCJ3LTMgaC0zXCIgLz4gTW9zdCBSZWNvbW1lbmRlZFxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2t5LTUwMFwiPlxuICAgICAgICAgICAgICAgICAgICB7cGxhbi5jYXRlZ29yeX1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICB7cGxhbi5uYW1lfVxuICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBQcmljZSBEaXNwbGF5ICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtYmFzZWxpbmUgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0zeGwgc206dGV4dC00eGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAge3BsYW4ucHJpY2V9XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAge3BsYW4ub3JpZ2luYWxQcmljZSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNDAwIGxpbmUtdGhyb3VnaFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAge3BsYW4ub3JpZ2luYWxQcmljZX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAge3BsYW4uZW1pQXZhaWxhYmxlICYmIHBsYW4uZW1pU3RhcnRpbmdBdCAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtZW1lcmFsZC02MDAgZGFyazp0ZXh0LWVtZXJhbGQtNDAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPENyZWRpdENhcmQgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntwbGFuLmVtaVN0YXJ0aW5nQXR9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogRmVhdHVyZSBMaXN0ICovfVxuICAgICAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTIuNSBwdC00IGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICB7cGxhbi5mZWF0dXJlcy5tYXAoKGZlYXQsIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8bGkga2V5PXtpZHh9IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQgZ2FwLTIuNSB0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNTAwIGZsZXgtc2hyaW5rLTAgbXQtMC41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57ZmVhdH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogQWN0aW9uICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTZcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk9wZW5Cb29raW5nKCl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2B3LWZ1bGwgcHktMy41IHB4LTQgcm91bmRlZC14bCBmb250LWJvbGQgdGV4dC14cyBzaGFkb3ctbWQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXIgdHJhbnNpdGlvbiAke1xuICAgICAgICAgICAgICAgICAgICBwbGFuLnBvcHVsYXJcbiAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1ncmFkaWVudC10by1yIGZyb20tc2t5LTUwMCB0by10ZWFsLTUwMCBob3Zlcjpmcm9tLXNreS02MDAgaG92ZXI6dG8tdGVhbC02MDAgdGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05MDAgaG92ZXI6Ymctc2xhdGUtODAwIGRhcms6Ymctc2xhdGUtODAwIGRhcms6aG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5Cb29rIFBhY2thZ2UgTm93PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEluc3VyYW5jZSBQYXJ0bmVycyBTZWN0aW9uICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTE2IGJnLXdoaXRlIGRhcms6Ymctc2xhdGUtODAwIHJvdW5kZWQtM3hsIHAtOCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgc2hhZG93LW1kXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBtYXgtdy14bCBteC1hdXRvIHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2t5LTUwMFwiPlxuICAgICAgICAgICAgICBDYXNobGVzcyAmIFJlaW1idXJzZW1lbnQgU3VwcG9ydFxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICBBY2NlcHRlZCBIZWFsdGggSW5zdXJhbmNlIFBhcnRuZXJzXG4gICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgIFdlIGFzc2lzdCB3aXRoIGRpcmVjdCBjYXNobGVzcyBjbGFpbXMgJiBvZmZpY2lhbCBjbGluaWNhbCB0YXggcmVjZWlwdCBkb2N1bWVudGF0aW9uLlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IGdyaWQgZ3JpZC1jb2xzLTIgc206Z3JpZC1jb2xzLTMgbGc6Z3JpZC1jb2xzLTYgZ2FwLTRcIj5cbiAgICAgICAgICAgIHtjb25maWcuaW5zdXJhbmNlUGFydG5lcnMubWFwKChwYXJ0bmVyLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGtleT17aWR4fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtNCByb3VuZGVkLXhsIGJnLXNsYXRlLTUwIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTcwMCB0ZXh0LWNlbnRlciBmb250LWJvbGQgdGV4dC14cyB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtwYXJ0bmVyLm5hbWV9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICA8L2Rpdj5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59O1xuIl19