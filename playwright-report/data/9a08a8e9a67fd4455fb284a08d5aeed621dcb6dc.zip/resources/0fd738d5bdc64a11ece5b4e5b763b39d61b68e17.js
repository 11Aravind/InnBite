import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/context/ThemeContext.tsx");const React = __vite__cjsImport0_react; const createContext = __vite__cjsImport0_react["createContext"]; const useContext = __vite__cjsImport0_react["useContext"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=383ccf5c";
import { clinicConfig } from "/src/config/siteConfig.ts";
var _jsxFileName = "D:/Aravind-Works/Dentel clinic/src/context/ThemeContext.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=383ccf5c";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const ThemeContext = createContext(undefined);
_c = ThemeContext;
export const ThemeProvider = ({ children }) => {
	_s();
	const [mode, setMode] = useState("light");
	useEffect(() => {
		// Inject CSS variable roots from clinicConfig.theme
		const root = document.documentElement;
		const t = clinicConfig.theme;
		if (mode === "dark") {
			root.classList.add("dark");
			root.style.setProperty("--color-primary", t.primary);
			root.style.setProperty("--color-primary-hover", t.primaryHover);
			root.style.setProperty("--color-secondary", t.secondary);
			root.style.setProperty("--color-accent", t.accent);
			root.style.setProperty("--color-bg", t.darkBackground);
			root.style.setProperty("--color-surface", t.darkSurface);
			root.style.setProperty("--color-text-main", t.darkTextPrimary);
			root.style.setProperty("--color-text-muted", t.darkTextSecondary);
			root.style.setProperty("--color-border", t.darkBorder);
		} else {
			root.classList.remove("dark");
			root.style.setProperty("--color-primary", t.primary);
			root.style.setProperty("--color-primary-hover", t.primaryHover);
			root.style.setProperty("--color-secondary", t.secondary);
			root.style.setProperty("--color-accent", t.accent);
			root.style.setProperty("--color-bg", t.background);
			root.style.setProperty("--color-surface", t.surface);
			root.style.setProperty("--color-text-main", t.textPrimary);
			root.style.setProperty("--color-text-muted", t.textSecondary);
			root.style.setProperty("--color-border", t.border);
		}
	}, [mode]);
	const toggleTheme = () => {
		setMode((prev) => prev === "light" ? "dark" : "light");
	};
	return /* @__PURE__ */ _jsxDEV(ThemeContext.Provider, {
		value: {
			mode,
			toggleTheme,
			config: clinicConfig
		},
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 52,
		columnNumber: 5
	}, this);
};
_s(ThemeProvider, "Rj8DZAwi2xbxHzfSCwPnO26Yidk=");
_c2 = ThemeProvider;
export const useTheme = () => {
	_s2();
	const context = useContext(ThemeContext);
	if (!context) {
		throw new Error("useTheme must be used within a ThemeProvider");
	}
	return context;
};
_s2(useTheme, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c, _c2;
$RefreshReg$(_c, "ThemeContext");
$RefreshReg$(_c2, "ThemeProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/context/ThemeContext.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Aravind-Works/Dentel clinic/src/context/ThemeContext.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Aravind-Works/Dentel clinic/src/context/ThemeContext.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Aravind-Works/Dentel clinic/src/context/ThemeContext.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGVBQWUsWUFBWSxXQUFXLGdCQUFnQjtBQUN0RSxTQUFTLG9CQUFvQjs7OztBQVU3QixNQUFNLGVBQWUsY0FBNEMsU0FBUzs7QUFFMUUsT0FBTyxNQUFNLGlCQUEwRCxFQUFFLGVBQWU7O0NBQ3RGLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBb0IsT0FBTztDQUVuRCxnQkFBZ0I7O0VBRWQsTUFBTSxPQUFPLFNBQVM7RUFDdEIsTUFBTSxJQUFJLGFBQWE7RUFFdkIsSUFBSSxTQUFTLFFBQVE7R0FDbkIsS0FBSyxVQUFVLElBQUksTUFBTTtHQUN6QixLQUFLLE1BQU0sWUFBWSxtQkFBbUIsRUFBRSxPQUFPO0dBQ25ELEtBQUssTUFBTSxZQUFZLHlCQUF5QixFQUFFLFlBQVk7R0FDOUQsS0FBSyxNQUFNLFlBQVkscUJBQXFCLEVBQUUsU0FBUztHQUN2RCxLQUFLLE1BQU0sWUFBWSxrQkFBa0IsRUFBRSxNQUFNO0dBQ2pELEtBQUssTUFBTSxZQUFZLGNBQWMsRUFBRSxjQUFjO0dBQ3JELEtBQUssTUFBTSxZQUFZLG1CQUFtQixFQUFFLFdBQVc7R0FDdkQsS0FBSyxNQUFNLFlBQVkscUJBQXFCLEVBQUUsZUFBZTtHQUM3RCxLQUFLLE1BQU0sWUFBWSxzQkFBc0IsRUFBRSxpQkFBaUI7R0FDaEUsS0FBSyxNQUFNLFlBQVksa0JBQWtCLEVBQUUsVUFBVTtFQUN2RCxPQUFPO0dBQ0wsS0FBSyxVQUFVLE9BQU8sTUFBTTtHQUM1QixLQUFLLE1BQU0sWUFBWSxtQkFBbUIsRUFBRSxPQUFPO0dBQ25ELEtBQUssTUFBTSxZQUFZLHlCQUF5QixFQUFFLFlBQVk7R0FDOUQsS0FBSyxNQUFNLFlBQVkscUJBQXFCLEVBQUUsU0FBUztHQUN2RCxLQUFLLE1BQU0sWUFBWSxrQkFBa0IsRUFBRSxNQUFNO0dBQ2pELEtBQUssTUFBTSxZQUFZLGNBQWMsRUFBRSxVQUFVO0dBQ2pELEtBQUssTUFBTSxZQUFZLG1CQUFtQixFQUFFLE9BQU87R0FDbkQsS0FBSyxNQUFNLFlBQVkscUJBQXFCLEVBQUUsV0FBVztHQUN6RCxLQUFLLE1BQU0sWUFBWSxzQkFBc0IsRUFBRSxhQUFhO0dBQzVELEtBQUssTUFBTSxZQUFZLGtCQUFrQixFQUFFLE1BQU07RUFDbkQ7Q0FDRixHQUFHLENBQUMsSUFBSSxDQUFDO0NBRVQsTUFBTSxvQkFBb0I7RUFDeEIsU0FBUyxTQUFVLFNBQVMsVUFBVSxTQUFTLE9BQVE7Q0FDekQ7Q0FFQSxPQUNFLHdCQUFDLGFBQWEsVUFBZDtFQUF1QixPQUFPO0dBQUU7R0FBTTtHQUFhLFFBQVE7RUFBYTtFQUNyRTtDQUNvQjs7Ozs7QUFFM0I7OztBQUVBLE9BQU8sTUFBTSxpQkFBaUI7O0NBQzVCLE1BQU0sVUFBVSxXQUFXLFlBQVk7Q0FDdkMsSUFBSSxDQUFDLFNBQVM7RUFDWixNQUFNLElBQUksTUFBTSw4Q0FBOEM7Q0FDaEU7Q0FDQSxPQUFPO0FBQ1QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiVGhlbWVDb250ZXh0LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCwgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGNsaW5pY0NvbmZpZyB9IGZyb20gJ0AvY29uZmlnL3NpdGVDb25maWcnO1xuXG50eXBlIFRoZW1lTW9kZSA9ICdsaWdodCcgfCAnZGFyayc7XG5cbmludGVyZmFjZSBUaGVtZUNvbnRleHRUeXBlIHtcbiAgbW9kZTogVGhlbWVNb2RlO1xuICB0b2dnbGVUaGVtZTogKCkgPT4gdm9pZDtcbiAgY29uZmlnOiB0eXBlb2YgY2xpbmljQ29uZmlnO1xufVxuXG5jb25zdCBUaGVtZUNvbnRleHQgPSBjcmVhdGVDb250ZXh0PFRoZW1lQ29udGV4dFR5cGUgfCB1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XG5cbmV4cG9ydCBjb25zdCBUaGVtZVByb3ZpZGVyOiBSZWFjdC5GQzx7IGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGUgfT4gPSAoeyBjaGlsZHJlbiB9KSA9PiB7XG4gIGNvbnN0IFttb2RlLCBzZXRNb2RlXSA9IHVzZVN0YXRlPFRoZW1lTW9kZT4oJ2xpZ2h0Jyk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICAvLyBJbmplY3QgQ1NTIHZhcmlhYmxlIHJvb3RzIGZyb20gY2xpbmljQ29uZmlnLnRoZW1lXG4gICAgY29uc3Qgcm9vdCA9IGRvY3VtZW50LmRvY3VtZW50RWxlbWVudDtcbiAgICBjb25zdCB0ID0gY2xpbmljQ29uZmlnLnRoZW1lO1xuXG4gICAgaWYgKG1vZGUgPT09ICdkYXJrJykge1xuICAgICAgcm9vdC5jbGFzc0xpc3QuYWRkKCdkYXJrJyk7XG4gICAgICByb290LnN0eWxlLnNldFByb3BlcnR5KCctLWNvbG9yLXByaW1hcnknLCB0LnByaW1hcnkpO1xuICAgICAgcm9vdC5zdHlsZS5zZXRQcm9wZXJ0eSgnLS1jb2xvci1wcmltYXJ5LWhvdmVyJywgdC5wcmltYXJ5SG92ZXIpO1xuICAgICAgcm9vdC5zdHlsZS5zZXRQcm9wZXJ0eSgnLS1jb2xvci1zZWNvbmRhcnknLCB0LnNlY29uZGFyeSk7XG4gICAgICByb290LnN0eWxlLnNldFByb3BlcnR5KCctLWNvbG9yLWFjY2VudCcsIHQuYWNjZW50KTtcbiAgICAgIHJvb3Quc3R5bGUuc2V0UHJvcGVydHkoJy0tY29sb3ItYmcnLCB0LmRhcmtCYWNrZ3JvdW5kKTtcbiAgICAgIHJvb3Quc3R5bGUuc2V0UHJvcGVydHkoJy0tY29sb3Itc3VyZmFjZScsIHQuZGFya1N1cmZhY2UpO1xuICAgICAgcm9vdC5zdHlsZS5zZXRQcm9wZXJ0eSgnLS1jb2xvci10ZXh0LW1haW4nLCB0LmRhcmtUZXh0UHJpbWFyeSk7XG4gICAgICByb290LnN0eWxlLnNldFByb3BlcnR5KCctLWNvbG9yLXRleHQtbXV0ZWQnLCB0LmRhcmtUZXh0U2Vjb25kYXJ5KTtcbiAgICAgIHJvb3Quc3R5bGUuc2V0UHJvcGVydHkoJy0tY29sb3ItYm9yZGVyJywgdC5kYXJrQm9yZGVyKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcm9vdC5jbGFzc0xpc3QucmVtb3ZlKCdkYXJrJyk7XG4gICAgICByb290LnN0eWxlLnNldFByb3BlcnR5KCctLWNvbG9yLXByaW1hcnknLCB0LnByaW1hcnkpO1xuICAgICAgcm9vdC5zdHlsZS5zZXRQcm9wZXJ0eSgnLS1jb2xvci1wcmltYXJ5LWhvdmVyJywgdC5wcmltYXJ5SG92ZXIpO1xuICAgICAgcm9vdC5zdHlsZS5zZXRQcm9wZXJ0eSgnLS1jb2xvci1zZWNvbmRhcnknLCB0LnNlY29uZGFyeSk7XG4gICAgICByb290LnN0eWxlLnNldFByb3BlcnR5KCctLWNvbG9yLWFjY2VudCcsIHQuYWNjZW50KTtcbiAgICAgIHJvb3Quc3R5bGUuc2V0UHJvcGVydHkoJy0tY29sb3ItYmcnLCB0LmJhY2tncm91bmQpO1xuICAgICAgcm9vdC5zdHlsZS5zZXRQcm9wZXJ0eSgnLS1jb2xvci1zdXJmYWNlJywgdC5zdXJmYWNlKTtcbiAgICAgIHJvb3Quc3R5bGUuc2V0UHJvcGVydHkoJy0tY29sb3ItdGV4dC1tYWluJywgdC50ZXh0UHJpbWFyeSk7XG4gICAgICByb290LnN0eWxlLnNldFByb3BlcnR5KCctLWNvbG9yLXRleHQtbXV0ZWQnLCB0LnRleHRTZWNvbmRhcnkpO1xuICAgICAgcm9vdC5zdHlsZS5zZXRQcm9wZXJ0eSgnLS1jb2xvci1ib3JkZXInLCB0LmJvcmRlcik7XG4gICAgfVxuICB9LCBbbW9kZV0pO1xuXG4gIGNvbnN0IHRvZ2dsZVRoZW1lID0gKCkgPT4ge1xuICAgIHNldE1vZGUoKHByZXYpID0+IChwcmV2ID09PSAnbGlnaHQnID8gJ2RhcmsnIDogJ2xpZ2h0JykpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPFRoZW1lQ29udGV4dC5Qcm92aWRlciB2YWx1ZT17eyBtb2RlLCB0b2dnbGVUaGVtZSwgY29uZmlnOiBjbGluaWNDb25maWcgfX0+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9UaGVtZUNvbnRleHQuUHJvdmlkZXI+XG4gICk7XG59O1xuXG5leHBvcnQgY29uc3QgdXNlVGhlbWUgPSAoKSA9PiB7XG4gIGNvbnN0IGNvbnRleHQgPSB1c2VDb250ZXh0KFRoZW1lQ29udGV4dCk7XG4gIGlmICghY29udGV4dCkge1xuICAgIHRocm93IG5ldyBFcnJvcigndXNlVGhlbWUgbXVzdCBiZSB1c2VkIHdpdGhpbiBhIFRoZW1lUHJvdmlkZXInKTtcbiAgfVxuICByZXR1cm4gY29udGV4dDtcbn07XG4iXX0=