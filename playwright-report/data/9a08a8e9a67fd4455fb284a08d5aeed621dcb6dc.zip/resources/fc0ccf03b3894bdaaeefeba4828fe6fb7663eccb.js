export const clinicConfig = {
	name: "ApexCare Dental Studio",
	tagline: "Precision Dentistry, Designed For Your Smile",
	subtagline: "Experience painless, laser-assisted dental care & 3D smile transformations in a luxurious, serene studio environment.",
	logo: {
		text: "ApexCare",
		icon: "Sparkles",
		subtext: "Dental & Implantology Studio"
	},
	theme: {
		primary: "#0284c7",
		primaryHover: "#0369a1",
		secondary: "#0d9488",
		accent: "#f59e0b",
		background: "#ffffff",
		surface: "#ffffff",
		textPrimary: "#0f172a",
		textSecondary: "#475569",
		border: "#e2e8f0",
		darkBackground: "#ffffff",
		darkSurface: "#ffffff",
		darkTextPrimary: "#0f172a",
		darkTextSecondary: "#475569",
		darkBorder: "#e2e8f0"
	},
	contact: {
		phone: "+91 98765 43210",
		emergencyPhone: "+91 98765 43211",
		email: "appointments@apexcare.com",
		address: "Suite 402, Radiant Towers, Healthcare Avenue, Kochi, Kerala 682016",
		city: "Kochi",
		branches: [{
			name: "ApexCare Radiant Towers (Main)",
			address: "Suite 402, Radiant Towers, Healthcare Ave, Kochi",
			phone: "+91 98765 43210",
			mapEmbedUrl: "https://maps.google.com/maps?q=Kochi,Kerala&t=&z=13&ie=UTF8&iwloc=&output=embed"
		}, {
			name: "ApexCare Marine Drive Branch",
			address: "Plot 14, Marine Drive Promenade, Kochi",
			phone: "+91 98765 43212",
			mapEmbedUrl: "https://maps.google.com/maps?q=Marine+Drive+Kochi&t=&z=13&ie=UTF8&iwloc=&output=embed"
		}],
		workingHours: {
			weekdays: "Mon - Sat: 9:00 AM - 8:00 PM",
			sunday: "Sun: 10:00 AM - 2:00 PM (Emergency Only)",
			isOpenNow: true
		},
		whatsapp: {
			number: "919876543210",
			defaultMessage: "Hi ApexCare Dental, I would like to book a consultation for a dental treatment."
		}
	},
	socials: {
		instagram: "https://instagram.com",
		facebook: "https://facebook.com",
		youtube: "https://youtube.com",
		twitter: "https://twitter.com",
		linkedin: "https://linkedin.com"
	},
	metrics: {
		satisfiedPatients: "18,500+",
		yearsExperience: "16+",
		googleRating: "4.9",
		reviewsCount: "1,420+",
		painlessSuccessRate: "99.4%",
		implantsPlaced: "4,200+"
	},
	trustBadges: [
		{
			title: "ISO 9001:2025 Certified Studio",
			icon: "ShieldCheck"
		},
		{
			title: "100% Sterile Hospital Protocol",
			icon: "Sparkles"
		},
		{
			title: "0% Interest EMI Available",
			icon: "CreditCard"
		},
		{
			title: "Computer Guided Painless Surgery",
			icon: "Cpu"
		}
	],
	navigation: [
		{
			name: "Home",
			href: "#hero"
		},
		{
			name: "Services",
			href: "#services"
		},
		{
			name: "Smile Transformations",
			href: "#transformations"
		},
		{
			name: "Cost Calculator",
			href: "#cost-calculator"
		},
		{
			name: "Our Doctors",
			href: "#doctors"
		},
		{
			name: "Painless Tech",
			href: "#technology"
		},
		{
			name: "Reviews",
			href: "#reviews"
		},
		{
			name: "FAQ",
			href: "#faq"
		},
		{
			name: "Contact",
			href: "#contact"
		}
	],
	services: [
		{
			id: "implants",
			title: "3D Computer-Guided Dental Implants",
			category: "implants",
			shortDesc: "Permanent, natural-looking tooth replacement with keyhole surgery & same-day provisional crowns.",
			fullDesc: "Our computer-guided dental implant procedures offer 99.6% precision, minimal discomfort, and rapid healing time. Replace missing teeth permanently with biocompatible titanium or zirconia implants.",
			iconName: "Tooth",
			priceRange: "₹24,999 - ₹48,000 / implant",
			duration: "45 mins keyhole procedure",
			painlessTech: "Computer Guided & Local Wand Anesthesia",
			highlights: [
				"Lifetime Warranty on Titanium Post",
				"Same-Day Tooth Options",
				"Natural Bone Integration",
				"0% EMI Available"
			],
			popular: true
		},
		{
			id: "invisalign",
			title: "Invisible Aligners (Clear Braces)",
			category: "orthodontics",
			shortDesc: "Straighten teeth discreetly without metal wires using 3D custom clear aligner trays.",
			fullDesc: "Get a perfectly aligned smile with custom-designed 3D clear aligners. Removable, comfortable, and virtually invisible during speech and meals.",
			iconName: "Smile",
			priceRange: "₹45,000 - ₹1,20,000",
			duration: "6 - 14 Months total treatment",
			painlessTech: "3D Intraoral Scanner (No Gaggy Impression Trays)",
			highlights: [
				"3D Digital Smile Simulation Before Starting",
				"Virtually Invisible",
				"Eat Whatever You Like",
				"Free Retainers Included"
			],
			popular: true
		},
		{
			id: "veneers",
			title: "Hollywood Smile & Porcelain Veneers",
			category: "cosmetic",
			shortDesc: "Custom-crafted ultra-thin porcelain veneers to correct gaps, chips, stains, and misalignments.",
			fullDesc: "Transform your smile in just 2 visits! Premium German porcelain veneers designed digitally to match your facial features, skin tone, and natural smile curve.",
			iconName: "Sparkles",
			priceRange: "₹8,500 - ₹18,000 / tooth",
			duration: "2 Visits (5 Days total)",
			painlessTech: "Micro-Enamel Prep with Laser Precision",
			highlights: [
				"Stain-Resistant Glass Porcelain",
				"Custom Shade Matching",
				"10-Year Guarantee",
				"Digital Smile Design Preview"
			],
			popular: true
		},
		{
			id: "whitening",
			title: "Laser Teeth Whitening (Zoom 4)",
			category: "cosmetic",
			shortDesc: "Achieve up to 8 shades whiter teeth in 45 minutes with cold laser LED technology.",
			fullDesc: "Instant, safe teeth whitening that removes deep tea, coffee, smoking, and age stains without enamel damage or post-treatment sensitivity.",
			iconName: "Sun",
			priceRange: "₹6,999 - ₹12,000",
			duration: "45 Minutes single session",
			painlessTech: "Desensitizing Nano-hydroxyapatite Gel",
			highlights: [
				"Instant Results in 1 Session",
				"Safe for Tooth Enamel",
				"Includes Take-Home Touchup Kit",
				"Zero Sensitivity Formulation"
			],
			popular: false
		},
		{
			id: "rootcanal",
			title: "Painless Single-Visit Root Canal (RCT)",
			category: "restorative",
			shortDesc: "Save infected teeth painlessly in a single 45-minute sitting under microscope guidance.",
			fullDesc: "Using rotary endodontic instruments and apex locators, we clean infected root canals thoroughly with zero pain, preserving your natural root structure.",
			iconName: "ShieldAlert",
			priceRange: "₹4,500 - ₹9,500 / tooth",
			duration: "45 - 60 Minutes (Single Visit)",
			painlessTech: "Microscopic Rotary Endodontics + Painless Wand",
			highlights: [
				"Single Sitting Convenience",
				"Microscopic Precision",
				"CAD/CAM Zirconia Crown Pairing",
				"Painless Localized Anesthesia"
			],
			popular: false
		},
		{
			id: "pediatric",
			title: "Kid-Friendly Pediatric Dentistry",
			category: "preventive",
			shortDesc: "Gentle dental checkups, cavity prevention, fluoride therapy, and preventive braces for children.",
			fullDesc: "A playful, anxiety-free atmosphere designed specifically for kids. We make dental visits fun, educational, and completely fear-free.",
			iconName: "Heart",
			priceRange: "₹999 - ₹3,500",
			duration: "30 Minutes",
			painlessTech: "Nitrous Oxide Sedation & Gentle Touch",
			highlights: [
				"Fear-Free Kid Suite",
				"Fluoride Varnish & Sealants",
				"Habit Correction Appliances",
				"Fun Gift Badges"
			],
			popular: false
		},
		{
			id: "emergency",
			title: "24/7 Emergency Dental Trauma Care",
			category: "emergency",
			shortDesc: "Immediate relief for severe toothaches, broken teeth, bleeding gums, or knocked-out teeth.",
			fullDesc: "Dental emergencies shouldn't wait. Our priority trauma care unit handles acute pain, fractured jaws, lost crowns, and sports injuries instantly.",
			iconName: "Activity",
			priceRange: "₹1,200 Onward",
			duration: "Immediate Priority Slot",
			painlessTech: "Instant Pain Block Injection",
			highlights: [
				"Same-Day Emergency Priority",
				"Trauma & Fracture Care",
				"Instant Pain Elimination",
				"On-Call Emergency Surgeons"
			],
			popular: true
		}
	],
	doctors: [
		{
			id: "dr-aravind",
			name: "Dr. Aravind Swaminathan",
			role: "Chief Implantologist & Cosmetic Dentist",
			qualification: "BDS, MDS (Prosthodontics & Implantology), FICOI (USA)",
			experienceYears: 16,
			specialties: [
				"3D Guided Implants",
				"Full Mouth Reconstruction",
				"Hollywood Smile Veneers"
			],
			bio: "Trained in Germany and the USA, Dr. Aravind has successfully placed over 4,200 implants with a 99.4% success rate. He specializes in minimally invasive computer-guided implant surgeries.",
			image: "https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=600&q=80",
			availableDays: "Mon - Sat (9:00 AM - 5:00 PM)",
			rating: 4.9,
			reviewsCount: 680
		},
		{
			id: "dr-ananya",
			name: "Dr. Ananya Nair",
			role: "Senior Orthodontist & Invisalign Specialist",
			qualification: "MDS (Orthodontics & Dentofacial Orthopedics), Certified Invisalign Provider",
			experienceYears: 12,
			specialties: [
				"Clear Aligners / Invisalign",
				"Lingual Braces",
				"Surgical Orthodontics"
			],
			bio: "Dr. Ananya has crafted over 1,500 aligner smiles. She blends digital facial aesthetics with precise orthodontic biomechanics for beautiful, functional results.",
			image: "https://images.unsplash.com/photo-1594824813566-78a99479b634?auto=format&fit=crop&w=600&q=80",
			availableDays: "Mon - Sat (10:00 AM - 7:00 PM)",
			rating: 4.9,
			reviewsCount: 520
		},
		{
			id: "dr-rohit",
			name: "Dr. Rohit Menon",
			role: "Endodontist & Laser Specialist",
			qualification: "MDS (Conservative Dentistry & Endodontics), DiLA (Laser Cert. Germany)",
			experienceYears: 10,
			specialties: [
				"Single-Visit Painless RCT",
				"Microscopic Dentistry",
				"Laser Gum Therapy"
			],
			bio: "Expert in preserving natural teeth with zero pain. Dr. Rohit performs high-precision root canals under surgical microscope with laser sterilization.",
			image: "https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&w=600&q=80",
			availableDays: "Mon - Sat (11:00 AM - 8:00 PM)",
			rating: 4.8,
			reviewsCount: 390
		}
	],
	transformations: [
		{
			id: "case-1",
			treatmentName: "Full Upper Arch Invisalign Alignment",
			patientName: "Meera R., 28",
			category: "Invisalign Clear Aligners",
			beforeImage: "https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&w=600&q=80",
			afterImage: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80",
			duration: "8 Months",
			dentistName: "Dr. Ananya Nair",
			description: "Corrected severe overcrowding and deep bite using custom 3D aligner series without any metal braces."
		},
		{
			id: "case-2",
			treatmentName: "10-Tooth Porcelain Veneer Makeover",
			patientName: "Rahul V., 35",
			category: "Cosmetic Veneers",
			beforeImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80",
			afterImage: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=600&q=80",
			duration: "2 Visits (4 Days)",
			dentistName: "Dr. Aravind Swaminathan",
			description: "Transformed chipped, discolored front teeth into a radiant, symmetric Hollywood smile."
		},
		{
			id: "case-3",
			treatmentName: "Same-Day Guided Dental Implant",
			patientName: "Siddharth K., 42",
			category: "Dental Implants",
			beforeImage: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=600&q=80",
			afterImage: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=600&q=80",
			duration: "Single Sitting + Crown",
			dentistName: "Dr. Aravind Swaminathan",
			description: "Replaced a fractured front tooth with keyhole titanium implant and immediate esthetic provisional crown."
		}
	],
	pricingPlans: [
		{
			id: "plan-checkup",
			name: "Comprehensive Preventive Checkup",
			category: "Preventive Care",
			price: "₹999",
			originalPrice: "₹2,500",
			emiAvailable: false,
			features: [
				"Full Mouth 3D Intraoral Digital Scan",
				"HD Digital X-Rays (RVG)",
				"Ultrasonic Scaling & Tooth Polishing",
				"Oral Cancer Screening & Gum Assessment",
				"Personalized Treatment Plan & Consultation"
			],
			popular: false
		},
		{
			id: "plan-whitening",
			name: "Zoom 4 Laser Whitening",
			category: "Cosmetic Dentistry",
			price: "₹6,999",
			originalPrice: "₹12,000",
			emiAvailable: true,
			emiStartingAt: "₹1,166 / mo (6 mo EMI)",
			features: [
				"Up to 8 Shades Whiter in 45 Mins",
				"German Cold-LED Technology",
				"Zero-Sensitivity Nano Protection",
				"Includes Take-Home Care Kit",
				"Free Follow-up Polish in 6 Months"
			],
			popular: true
		},
		{
			id: "plan-implant",
			name: "Premium Zirconia Dental Implant",
			category: "Restorative Dentistry",
			price: "₹28,500",
			originalPrice: "₹38,000",
			emiAvailable: true,
			emiStartingAt: "₹2,375 / mo (12 mo EMI)",
			features: [
				"Computer-Guided Keyhole Surgery",
				"US-FDA Approved Titanium Abutment",
				"100% Metal-Free Zirconia Crown",
				"Lifetime Guarantee Certificate",
				"Free 3D CT Scan (CBCT) Included"
			],
			popular: true
		}
	],
	insurancePartners: [
		{
			name: "Star Health Insurance",
			logoText: "Star Health"
		},
		{
			name: "HDFC ERGO Health",
			logoText: "HDFC ERGO"
		},
		{
			name: "ICICI Lombard",
			logoText: "ICICI Lombard"
		},
		{
			name: "Max Bupa / Niva Bupa",
			logoText: "Niva Bupa"
		},
		{
			name: "Care Health Insurance",
			logoText: "Care Health"
		},
		{
			name: "Bajaj Allianz",
			logoText: "Bajaj Allianz"
		}
	],
	testimonials: [
		{
			id: "t1",
			name: "Dr. Lakshmi Prasad",
			role: "Professor & Patient",
			rating: 5,
			comment: "I was terrified of dental implants until I visited ApexCare. Dr. Aravind used 3D computer guidance — the entire procedure took less than 45 minutes and I experienced absolutely zero pain! Highly recommended studio.",
			treatment: "Computer-Guided Implant",
			date: "2 weeks ago",
			verified: true
		},
		{
			id: "t2",
			name: "Vishnu Mohan",
			role: "Software Architect",
			rating: 5,
			comment: "Got my Invisalign aligners done here with Dr. Ananya. The 3D scan preview before starting gave me total confidence. Today my teeth are completely straight and nobody even noticed I had aligners on!",
			treatment: "Invisalign Clear Aligners",
			date: "1 month ago",
			verified: true
		},
		{
			id: "t3",
			name: "Priya Nair",
			role: "Fashion Designer",
			rating: 5,
			comment: "The Hollywood Smile porcelain veneers done by Dr. Aravind transformed my confidence completely. The clinic looks like a luxury lounge and their sterilization standards are top-notch.",
			treatment: "Porcelain Veneers",
			date: "3 weeks ago",
			verified: true
		}
	],
	faqs: [
		{
			question: "Are dental treatments at ApexCare really painless?",
			answer: "Yes! We utilize computer-controlled Wand local anesthesia, needle-free injections, nitrous oxide dental sedation, and cold laser technology. Most patients feel no pain during or after procedures."
		},
		{
			question: "How long does a clear aligner (Invisalign) treatment take?",
			answer: "Treatment times range from 6 to 14 months depending on complexity. With our 3D digital scanner, you will see a step-by-step virtual model of your future smile during your first consultation."
		},
		{
			question: "Do you offer 0% interest EMI payment options?",
			answer: "Yes! We partner with major banks and healthcare fintechs to offer 3, 6, 9, and 12-month 0% interest EMI options with no hidden fees and instant approval."
		},
		{
			question: "Can I get a dental implant done on the same day as extraction?",
			answer: "In most cases, yes! Immediate loading implants allow us to place the implant and fit a natural temporary crown in a single 45-minute visit."
		},
		{
			question: "What safety and sterilization protocols do you follow?",
			answer: "We adhere strictly to Class-B Autoclave 7-step sterilization protocols recommended by the CDC and WHO. Every instrument is individually sealed in sterile pouches opened in front of you."
		}
	],
	symptomQuiz: [{
		id: "q1",
		question: "What is your main dental concern?",
		options: [
			{
				text: "Missing or lost teeth",
				matchService: "implants"
			},
			{
				text: "Crooked or crowded teeth",
				matchService: "invisalign"
			},
			{
				text: "Discolored or stained smile",
				matchService: "whitening"
			},
			{
				text: "Severe tooth pain or toothache",
				matchService: "rootcanal"
			},
			{
				text: "Desire a celebrity smile makeover",
				matchService: "veneers"
			}
		]
	}, {
		id: "q2",
		question: "How urgently do you require treatment?",
		options: [
			{ text: "Immediately (Within 24 Hours / Emergency)" },
			{ text: "This Week" },
			{ text: "Planning for Next Month" }
		]
	}]
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBeURBLE9BQU8sTUFBTSxlQUFlO0NBQzFCLE1BQU07Q0FDTixTQUFTO0NBQ1QsWUFBWTtDQUVaLE1BQU07RUFDSixNQUFNO0VBQ04sTUFBTTtFQUNOLFNBQVM7Q0FDWDtDQUVBLE9BQU87RUFDTCxTQUFTO0VBQ1QsY0FBYztFQUNkLFdBQVc7RUFDWCxRQUFRO0VBQ1IsWUFBWTtFQUNaLFNBQVM7RUFDVCxhQUFhO0VBQ2IsZUFBZTtFQUNmLFFBQVE7RUFDUixnQkFBZ0I7RUFDaEIsYUFBYTtFQUNiLGlCQUFpQjtFQUNqQixtQkFBbUI7RUFDbkIsWUFBWTtDQUNkO0NBRUEsU0FBUztFQUNQLE9BQU87RUFDUCxnQkFBZ0I7RUFDaEIsT0FBTztFQUNQLFNBQVM7RUFDVCxNQUFNO0VBQ04sVUFBVSxDQUNSO0dBQUUsTUFBTTtHQUFrQyxTQUFTO0dBQW9ELE9BQU87R0FBbUIsYUFBYTtFQUFrRixHQUNoTztHQUFFLE1BQU07R0FBZ0MsU0FBUztHQUEwQyxPQUFPO0dBQW1CLGFBQWE7RUFBd0YsQ0FDNU47RUFDQSxjQUFjO0dBQ1osVUFBVTtHQUNWLFFBQVE7R0FDUixXQUFXO0VBQ2I7RUFDQSxVQUFVO0dBQ1IsUUFBUTtHQUNSLGdCQUFnQjtFQUNsQjtDQUNGO0NBRUEsU0FBUztFQUNQLFdBQVc7RUFDWCxVQUFVO0VBQ1YsU0FBUztFQUNULFNBQVM7RUFDVCxVQUFVO0NBQ1o7Q0FFQSxTQUFTO0VBQ1AsbUJBQW1CO0VBQ25CLGlCQUFpQjtFQUNqQixjQUFjO0VBQ2QsY0FBYztFQUNkLHFCQUFxQjtFQUNyQixnQkFBZ0I7Q0FDbEI7Q0FFQSxhQUFhO0VBQ1g7R0FBRSxPQUFPO0dBQWtDLE1BQU07RUFBYztFQUMvRDtHQUFFLE9BQU87R0FBa0MsTUFBTTtFQUFXO0VBQzVEO0dBQUUsT0FBTztHQUE2QixNQUFNO0VBQWE7RUFDekQ7R0FBRSxPQUFPO0dBQW9DLE1BQU07RUFBTTtDQUMzRDtDQUVBLFlBQVk7RUFDVjtHQUFFLE1BQU07R0FBUSxNQUFNO0VBQVE7RUFDOUI7R0FBRSxNQUFNO0dBQVksTUFBTTtFQUFZO0VBQ3RDO0dBQUUsTUFBTTtHQUF5QixNQUFNO0VBQW1CO0VBQzFEO0dBQUUsTUFBTTtHQUFtQixNQUFNO0VBQW1CO0VBQ3BEO0dBQUUsTUFBTTtHQUFlLE1BQU07RUFBVztFQUN4QztHQUFFLE1BQU07R0FBaUIsTUFBTTtFQUFjO0VBQzdDO0dBQUUsTUFBTTtHQUFXLE1BQU07RUFBVztFQUNwQztHQUFFLE1BQU07R0FBTyxNQUFNO0VBQU87RUFDNUI7R0FBRSxNQUFNO0dBQVcsTUFBTTtFQUFXO0NBQ3RDO0NBRUEsVUFBVTtFQUNSO0dBQ0UsSUFBSTtHQUNKLE9BQU87R0FDUCxVQUFVO0dBQ1YsV0FBVztHQUNYLFVBQVU7R0FDVixVQUFVO0dBQ1YsWUFBWTtHQUNaLFVBQVU7R0FDVixjQUFjO0dBQ2QsWUFBWTtJQUFDO0lBQXNDO0lBQTBCO0lBQTRCO0dBQWtCO0dBQzNILFNBQVM7RUFDWDtFQUNBO0dBQ0UsSUFBSTtHQUNKLE9BQU87R0FDUCxVQUFVO0dBQ1YsV0FBVztHQUNYLFVBQVU7R0FDVixVQUFVO0dBQ1YsWUFBWTtHQUNaLFVBQVU7R0FDVixjQUFjO0dBQ2QsWUFBWTtJQUFDO0lBQStDO0lBQXVCO0lBQXlCO0dBQXlCO0dBQ3JJLFNBQVM7RUFDWDtFQUNBO0dBQ0UsSUFBSTtHQUNKLE9BQU87R0FDUCxVQUFVO0dBQ1YsV0FBVztHQUNYLFVBQVU7R0FDVixVQUFVO0dBQ1YsWUFBWTtHQUNaLFVBQVU7R0FDVixjQUFjO0dBQ2QsWUFBWTtJQUFDO0lBQW1DO0lBQXlCO0lBQXFCO0dBQThCO0dBQzVILFNBQVM7RUFDWDtFQUNBO0dBQ0UsSUFBSTtHQUNKLE9BQU87R0FDUCxVQUFVO0dBQ1YsV0FBVztHQUNYLFVBQVU7R0FDVixVQUFVO0dBQ1YsWUFBWTtHQUNaLFVBQVU7R0FDVixjQUFjO0dBQ2QsWUFBWTtJQUFDO0lBQWdDO0lBQXlCO0lBQWtDO0dBQThCO0dBQ3RJLFNBQVM7RUFDWDtFQUNBO0dBQ0UsSUFBSTtHQUNKLE9BQU87R0FDUCxVQUFVO0dBQ1YsV0FBVztHQUNYLFVBQVU7R0FDVixVQUFVO0dBQ1YsWUFBWTtHQUNaLFVBQVU7R0FDVixjQUFjO0dBQ2QsWUFBWTtJQUFDO0lBQThCO0lBQXlCO0lBQWtDO0dBQStCO0dBQ3JJLFNBQVM7RUFDWDtFQUNBO0dBQ0UsSUFBSTtHQUNKLE9BQU87R0FDUCxVQUFVO0dBQ1YsV0FBVztHQUNYLFVBQVU7R0FDVixVQUFVO0dBQ1YsWUFBWTtHQUNaLFVBQVU7R0FDVixjQUFjO0dBQ2QsWUFBWTtJQUFDO0lBQXVCO0lBQStCO0lBQStCO0dBQWlCO0dBQ25ILFNBQVM7RUFDWDtFQUNBO0dBQ0UsSUFBSTtHQUNKLE9BQU87R0FDUCxVQUFVO0dBQ1YsV0FBVztHQUNYLFVBQVU7R0FDVixVQUFVO0dBQ1YsWUFBWTtHQUNaLFVBQVU7R0FDVixjQUFjO0dBQ2QsWUFBWTtJQUFDO0lBQStCO0lBQTBCO0lBQTRCO0dBQTRCO0dBQzlILFNBQVM7RUFDWDtDQUNGO0NBRUEsU0FBUztFQUNQO0dBQ0UsSUFBSTtHQUNKLE1BQU07R0FDTixNQUFNO0dBQ04sZUFBZTtHQUNmLGlCQUFpQjtHQUNqQixhQUFhO0lBQUM7SUFBc0I7SUFBNkI7R0FBeUI7R0FDMUYsS0FBSztHQUNMLE9BQU87R0FDUCxlQUFlO0dBQ2YsUUFBUTtHQUNSLGNBQWM7RUFDaEI7RUFDQTtHQUNFLElBQUk7R0FDSixNQUFNO0dBQ04sTUFBTTtHQUNOLGVBQWU7R0FDZixpQkFBaUI7R0FDakIsYUFBYTtJQUFDO0lBQStCO0lBQWtCO0dBQXVCO0dBQ3RGLEtBQUs7R0FDTCxPQUFPO0dBQ1AsZUFBZTtHQUNmLFFBQVE7R0FDUixjQUFjO0VBQ2hCO0VBQ0E7R0FDRSxJQUFJO0dBQ0osTUFBTTtHQUNOLE1BQU07R0FDTixlQUFlO0dBQ2YsaUJBQWlCO0dBQ2pCLGFBQWE7SUFBQztJQUE2QjtJQUF5QjtHQUFtQjtHQUN2RixLQUFLO0dBQ0wsT0FBTztHQUNQLGVBQWU7R0FDZixRQUFRO0dBQ1IsY0FBYztFQUNoQjtDQUNGO0NBRUEsaUJBQWlCO0VBQ2Y7R0FDRSxJQUFJO0dBQ0osZUFBZTtHQUNmLGFBQWE7R0FDYixVQUFVO0dBQ1YsYUFBYTtHQUNiLFlBQVk7R0FDWixVQUFVO0dBQ1YsYUFBYTtHQUNiLGFBQWE7RUFDZjtFQUNBO0dBQ0UsSUFBSTtHQUNKLGVBQWU7R0FDZixhQUFhO0dBQ2IsVUFBVTtHQUNWLGFBQWE7R0FDYixZQUFZO0dBQ1osVUFBVTtHQUNWLGFBQWE7R0FDYixhQUFhO0VBQ2Y7RUFDQTtHQUNFLElBQUk7R0FDSixlQUFlO0dBQ2YsYUFBYTtHQUNiLFVBQVU7R0FDVixhQUFhO0dBQ2IsWUFBWTtHQUNaLFVBQVU7R0FDVixhQUFhO0dBQ2IsYUFBYTtFQUNmO0NBQ0Y7Q0FFQSxjQUFjO0VBQ1o7R0FDRSxJQUFJO0dBQ0osTUFBTTtHQUNOLFVBQVU7R0FDVixPQUFPO0dBQ1AsZUFBZTtHQUNmLGNBQWM7R0FDZCxVQUFVO0lBQ1I7SUFDQTtJQUNBO0lBQ0E7SUFDQTtHQUNGO0dBQ0EsU0FBUztFQUNYO0VBQ0E7R0FDRSxJQUFJO0dBQ0osTUFBTTtHQUNOLFVBQVU7R0FDVixPQUFPO0dBQ1AsZUFBZTtHQUNmLGNBQWM7R0FDZCxlQUFlO0dBQ2YsVUFBVTtJQUNSO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7R0FDRjtHQUNBLFNBQVM7RUFDWDtFQUNBO0dBQ0UsSUFBSTtHQUNKLE1BQU07R0FDTixVQUFVO0dBQ1YsT0FBTztHQUNQLGVBQWU7R0FDZixjQUFjO0dBQ2QsZUFBZTtHQUNmLFVBQVU7SUFDUjtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0Y7R0FDQSxTQUFTO0VBQ1g7Q0FDRjtDQUVBLG1CQUFtQjtFQUNqQjtHQUFFLE1BQU07R0FBeUIsVUFBVTtFQUFjO0VBQ3pEO0dBQUUsTUFBTTtHQUFvQixVQUFVO0VBQVk7RUFDbEQ7R0FBRSxNQUFNO0dBQWlCLFVBQVU7RUFBZ0I7RUFDbkQ7R0FBRSxNQUFNO0dBQXdCLFVBQVU7RUFBWTtFQUN0RDtHQUFFLE1BQU07R0FBeUIsVUFBVTtFQUFjO0VBQ3pEO0dBQUUsTUFBTTtHQUFpQixVQUFVO0VBQWdCO0NBQ3JEO0NBRUEsY0FBYztFQUNaO0dBQ0UsSUFBSTtHQUNKLE1BQU07R0FDTixNQUFNO0dBQ04sUUFBUTtHQUNSLFNBQVM7R0FDVCxXQUFXO0dBQ1gsTUFBTTtHQUNOLFVBQVU7RUFDWjtFQUNBO0dBQ0UsSUFBSTtHQUNKLE1BQU07R0FDTixNQUFNO0dBQ04sUUFBUTtHQUNSLFNBQVM7R0FDVCxXQUFXO0dBQ1gsTUFBTTtHQUNOLFVBQVU7RUFDWjtFQUNBO0dBQ0UsSUFBSTtHQUNKLE1BQU07R0FDTixNQUFNO0dBQ04sUUFBUTtHQUNSLFNBQVM7R0FDVCxXQUFXO0dBQ1gsTUFBTTtHQUNOLFVBQVU7RUFDWjtDQUNGO0NBRUEsTUFBTTtFQUNKO0dBQ0UsVUFBVTtHQUNWLFFBQVE7RUFDVjtFQUNBO0dBQ0UsVUFBVTtHQUNWLFFBQVE7RUFDVjtFQUNBO0dBQ0UsVUFBVTtHQUNWLFFBQVE7RUFDVjtFQUNBO0dBQ0UsVUFBVTtHQUNWLFFBQVE7RUFDVjtFQUNBO0dBQ0UsVUFBVTtHQUNWLFFBQVE7RUFDVjtDQUNGO0NBRUEsYUFBYSxDQUNYO0VBQ0UsSUFBSTtFQUNKLFVBQVU7RUFDVixTQUFTO0dBQ1A7SUFBRSxNQUFNO0lBQXlCLGNBQWM7R0FBVztHQUMxRDtJQUFFLE1BQU07SUFBNEIsY0FBYztHQUFhO0dBQy9EO0lBQUUsTUFBTTtJQUErQixjQUFjO0dBQVk7R0FDakU7SUFBRSxNQUFNO0lBQWtDLGNBQWM7R0FBWTtHQUNwRTtJQUFFLE1BQU07SUFBcUMsY0FBYztHQUFVO0VBQ3ZFO0NBQ0YsR0FDQTtFQUNFLElBQUk7RUFDSixVQUFVO0VBQ1YsU0FBUztHQUNQLEVBQUUsTUFBTSw0Q0FBNEM7R0FDcEQsRUFBRSxNQUFNLFlBQVk7R0FDcEIsRUFBRSxNQUFNLDBCQUEwQjtFQUNwQztDQUNGLENBQ0Y7QUFDRiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJzaXRlQ29uZmlnLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBpbnRlcmZhY2UgU2VydmljZUl0ZW0ge1xuICBpZDogc3RyaW5nO1xuICB0aXRsZTogc3RyaW5nO1xuICBjYXRlZ29yeTogJ2Nvc21ldGljJyB8ICdpbXBsYW50cycgfCAnb3J0aG9kb250aWNzJyB8ICdwcmV2ZW50aXZlJyB8ICdlbWVyZ2VuY3knO1xuICBzaG9ydERlc2M6IHN0cmluZztcbiAgZnVsbERlc2M6IHN0cmluZztcbiAgaWNvbk5hbWU6IHN0cmluZzsgLy8gTHVjaWRlIGljb24gbmFtZVxuICBwcmljZVJhbmdlOiBzdHJpbmc7XG4gIGR1cmF0aW9uOiBzdHJpbmc7XG4gIHBhaW5sZXNzVGVjaDogc3RyaW5nO1xuICBoaWdobGlnaHRzOiBzdHJpbmdbXTtcbiAgcG9wdWxhcj86IGJvb2xlYW47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgRG9jdG9yIHtcbiAgaWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICByb2xlOiBzdHJpbmc7XG4gIHF1YWxpZmljYXRpb246IHN0cmluZztcbiAgZXhwZXJpZW5jZVllYXJzOiBudW1iZXI7XG4gIHNwZWNpYWx0aWVzOiBzdHJpbmdbXTtcbiAgYmlvOiBzdHJpbmc7XG4gIGltYWdlOiBzdHJpbmc7XG4gIGF2YWlsYWJsZURheXM6IHN0cmluZztcbiAgcmF0aW5nOiBudW1iZXI7XG4gIHJldmlld3NDb3VudDogbnVtYmVyO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEJlZm9yZUFmdGVyQ2FzZSB7XG4gIGlkOiBzdHJpbmc7XG4gIHRyZWF0bWVudE5hbWU6IHN0cmluZztcbiAgcGF0aWVudE5hbWU6IHN0cmluZztcbiAgY2F0ZWdvcnk6IHN0cmluZztcbiAgYmVmb3JlSW1hZ2U6IHN0cmluZztcbiAgYWZ0ZXJJbWFnZTogc3RyaW5nO1xuICBkdXJhdGlvbjogc3RyaW5nO1xuICBkZW50aXN0TmFtZTogc3RyaW5nO1xuICBkZXNjcmlwdGlvbjogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFF1aXpPcHRpb24ge1xuICB0ZXh0OiBzdHJpbmc7XG4gIG1hdGNoU2VydmljZT86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBQcmljaW5nUGxhbiB7XG4gIGlkOiBzdHJpbmc7XG4gIG5hbWU6IHN0cmluZztcbiAgY2F0ZWdvcnk6IHN0cmluZztcbiAgcHJpY2U6IHN0cmluZztcbiAgb3JpZ2luYWxQcmljZT86IHN0cmluZztcbiAgZW1pQXZhaWxhYmxlOiBib29sZWFuO1xuICBlbWlTdGFydGluZ0F0Pzogc3RyaW5nO1xuICBmZWF0dXJlczogc3RyaW5nW107XG4gIHBvcHVsYXI/OiBib29sZWFuO1xufVxuXG5leHBvcnQgY29uc3QgY2xpbmljQ29uZmlnID0ge1xuICBuYW1lOiBcIkFwZXhDYXJlIERlbnRhbCBTdHVkaW9cIixcbiAgdGFnbGluZTogXCJQcmVjaXNpb24gRGVudGlzdHJ5LCBEZXNpZ25lZCBGb3IgWW91ciBTbWlsZVwiLFxuICBzdWJ0YWdsaW5lOiBcIkV4cGVyaWVuY2UgcGFpbmxlc3MsIGxhc2VyLWFzc2lzdGVkIGRlbnRhbCBjYXJlICYgM0Qgc21pbGUgdHJhbnNmb3JtYXRpb25zIGluIGEgbHV4dXJpb3VzLCBzZXJlbmUgc3R1ZGlvIGVudmlyb25tZW50LlwiLFxuICBcbiAgbG9nbzoge1xuICAgIHRleHQ6IFwiQXBleENhcmVcIixcbiAgICBpY29uOiBcIlNwYXJrbGVzXCIsIC8vIEx1Y2lkZSBpY29uXG4gICAgc3VidGV4dDogXCJEZW50YWwgJiBJbXBsYW50b2xvZ3kgU3R1ZGlvXCJcbiAgfSxcblxuICB0aGVtZToge1xuICAgIHByaW1hcnk6IFwiIzAyODRjN1wiLCAgICAgICAgLy8gUmljaCBNZWRpY2FsIFNreSBCbHVlXG4gICAgcHJpbWFyeUhvdmVyOiBcIiMwMzY5YTFcIixcbiAgICBzZWNvbmRhcnk6IFwiIzBkOTQ4OFwiLCAgICAgIC8vIE1lZGljYWwgQ3lhbiAvIFRlYWxcbiAgICBhY2NlbnQ6IFwiI2Y1OWUwYlwiLCAgICAgICAgIC8vIFdhcm0gR29sZCBBbWJlclxuICAgIGJhY2tncm91bmQ6IFwiI2ZmZmZmZlwiLCAgICAgLy8gUHVyZSBQcmlzdGluZSBXaGl0ZVxuICAgIHN1cmZhY2U6IFwiI2ZmZmZmZlwiLFxuICAgIHRleHRQcmltYXJ5OiBcIiMwZjE3MmFcIiwgICAgLy8gRGVlcCBTbGF0ZSAvIEFsbW9zdCBCbGFjayBmb3IgcGVyZmVjdCByZWFkYWJpbGl0eVxuICAgIHRleHRTZWNvbmRhcnk6IFwiIzQ3NTU2OVwiLCAgLy8gTXV0ZWQgU2xhdGVcbiAgICBib3JkZXI6IFwiI2UyZThmMFwiLFxuICAgIGRhcmtCYWNrZ3JvdW5kOiBcIiNmZmZmZmZcIixcbiAgICBkYXJrU3VyZmFjZTogXCIjZmZmZmZmXCIsXG4gICAgZGFya1RleHRQcmltYXJ5OiBcIiMwZjE3MmFcIixcbiAgICBkYXJrVGV4dFNlY29uZGFyeTogXCIjNDc1NTY5XCIsXG4gICAgZGFya0JvcmRlcjogXCIjZTJlOGYwXCJcbiAgfSxcblxuICBjb250YWN0OiB7XG4gICAgcGhvbmU6IFwiKzkxIDk4NzY1IDQzMjEwXCIsXG4gICAgZW1lcmdlbmN5UGhvbmU6IFwiKzkxIDk4NzY1IDQzMjExXCIsXG4gICAgZW1haWw6IFwiYXBwb2ludG1lbnRzQGFwZXhjYXJlLmNvbVwiLFxuICAgIGFkZHJlc3M6IFwiU3VpdGUgNDAyLCBSYWRpYW50IFRvd2VycywgSGVhbHRoY2FyZSBBdmVudWUsIEtvY2hpLCBLZXJhbGEgNjgyMDE2XCIsXG4gICAgY2l0eTogXCJLb2NoaVwiLFxuICAgIGJyYW5jaGVzOiBbXG4gICAgICB7IG5hbWU6IFwiQXBleENhcmUgUmFkaWFudCBUb3dlcnMgKE1haW4pXCIsIGFkZHJlc3M6IFwiU3VpdGUgNDAyLCBSYWRpYW50IFRvd2VycywgSGVhbHRoY2FyZSBBdmUsIEtvY2hpXCIsIHBob25lOiBcIis5MSA5ODc2NSA0MzIxMFwiLCBtYXBFbWJlZFVybDogXCJodHRwczovL21hcHMuZ29vZ2xlLmNvbS9tYXBzP3E9S29jaGksS2VyYWxhJnQ9Jno9MTMmaWU9VVRGOCZpd2xvYz0mb3V0cHV0PWVtYmVkXCIgfSxcbiAgICAgIHsgbmFtZTogXCJBcGV4Q2FyZSBNYXJpbmUgRHJpdmUgQnJhbmNoXCIsIGFkZHJlc3M6IFwiUGxvdCAxNCwgTWFyaW5lIERyaXZlIFByb21lbmFkZSwgS29jaGlcIiwgcGhvbmU6IFwiKzkxIDk4NzY1IDQzMjEyXCIsIG1hcEVtYmVkVXJsOiBcImh0dHBzOi8vbWFwcy5nb29nbGUuY29tL21hcHM/cT1NYXJpbmUrRHJpdmUrS29jaGkmdD0mej0xMyZpZT1VVEY4Jml3bG9jPSZvdXRwdXQ9ZW1iZWRcIiB9XG4gICAgXSxcbiAgICB3b3JraW5nSG91cnM6IHtcbiAgICAgIHdlZWtkYXlzOiBcIk1vbiAtIFNhdDogOTowMCBBTSAtIDg6MDAgUE1cIixcbiAgICAgIHN1bmRheTogXCJTdW46IDEwOjAwIEFNIC0gMjowMCBQTSAoRW1lcmdlbmN5IE9ubHkpXCIsXG4gICAgICBpc09wZW5Ob3c6IHRydWVcbiAgICB9LFxuICAgIHdoYXRzYXBwOiB7XG4gICAgICBudW1iZXI6IFwiOTE5ODc2NTQzMjEwXCIsXG4gICAgICBkZWZhdWx0TWVzc2FnZTogXCJIaSBBcGV4Q2FyZSBEZW50YWwsIEkgd291bGQgbGlrZSB0byBib29rIGEgY29uc3VsdGF0aW9uIGZvciBhIGRlbnRhbCB0cmVhdG1lbnQuXCJcbiAgICB9XG4gIH0sXG5cbiAgc29jaWFsczoge1xuICAgIGluc3RhZ3JhbTogXCJodHRwczovL2luc3RhZ3JhbS5jb21cIixcbiAgICBmYWNlYm9vazogXCJodHRwczovL2ZhY2Vib29rLmNvbVwiLFxuICAgIHlvdXR1YmU6IFwiaHR0cHM6Ly95b3V0dWJlLmNvbVwiLFxuICAgIHR3aXR0ZXI6IFwiaHR0cHM6Ly90d2l0dGVyLmNvbVwiLFxuICAgIGxpbmtlZGluOiBcImh0dHBzOi8vbGlua2VkaW4uY29tXCJcbiAgfSxcblxuICBtZXRyaWNzOiB7XG4gICAgc2F0aXNmaWVkUGF0aWVudHM6IFwiMTgsNTAwK1wiLFxuICAgIHllYXJzRXhwZXJpZW5jZTogXCIxNitcIixcbiAgICBnb29nbGVSYXRpbmc6IFwiNC45XCIsXG4gICAgcmV2aWV3c0NvdW50OiBcIjEsNDIwK1wiLFxuICAgIHBhaW5sZXNzU3VjY2Vzc1JhdGU6IFwiOTkuNCVcIixcbiAgICBpbXBsYW50c1BsYWNlZDogXCI0LDIwMCtcIlxuICB9LFxuXG4gIHRydXN0QmFkZ2VzOiBbXG4gICAgeyB0aXRsZTogXCJJU08gOTAwMToyMDI1IENlcnRpZmllZCBTdHVkaW9cIiwgaWNvbjogXCJTaGllbGRDaGVja1wiIH0sXG4gICAgeyB0aXRsZTogXCIxMDAlIFN0ZXJpbGUgSG9zcGl0YWwgUHJvdG9jb2xcIiwgaWNvbjogXCJTcGFya2xlc1wiIH0sXG4gICAgeyB0aXRsZTogXCIwJSBJbnRlcmVzdCBFTUkgQXZhaWxhYmxlXCIsIGljb246IFwiQ3JlZGl0Q2FyZFwiIH0sXG4gICAgeyB0aXRsZTogXCJDb21wdXRlciBHdWlkZWQgUGFpbmxlc3MgU3VyZ2VyeVwiLCBpY29uOiBcIkNwdVwiIH1cbiAgXSxcblxuICBuYXZpZ2F0aW9uOiBbXG4gICAgeyBuYW1lOiBcIkhvbWVcIiwgaHJlZjogXCIjaGVyb1wiIH0sXG4gICAgeyBuYW1lOiBcIlNlcnZpY2VzXCIsIGhyZWY6IFwiI3NlcnZpY2VzXCIgfSxcbiAgICB7IG5hbWU6IFwiU21pbGUgVHJhbnNmb3JtYXRpb25zXCIsIGhyZWY6IFwiI3RyYW5zZm9ybWF0aW9uc1wiIH0sXG4gICAgeyBuYW1lOiBcIkNvc3QgQ2FsY3VsYXRvclwiLCBocmVmOiBcIiNjb3N0LWNhbGN1bGF0b3JcIiB9LFxuICAgIHsgbmFtZTogXCJPdXIgRG9jdG9yc1wiLCBocmVmOiBcIiNkb2N0b3JzXCIgfSxcbiAgICB7IG5hbWU6IFwiUGFpbmxlc3MgVGVjaFwiLCBocmVmOiBcIiN0ZWNobm9sb2d5XCIgfSxcbiAgICB7IG5hbWU6IFwiUmV2aWV3c1wiLCBocmVmOiBcIiNyZXZpZXdzXCIgfSxcbiAgICB7IG5hbWU6IFwiRkFRXCIsIGhyZWY6IFwiI2ZhcVwiIH0sXG4gICAgeyBuYW1lOiBcIkNvbnRhY3RcIiwgaHJlZjogXCIjY29udGFjdFwiIH1cbiAgXSxcblxuICBzZXJ2aWNlczogW1xuICAgIHtcbiAgICAgIGlkOiBcImltcGxhbnRzXCIsXG4gICAgICB0aXRsZTogXCIzRCBDb21wdXRlci1HdWlkZWQgRGVudGFsIEltcGxhbnRzXCIsXG4gICAgICBjYXRlZ29yeTogXCJpbXBsYW50c1wiLFxuICAgICAgc2hvcnREZXNjOiBcIlBlcm1hbmVudCwgbmF0dXJhbC1sb29raW5nIHRvb3RoIHJlcGxhY2VtZW50IHdpdGgga2V5aG9sZSBzdXJnZXJ5ICYgc2FtZS1kYXkgcHJvdmlzaW9uYWwgY3Jvd25zLlwiLFxuICAgICAgZnVsbERlc2M6IFwiT3VyIGNvbXB1dGVyLWd1aWRlZCBkZW50YWwgaW1wbGFudCBwcm9jZWR1cmVzIG9mZmVyIDk5LjYlIHByZWNpc2lvbiwgbWluaW1hbCBkaXNjb21mb3J0LCBhbmQgcmFwaWQgaGVhbGluZyB0aW1lLiBSZXBsYWNlIG1pc3NpbmcgdGVldGggcGVybWFuZW50bHkgd2l0aCBiaW9jb21wYXRpYmxlIHRpdGFuaXVtIG9yIHppcmNvbmlhIGltcGxhbnRzLlwiLFxuICAgICAgaWNvbk5hbWU6IFwiVG9vdGhcIixcbiAgICAgIHByaWNlUmFuZ2U6IFwi4oK5MjQsOTk5IC0g4oK5NDgsMDAwIC8gaW1wbGFudFwiLFxuICAgICAgZHVyYXRpb246IFwiNDUgbWlucyBrZXlob2xlIHByb2NlZHVyZVwiLFxuICAgICAgcGFpbmxlc3NUZWNoOiBcIkNvbXB1dGVyIEd1aWRlZCAmIExvY2FsIFdhbmQgQW5lc3RoZXNpYVwiLFxuICAgICAgaGlnaGxpZ2h0czogW1wiTGlmZXRpbWUgV2FycmFudHkgb24gVGl0YW5pdW0gUG9zdFwiLCBcIlNhbWUtRGF5IFRvb3RoIE9wdGlvbnNcIiwgXCJOYXR1cmFsIEJvbmUgSW50ZWdyYXRpb25cIiwgXCIwJSBFTUkgQXZhaWxhYmxlXCJdLFxuICAgICAgcG9wdWxhcjogdHJ1ZVxuICAgIH0sXG4gICAge1xuICAgICAgaWQ6IFwiaW52aXNhbGlnblwiLFxuICAgICAgdGl0bGU6IFwiSW52aXNpYmxlIEFsaWduZXJzIChDbGVhciBCcmFjZXMpXCIsXG4gICAgICBjYXRlZ29yeTogXCJvcnRob2RvbnRpY3NcIixcbiAgICAgIHNob3J0RGVzYzogXCJTdHJhaWdodGVuIHRlZXRoIGRpc2NyZWV0bHkgd2l0aG91dCBtZXRhbCB3aXJlcyB1c2luZyAzRCBjdXN0b20gY2xlYXIgYWxpZ25lciB0cmF5cy5cIixcbiAgICAgIGZ1bGxEZXNjOiBcIkdldCBhIHBlcmZlY3RseSBhbGlnbmVkIHNtaWxlIHdpdGggY3VzdG9tLWRlc2lnbmVkIDNEIGNsZWFyIGFsaWduZXJzLiBSZW1vdmFibGUsIGNvbWZvcnRhYmxlLCBhbmQgdmlydHVhbGx5IGludmlzaWJsZSBkdXJpbmcgc3BlZWNoIGFuZCBtZWFscy5cIixcbiAgICAgIGljb25OYW1lOiBcIlNtaWxlXCIsXG4gICAgICBwcmljZVJhbmdlOiBcIuKCuTQ1LDAwMCAtIOKCuTEsMjAsMDAwXCIsXG4gICAgICBkdXJhdGlvbjogXCI2IC0gMTQgTW9udGhzIHRvdGFsIHRyZWF0bWVudFwiLFxuICAgICAgcGFpbmxlc3NUZWNoOiBcIjNEIEludHJhb3JhbCBTY2FubmVyIChObyBHYWdneSBJbXByZXNzaW9uIFRyYXlzKVwiLFxuICAgICAgaGlnaGxpZ2h0czogW1wiM0QgRGlnaXRhbCBTbWlsZSBTaW11bGF0aW9uIEJlZm9yZSBTdGFydGluZ1wiLCBcIlZpcnR1YWxseSBJbnZpc2libGVcIiwgXCJFYXQgV2hhdGV2ZXIgWW91IExpa2VcIiwgXCJGcmVlIFJldGFpbmVycyBJbmNsdWRlZFwiXSxcbiAgICAgIHBvcHVsYXI6IHRydWVcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiBcInZlbmVlcnNcIixcbiAgICAgIHRpdGxlOiBcIkhvbGx5d29vZCBTbWlsZSAmIFBvcmNlbGFpbiBWZW5lZXJzXCIsXG4gICAgICBjYXRlZ29yeTogXCJjb3NtZXRpY1wiLFxuICAgICAgc2hvcnREZXNjOiBcIkN1c3RvbS1jcmFmdGVkIHVsdHJhLXRoaW4gcG9yY2VsYWluIHZlbmVlcnMgdG8gY29ycmVjdCBnYXBzLCBjaGlwcywgc3RhaW5zLCBhbmQgbWlzYWxpZ25tZW50cy5cIixcbiAgICAgIGZ1bGxEZXNjOiBcIlRyYW5zZm9ybSB5b3VyIHNtaWxlIGluIGp1c3QgMiB2aXNpdHMhIFByZW1pdW0gR2VybWFuIHBvcmNlbGFpbiB2ZW5lZXJzIGRlc2lnbmVkIGRpZ2l0YWxseSB0byBtYXRjaCB5b3VyIGZhY2lhbCBmZWF0dXJlcywgc2tpbiB0b25lLCBhbmQgbmF0dXJhbCBzbWlsZSBjdXJ2ZS5cIixcbiAgICAgIGljb25OYW1lOiBcIlNwYXJrbGVzXCIsXG4gICAgICBwcmljZVJhbmdlOiBcIuKCuTgsNTAwIC0g4oK5MTgsMDAwIC8gdG9vdGhcIixcbiAgICAgIGR1cmF0aW9uOiBcIjIgVmlzaXRzICg1IERheXMgdG90YWwpXCIsXG4gICAgICBwYWlubGVzc1RlY2g6IFwiTWljcm8tRW5hbWVsIFByZXAgd2l0aCBMYXNlciBQcmVjaXNpb25cIixcbiAgICAgIGhpZ2hsaWdodHM6IFtcIlN0YWluLVJlc2lzdGFudCBHbGFzcyBQb3JjZWxhaW5cIiwgXCJDdXN0b20gU2hhZGUgTWF0Y2hpbmdcIiwgXCIxMC1ZZWFyIEd1YXJhbnRlZVwiLCBcIkRpZ2l0YWwgU21pbGUgRGVzaWduIFByZXZpZXdcIl0sXG4gICAgICBwb3B1bGFyOiB0cnVlXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogXCJ3aGl0ZW5pbmdcIixcbiAgICAgIHRpdGxlOiBcIkxhc2VyIFRlZXRoIFdoaXRlbmluZyAoWm9vbSA0KVwiLFxuICAgICAgY2F0ZWdvcnk6IFwiY29zbWV0aWNcIixcbiAgICAgIHNob3J0RGVzYzogXCJBY2hpZXZlIHVwIHRvIDggc2hhZGVzIHdoaXRlciB0ZWV0aCBpbiA0NSBtaW51dGVzIHdpdGggY29sZCBsYXNlciBMRUQgdGVjaG5vbG9neS5cIixcbiAgICAgIGZ1bGxEZXNjOiBcIkluc3RhbnQsIHNhZmUgdGVldGggd2hpdGVuaW5nIHRoYXQgcmVtb3ZlcyBkZWVwIHRlYSwgY29mZmVlLCBzbW9raW5nLCBhbmQgYWdlIHN0YWlucyB3aXRob3V0IGVuYW1lbCBkYW1hZ2Ugb3IgcG9zdC10cmVhdG1lbnQgc2Vuc2l0aXZpdHkuXCIsXG4gICAgICBpY29uTmFtZTogXCJTdW5cIixcbiAgICAgIHByaWNlUmFuZ2U6IFwi4oK5Niw5OTkgLSDigrkxMiwwMDBcIixcbiAgICAgIGR1cmF0aW9uOiBcIjQ1IE1pbnV0ZXMgc2luZ2xlIHNlc3Npb25cIixcbiAgICAgIHBhaW5sZXNzVGVjaDogXCJEZXNlbnNpdGl6aW5nIE5hbm8taHlkcm94eWFwYXRpdGUgR2VsXCIsXG4gICAgICBoaWdobGlnaHRzOiBbXCJJbnN0YW50IFJlc3VsdHMgaW4gMSBTZXNzaW9uXCIsIFwiU2FmZSBmb3IgVG9vdGggRW5hbWVsXCIsIFwiSW5jbHVkZXMgVGFrZS1Ib21lIFRvdWNodXAgS2l0XCIsIFwiWmVybyBTZW5zaXRpdml0eSBGb3JtdWxhdGlvblwiXSxcbiAgICAgIHBvcHVsYXI6IGZhbHNlXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogXCJyb290Y2FuYWxcIixcbiAgICAgIHRpdGxlOiBcIlBhaW5sZXNzIFNpbmdsZS1WaXNpdCBSb290IENhbmFsIChSQ1QpXCIsXG4gICAgICBjYXRlZ29yeTogXCJyZXN0b3JhdGl2ZVwiLFxuICAgICAgc2hvcnREZXNjOiBcIlNhdmUgaW5mZWN0ZWQgdGVldGggcGFpbmxlc3NseSBpbiBhIHNpbmdsZSA0NS1taW51dGUgc2l0dGluZyB1bmRlciBtaWNyb3Njb3BlIGd1aWRhbmNlLlwiLFxuICAgICAgZnVsbERlc2M6IFwiVXNpbmcgcm90YXJ5IGVuZG9kb250aWMgaW5zdHJ1bWVudHMgYW5kIGFwZXggbG9jYXRvcnMsIHdlIGNsZWFuIGluZmVjdGVkIHJvb3QgY2FuYWxzIHRob3JvdWdobHkgd2l0aCB6ZXJvIHBhaW4sIHByZXNlcnZpbmcgeW91ciBuYXR1cmFsIHJvb3Qgc3RydWN0dXJlLlwiLFxuICAgICAgaWNvbk5hbWU6IFwiU2hpZWxkQWxlcnRcIixcbiAgICAgIHByaWNlUmFuZ2U6IFwi4oK5NCw1MDAgLSDigrk5LDUwMCAvIHRvb3RoXCIsXG4gICAgICBkdXJhdGlvbjogXCI0NSAtIDYwIE1pbnV0ZXMgKFNpbmdsZSBWaXNpdClcIixcbiAgICAgIHBhaW5sZXNzVGVjaDogXCJNaWNyb3Njb3BpYyBSb3RhcnkgRW5kb2RvbnRpY3MgKyBQYWlubGVzcyBXYW5kXCIsXG4gICAgICBoaWdobGlnaHRzOiBbXCJTaW5nbGUgU2l0dGluZyBDb252ZW5pZW5jZVwiLCBcIk1pY3Jvc2NvcGljIFByZWNpc2lvblwiLCBcIkNBRC9DQU0gWmlyY29uaWEgQ3Jvd24gUGFpcmluZ1wiLCBcIlBhaW5sZXNzIExvY2FsaXplZCBBbmVzdGhlc2lhXCJdLFxuICAgICAgcG9wdWxhcjogZmFsc2VcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiBcInBlZGlhdHJpY1wiLFxuICAgICAgdGl0bGU6IFwiS2lkLUZyaWVuZGx5IFBlZGlhdHJpYyBEZW50aXN0cnlcIixcbiAgICAgIGNhdGVnb3J5OiBcInByZXZlbnRpdmVcIixcbiAgICAgIHNob3J0RGVzYzogXCJHZW50bGUgZGVudGFsIGNoZWNrdXBzLCBjYXZpdHkgcHJldmVudGlvbiwgZmx1b3JpZGUgdGhlcmFweSwgYW5kIHByZXZlbnRpdmUgYnJhY2VzIGZvciBjaGlsZHJlbi5cIixcbiAgICAgIGZ1bGxEZXNjOiBcIkEgcGxheWZ1bCwgYW54aWV0eS1mcmVlIGF0bW9zcGhlcmUgZGVzaWduZWQgc3BlY2lmaWNhbGx5IGZvciBraWRzLiBXZSBtYWtlIGRlbnRhbCB2aXNpdHMgZnVuLCBlZHVjYXRpb25hbCwgYW5kIGNvbXBsZXRlbHkgZmVhci1mcmVlLlwiLFxuICAgICAgaWNvbk5hbWU6IFwiSGVhcnRcIixcbiAgICAgIHByaWNlUmFuZ2U6IFwi4oK5OTk5IC0g4oK5Myw1MDBcIixcbiAgICAgIGR1cmF0aW9uOiBcIjMwIE1pbnV0ZXNcIixcbiAgICAgIHBhaW5sZXNzVGVjaDogXCJOaXRyb3VzIE94aWRlIFNlZGF0aW9uICYgR2VudGxlIFRvdWNoXCIsXG4gICAgICBoaWdobGlnaHRzOiBbXCJGZWFyLUZyZWUgS2lkIFN1aXRlXCIsIFwiRmx1b3JpZGUgVmFybmlzaCAmIFNlYWxhbnRzXCIsIFwiSGFiaXQgQ29ycmVjdGlvbiBBcHBsaWFuY2VzXCIsIFwiRnVuIEdpZnQgQmFkZ2VzXCJdLFxuICAgICAgcG9wdWxhcjogZmFsc2VcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiBcImVtZXJnZW5jeVwiLFxuICAgICAgdGl0bGU6IFwiMjQvNyBFbWVyZ2VuY3kgRGVudGFsIFRyYXVtYSBDYXJlXCIsXG4gICAgICBjYXRlZ29yeTogXCJlbWVyZ2VuY3lcIixcbiAgICAgIHNob3J0RGVzYzogXCJJbW1lZGlhdGUgcmVsaWVmIGZvciBzZXZlcmUgdG9vdGhhY2hlcywgYnJva2VuIHRlZXRoLCBibGVlZGluZyBndW1zLCBvciBrbm9ja2VkLW91dCB0ZWV0aC5cIixcbiAgICAgIGZ1bGxEZXNjOiBcIkRlbnRhbCBlbWVyZ2VuY2llcyBzaG91bGRuJ3Qgd2FpdC4gT3VyIHByaW9yaXR5IHRyYXVtYSBjYXJlIHVuaXQgaGFuZGxlcyBhY3V0ZSBwYWluLCBmcmFjdHVyZWQgamF3cywgbG9zdCBjcm93bnMsIGFuZCBzcG9ydHMgaW5qdXJpZXMgaW5zdGFudGx5LlwiLFxuICAgICAgaWNvbk5hbWU6IFwiQWN0aXZpdHlcIixcbiAgICAgIHByaWNlUmFuZ2U6IFwi4oK5MSwyMDAgT253YXJkXCIsXG4gICAgICBkdXJhdGlvbjogXCJJbW1lZGlhdGUgUHJpb3JpdHkgU2xvdFwiLFxuICAgICAgcGFpbmxlc3NUZWNoOiBcIkluc3RhbnQgUGFpbiBCbG9jayBJbmplY3Rpb25cIixcbiAgICAgIGhpZ2hsaWdodHM6IFtcIlNhbWUtRGF5IEVtZXJnZW5jeSBQcmlvcml0eVwiLCBcIlRyYXVtYSAmIEZyYWN0dXJlIENhcmVcIiwgXCJJbnN0YW50IFBhaW4gRWxpbWluYXRpb25cIiwgXCJPbi1DYWxsIEVtZXJnZW5jeSBTdXJnZW9uc1wiXSxcbiAgICAgIHBvcHVsYXI6IHRydWVcbiAgICB9XG4gIF0gYXMgU2VydmljZUl0ZW1bXSxcblxuICBkb2N0b3JzOiBbXG4gICAge1xuICAgICAgaWQ6IFwiZHItYXJhdmluZFwiLFxuICAgICAgbmFtZTogXCJEci4gQXJhdmluZCBTd2FtaW5hdGhhblwiLFxuICAgICAgcm9sZTogXCJDaGllZiBJbXBsYW50b2xvZ2lzdCAmIENvc21ldGljIERlbnRpc3RcIixcbiAgICAgIHF1YWxpZmljYXRpb246IFwiQkRTLCBNRFMgKFByb3N0aG9kb250aWNzICYgSW1wbGFudG9sb2d5KSwgRklDT0kgKFVTQSlcIixcbiAgICAgIGV4cGVyaWVuY2VZZWFyczogMTYsXG4gICAgICBzcGVjaWFsdGllczogW1wiM0QgR3VpZGVkIEltcGxhbnRzXCIsIFwiRnVsbCBNb3V0aCBSZWNvbnN0cnVjdGlvblwiLCBcIkhvbGx5d29vZCBTbWlsZSBWZW5lZXJzXCJdLFxuICAgICAgYmlvOiBcIlRyYWluZWQgaW4gR2VybWFueSBhbmQgdGhlIFVTQSwgRHIuIEFyYXZpbmQgaGFzIHN1Y2Nlc3NmdWxseSBwbGFjZWQgb3ZlciA0LDIwMCBpbXBsYW50cyB3aXRoIGEgOTkuNCUgc3VjY2VzcyByYXRlLiBIZSBzcGVjaWFsaXplcyBpbiBtaW5pbWFsbHkgaW52YXNpdmUgY29tcHV0ZXItZ3VpZGVkIGltcGxhbnQgc3VyZ2VyaWVzLlwiLFxuICAgICAgaW1hZ2U6IFwiaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE2MjIyNTM2OTIwMTAtMzMzZjJkYTYwMzFkP2F1dG89Zm9ybWF0JmZpdD1jcm9wJnc9NjAwJnE9ODBcIixcbiAgICAgIGF2YWlsYWJsZURheXM6IFwiTW9uIC0gU2F0ICg5OjAwIEFNIC0gNTowMCBQTSlcIixcbiAgICAgIHJhdGluZzogNC45LFxuICAgICAgcmV2aWV3c0NvdW50OiA2ODBcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiBcImRyLWFuYW55YVwiLFxuICAgICAgbmFtZTogXCJEci4gQW5hbnlhIE5haXJcIixcbiAgICAgIHJvbGU6IFwiU2VuaW9yIE9ydGhvZG9udGlzdCAmIEludmlzYWxpZ24gU3BlY2lhbGlzdFwiLFxuICAgICAgcXVhbGlmaWNhdGlvbjogXCJNRFMgKE9ydGhvZG9udGljcyAmIERlbnRvZmFjaWFsIE9ydGhvcGVkaWNzKSwgQ2VydGlmaWVkIEludmlzYWxpZ24gUHJvdmlkZXJcIixcbiAgICAgIGV4cGVyaWVuY2VZZWFyczogMTIsXG4gICAgICBzcGVjaWFsdGllczogW1wiQ2xlYXIgQWxpZ25lcnMgLyBJbnZpc2FsaWduXCIsIFwiTGluZ3VhbCBCcmFjZXNcIiwgXCJTdXJnaWNhbCBPcnRob2RvbnRpY3NcIl0sXG4gICAgICBiaW86IFwiRHIuIEFuYW55YSBoYXMgY3JhZnRlZCBvdmVyIDEsNTAwIGFsaWduZXIgc21pbGVzLiBTaGUgYmxlbmRzIGRpZ2l0YWwgZmFjaWFsIGFlc3RoZXRpY3Mgd2l0aCBwcmVjaXNlIG9ydGhvZG9udGljIGJpb21lY2hhbmljcyBmb3IgYmVhdXRpZnVsLCBmdW5jdGlvbmFsIHJlc3VsdHMuXCIsXG4gICAgICBpbWFnZTogXCJodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTU5NDgyNDgxMzU2Ni03OGE5OTQ3OWI2MzQ/YXV0bz1mb3JtYXQmZml0PWNyb3Amdz02MDAmcT04MFwiLFxuICAgICAgYXZhaWxhYmxlRGF5czogXCJNb24gLSBTYXQgKDEwOjAwIEFNIC0gNzowMCBQTSlcIixcbiAgICAgIHJhdGluZzogNC45LFxuICAgICAgcmV2aWV3c0NvdW50OiA1MjBcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiBcImRyLXJvaGl0XCIsXG4gICAgICBuYW1lOiBcIkRyLiBSb2hpdCBNZW5vblwiLFxuICAgICAgcm9sZTogXCJFbmRvZG9udGlzdCAmIExhc2VyIFNwZWNpYWxpc3RcIixcbiAgICAgIHF1YWxpZmljYXRpb246IFwiTURTIChDb25zZXJ2YXRpdmUgRGVudGlzdHJ5ICYgRW5kb2RvbnRpY3MpLCBEaUxBIChMYXNlciBDZXJ0LiBHZXJtYW55KVwiLFxuICAgICAgZXhwZXJpZW5jZVllYXJzOiAxMCxcbiAgICAgIHNwZWNpYWx0aWVzOiBbXCJTaW5nbGUtVmlzaXQgUGFpbmxlc3MgUkNUXCIsIFwiTWljcm9zY29waWMgRGVudGlzdHJ5XCIsIFwiTGFzZXIgR3VtIFRoZXJhcHlcIl0sXG4gICAgICBiaW86IFwiRXhwZXJ0IGluIHByZXNlcnZpbmcgbmF0dXJhbCB0ZWV0aCB3aXRoIHplcm8gcGFpbi4gRHIuIFJvaGl0IHBlcmZvcm1zIGhpZ2gtcHJlY2lzaW9uIHJvb3QgY2FuYWxzIHVuZGVyIHN1cmdpY2FsIG1pY3Jvc2NvcGUgd2l0aCBsYXNlciBzdGVyaWxpemF0aW9uLlwiLFxuICAgICAgaW1hZ2U6IFwiaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1MzczNjg5MTAwMjUtNzAwMzUwZmU0NmM3P2F1dG89Zm9ybWF0JmZpdD1jcm9wJnc9NjAwJnE9ODBcIixcbiAgICAgIGF2YWlsYWJsZURheXM6IFwiTW9uIC0gU2F0ICgxMTowMCBBTSAtIDg6MDAgUE0pXCIsXG4gICAgICByYXRpbmc6IDQuOCxcbiAgICAgIHJldmlld3NDb3VudDogMzkwXG4gICAgfVxuICBdIGFzIERvY3RvcltdLFxuXG4gIHRyYW5zZm9ybWF0aW9uczogW1xuICAgIHtcbiAgICAgIGlkOiBcImNhc2UtMVwiLFxuICAgICAgdHJlYXRtZW50TmFtZTogXCJGdWxsIFVwcGVyIEFyY2ggSW52aXNhbGlnbiBBbGlnbm1lbnRcIixcbiAgICAgIHBhdGllbnROYW1lOiBcIk1lZXJhIFIuLCAyOFwiLFxuICAgICAgY2F0ZWdvcnk6IFwiSW52aXNhbGlnbiBDbGVhciBBbGlnbmVyc1wiLFxuICAgICAgYmVmb3JlSW1hZ2U6IFwiaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1ODg3NzY4MTQ1NDYtMWZmY2Y0NzI2N2E1P2F1dG89Zm9ybWF0JmZpdD1jcm9wJnc9NjAwJnE9ODBcIixcbiAgICAgIGFmdGVySW1hZ2U6IFwiaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1MzQ1Mjg3NDE3NzUtNTM5OTRhNjlkYWViP2F1dG89Zm9ybWF0JmZpdD1jcm9wJnc9NjAwJnE9ODBcIixcbiAgICAgIGR1cmF0aW9uOiBcIjggTW9udGhzXCIsXG4gICAgICBkZW50aXN0TmFtZTogXCJEci4gQW5hbnlhIE5haXJcIixcbiAgICAgIGRlc2NyaXB0aW9uOiBcIkNvcnJlY3RlZCBzZXZlcmUgb3ZlcmNyb3dkaW5nIGFuZCBkZWVwIGJpdGUgdXNpbmcgY3VzdG9tIDNEIGFsaWduZXIgc2VyaWVzIHdpdGhvdXQgYW55IG1ldGFsIGJyYWNlcy5cIlxuICAgIH0sXG4gICAge1xuICAgICAgaWQ6IFwiY2FzZS0yXCIsXG4gICAgICB0cmVhdG1lbnROYW1lOiBcIjEwLVRvb3RoIFBvcmNlbGFpbiBWZW5lZXIgTWFrZW92ZXJcIixcbiAgICAgIHBhdGllbnROYW1lOiBcIlJhaHVsIFYuLCAzNVwiLFxuICAgICAgY2F0ZWdvcnk6IFwiQ29zbWV0aWMgVmVuZWVyc1wiLFxuICAgICAgYmVmb3JlSW1hZ2U6IFwiaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1MDcwMDMyMTExNjktMGExZGQ3MjI4ZjJkP2F1dG89Zm9ybWF0JmZpdD1jcm9wJnc9NjAwJnE9ODBcIixcbiAgICAgIGFmdGVySW1hZ2U6IFwiaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE1MDA2NDg3Njc3OTEtMDBkY2M5OTRhNDNlP2F1dG89Zm9ybWF0JmZpdD1jcm9wJnc9NjAwJnE9ODBcIixcbiAgICAgIGR1cmF0aW9uOiBcIjIgVmlzaXRzICg0IERheXMpXCIsXG4gICAgICBkZW50aXN0TmFtZTogXCJEci4gQXJhdmluZCBTd2FtaW5hdGhhblwiLFxuICAgICAgZGVzY3JpcHRpb246IFwiVHJhbnNmb3JtZWQgY2hpcHBlZCwgZGlzY29sb3JlZCBmcm9udCB0ZWV0aCBpbnRvIGEgcmFkaWFudCwgc3ltbWV0cmljIEhvbGx5d29vZCBzbWlsZS5cIlxuICAgIH0sXG4gICAge1xuICAgICAgaWQ6IFwiY2FzZS0zXCIsXG4gICAgICB0cmVhdG1lbnROYW1lOiBcIlNhbWUtRGF5IEd1aWRlZCBEZW50YWwgSW1wbGFudFwiLFxuICAgICAgcGF0aWVudE5hbWU6IFwiU2lkZGhhcnRoIEsuLCA0MlwiLFxuICAgICAgY2F0ZWdvcnk6IFwiRGVudGFsIEltcGxhbnRzXCIsXG4gICAgICBiZWZvcmVJbWFnZTogXCJodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTUwNjc5NDc3ODIwMi1jYWQ4NGNmNDVmMWQ/YXV0bz1mb3JtYXQmZml0PWNyb3Amdz02MDAmcT04MFwiLFxuICAgICAgYWZ0ZXJJbWFnZTogXCJodHRwczovL2ltYWdlcy51bnNwbGFzaC5jb20vcGhvdG8tMTUxOTA4NTM2MDc1My1hZjAxMTlmN2NiZTc/YXV0bz1mb3JtYXQmZml0PWNyb3Amdz02MDAmcT04MFwiLFxuICAgICAgZHVyYXRpb246IFwiU2luZ2xlIFNpdHRpbmcgKyBDcm93blwiLFxuICAgICAgZGVudGlzdE5hbWU6IFwiRHIuIEFyYXZpbmQgU3dhbWluYXRoYW5cIixcbiAgICAgIGRlc2NyaXB0aW9uOiBcIlJlcGxhY2VkIGEgZnJhY3R1cmVkIGZyb250IHRvb3RoIHdpdGgga2V5aG9sZSB0aXRhbml1bSBpbXBsYW50IGFuZCBpbW1lZGlhdGUgZXN0aGV0aWMgcHJvdmlzaW9uYWwgY3Jvd24uXCJcbiAgICB9XG4gIF0gYXMgQmVmb3JlQWZ0ZXJDYXNlW10sXG5cbiAgcHJpY2luZ1BsYW5zOiBbXG4gICAge1xuICAgICAgaWQ6IFwicGxhbi1jaGVja3VwXCIsXG4gICAgICBuYW1lOiBcIkNvbXByZWhlbnNpdmUgUHJldmVudGl2ZSBDaGVja3VwXCIsXG4gICAgICBjYXRlZ29yeTogXCJQcmV2ZW50aXZlIENhcmVcIixcbiAgICAgIHByaWNlOiBcIuKCuTk5OVwiLFxuICAgICAgb3JpZ2luYWxQcmljZTogXCLigrkyLDUwMFwiLFxuICAgICAgZW1pQXZhaWxhYmxlOiBmYWxzZSxcbiAgICAgIGZlYXR1cmVzOiBbXG4gICAgICAgIFwiRnVsbCBNb3V0aCAzRCBJbnRyYW9yYWwgRGlnaXRhbCBTY2FuXCIsXG4gICAgICAgIFwiSEQgRGlnaXRhbCBYLVJheXMgKFJWRylcIixcbiAgICAgICAgXCJVbHRyYXNvbmljIFNjYWxpbmcgJiBUb290aCBQb2xpc2hpbmdcIixcbiAgICAgICAgXCJPcmFsIENhbmNlciBTY3JlZW5pbmcgJiBHdW0gQXNzZXNzbWVudFwiLFxuICAgICAgICBcIlBlcnNvbmFsaXplZCBUcmVhdG1lbnQgUGxhbiAmIENvbnN1bHRhdGlvblwiXG4gICAgICBdLFxuICAgICAgcG9wdWxhcjogZmFsc2VcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiBcInBsYW4td2hpdGVuaW5nXCIsXG4gICAgICBuYW1lOiBcIlpvb20gNCBMYXNlciBXaGl0ZW5pbmdcIixcbiAgICAgIGNhdGVnb3J5OiBcIkNvc21ldGljIERlbnRpc3RyeVwiLFxuICAgICAgcHJpY2U6IFwi4oK5Niw5OTlcIixcbiAgICAgIG9yaWdpbmFsUHJpY2U6IFwi4oK5MTIsMDAwXCIsXG4gICAgICBlbWlBdmFpbGFibGU6IHRydWUsXG4gICAgICBlbWlTdGFydGluZ0F0OiBcIuKCuTEsMTY2IC8gbW8gKDYgbW8gRU1JKVwiLFxuICAgICAgZmVhdHVyZXM6IFtcbiAgICAgICAgXCJVcCB0byA4IFNoYWRlcyBXaGl0ZXIgaW4gNDUgTWluc1wiLFxuICAgICAgICBcIkdlcm1hbiBDb2xkLUxFRCBUZWNobm9sb2d5XCIsXG4gICAgICAgIFwiWmVyby1TZW5zaXRpdml0eSBOYW5vIFByb3RlY3Rpb25cIixcbiAgICAgICAgXCJJbmNsdWRlcyBUYWtlLUhvbWUgQ2FyZSBLaXRcIixcbiAgICAgICAgXCJGcmVlIEZvbGxvdy11cCBQb2xpc2ggaW4gNiBNb250aHNcIlxuICAgICAgXSxcbiAgICAgIHBvcHVsYXI6IHRydWVcbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiBcInBsYW4taW1wbGFudFwiLFxuICAgICAgbmFtZTogXCJQcmVtaXVtIFppcmNvbmlhIERlbnRhbCBJbXBsYW50XCIsXG4gICAgICBjYXRlZ29yeTogXCJSZXN0b3JhdGl2ZSBEZW50aXN0cnlcIixcbiAgICAgIHByaWNlOiBcIuKCuTI4LDUwMFwiLFxuICAgICAgb3JpZ2luYWxQcmljZTogXCLigrkzOCwwMDBcIixcbiAgICAgIGVtaUF2YWlsYWJsZTogdHJ1ZSxcbiAgICAgIGVtaVN0YXJ0aW5nQXQ6IFwi4oK5MiwzNzUgLyBtbyAoMTIgbW8gRU1JKVwiLFxuICAgICAgZmVhdHVyZXM6IFtcbiAgICAgICAgXCJDb21wdXRlci1HdWlkZWQgS2V5aG9sZSBTdXJnZXJ5XCIsXG4gICAgICAgIFwiVVMtRkRBIEFwcHJvdmVkIFRpdGFuaXVtIEFidXRtZW50XCIsXG4gICAgICAgIFwiMTAwJSBNZXRhbC1GcmVlIFppcmNvbmlhIENyb3duXCIsXG4gICAgICAgIFwiTGlmZXRpbWUgR3VhcmFudGVlIENlcnRpZmljYXRlXCIsXG4gICAgICAgIFwiRnJlZSAzRCBDVCBTY2FuIChDQkNUKSBJbmNsdWRlZFwiXG4gICAgICBdLFxuICAgICAgcG9wdWxhcjogdHJ1ZVxuICAgIH1cbiAgXSBhcyBQcmljaW5nUGxhbltdLFxuXG4gIGluc3VyYW5jZVBhcnRuZXJzOiBbXG4gICAgeyBuYW1lOiBcIlN0YXIgSGVhbHRoIEluc3VyYW5jZVwiLCBsb2dvVGV4dDogXCJTdGFyIEhlYWx0aFwiIH0sXG4gICAgeyBuYW1lOiBcIkhERkMgRVJHTyBIZWFsdGhcIiwgbG9nb1RleHQ6IFwiSERGQyBFUkdPXCIgfSxcbiAgICB7IG5hbWU6IFwiSUNJQ0kgTG9tYmFyZFwiLCBsb2dvVGV4dDogXCJJQ0lDSSBMb21iYXJkXCIgfSxcbiAgICB7IG5hbWU6IFwiTWF4IEJ1cGEgLyBOaXZhIEJ1cGFcIiwgbG9nb1RleHQ6IFwiTml2YSBCdXBhXCIgfSxcbiAgICB7IG5hbWU6IFwiQ2FyZSBIZWFsdGggSW5zdXJhbmNlXCIsIGxvZ29UZXh0OiBcIkNhcmUgSGVhbHRoXCIgfSxcbiAgICB7IG5hbWU6IFwiQmFqYWogQWxsaWFuelwiLCBsb2dvVGV4dDogXCJCYWphaiBBbGxpYW56XCIgfVxuICBdLFxuXG4gIHRlc3RpbW9uaWFsczogW1xuICAgIHtcbiAgICAgIGlkOiBcInQxXCIsXG4gICAgICBuYW1lOiBcIkRyLiBMYWtzaG1pIFByYXNhZFwiLFxuICAgICAgcm9sZTogXCJQcm9mZXNzb3IgJiBQYXRpZW50XCIsXG4gICAgICByYXRpbmc6IDUsXG4gICAgICBjb21tZW50OiBcIkkgd2FzIHRlcnJpZmllZCBvZiBkZW50YWwgaW1wbGFudHMgdW50aWwgSSB2aXNpdGVkIEFwZXhDYXJlLiBEci4gQXJhdmluZCB1c2VkIDNEIGNvbXB1dGVyIGd1aWRhbmNlIOKAlCB0aGUgZW50aXJlIHByb2NlZHVyZSB0b29rIGxlc3MgdGhhbiA0NSBtaW51dGVzIGFuZCBJIGV4cGVyaWVuY2VkIGFic29sdXRlbHkgemVybyBwYWluISBIaWdobHkgcmVjb21tZW5kZWQgc3R1ZGlvLlwiLFxuICAgICAgdHJlYXRtZW50OiBcIkNvbXB1dGVyLUd1aWRlZCBJbXBsYW50XCIsXG4gICAgICBkYXRlOiBcIjIgd2Vla3MgYWdvXCIsXG4gICAgICB2ZXJpZmllZDogdHJ1ZVxuICAgIH0sXG4gICAge1xuICAgICAgaWQ6IFwidDJcIixcbiAgICAgIG5hbWU6IFwiVmlzaG51IE1vaGFuXCIsXG4gICAgICByb2xlOiBcIlNvZnR3YXJlIEFyY2hpdGVjdFwiLFxuICAgICAgcmF0aW5nOiA1LFxuICAgICAgY29tbWVudDogXCJHb3QgbXkgSW52aXNhbGlnbiBhbGlnbmVycyBkb25lIGhlcmUgd2l0aCBEci4gQW5hbnlhLiBUaGUgM0Qgc2NhbiBwcmV2aWV3IGJlZm9yZSBzdGFydGluZyBnYXZlIG1lIHRvdGFsIGNvbmZpZGVuY2UuIFRvZGF5IG15IHRlZXRoIGFyZSBjb21wbGV0ZWx5IHN0cmFpZ2h0IGFuZCBub2JvZHkgZXZlbiBub3RpY2VkIEkgaGFkIGFsaWduZXJzIG9uIVwiLFxuICAgICAgdHJlYXRtZW50OiBcIkludmlzYWxpZ24gQ2xlYXIgQWxpZ25lcnNcIixcbiAgICAgIGRhdGU6IFwiMSBtb250aCBhZ29cIixcbiAgICAgIHZlcmlmaWVkOiB0cnVlXG4gICAgfSxcbiAgICB7XG4gICAgICBpZDogXCJ0M1wiLFxuICAgICAgbmFtZTogXCJQcml5YSBOYWlyXCIsXG4gICAgICByb2xlOiBcIkZhc2hpb24gRGVzaWduZXJcIixcbiAgICAgIHJhdGluZzogNSxcbiAgICAgIGNvbW1lbnQ6IFwiVGhlIEhvbGx5d29vZCBTbWlsZSBwb3JjZWxhaW4gdmVuZWVycyBkb25lIGJ5IERyLiBBcmF2aW5kIHRyYW5zZm9ybWVkIG15IGNvbmZpZGVuY2UgY29tcGxldGVseS4gVGhlIGNsaW5pYyBsb29rcyBsaWtlIGEgbHV4dXJ5IGxvdW5nZSBhbmQgdGhlaXIgc3RlcmlsaXphdGlvbiBzdGFuZGFyZHMgYXJlIHRvcC1ub3RjaC5cIixcbiAgICAgIHRyZWF0bWVudDogXCJQb3JjZWxhaW4gVmVuZWVyc1wiLFxuICAgICAgZGF0ZTogXCIzIHdlZWtzIGFnb1wiLFxuICAgICAgdmVyaWZpZWQ6IHRydWVcbiAgICB9XG4gIF0sXG5cbiAgZmFxczogW1xuICAgIHtcbiAgICAgIHF1ZXN0aW9uOiBcIkFyZSBkZW50YWwgdHJlYXRtZW50cyBhdCBBcGV4Q2FyZSByZWFsbHkgcGFpbmxlc3M/XCIsXG4gICAgICBhbnN3ZXI6IFwiWWVzISBXZSB1dGlsaXplIGNvbXB1dGVyLWNvbnRyb2xsZWQgV2FuZCBsb2NhbCBhbmVzdGhlc2lhLCBuZWVkbGUtZnJlZSBpbmplY3Rpb25zLCBuaXRyb3VzIG94aWRlIGRlbnRhbCBzZWRhdGlvbiwgYW5kIGNvbGQgbGFzZXIgdGVjaG5vbG9neS4gTW9zdCBwYXRpZW50cyBmZWVsIG5vIHBhaW4gZHVyaW5nIG9yIGFmdGVyIHByb2NlZHVyZXMuXCJcbiAgICB9LFxuICAgIHtcbiAgICAgIHF1ZXN0aW9uOiBcIkhvdyBsb25nIGRvZXMgYSBjbGVhciBhbGlnbmVyIChJbnZpc2FsaWduKSB0cmVhdG1lbnQgdGFrZT9cIixcbiAgICAgIGFuc3dlcjogXCJUcmVhdG1lbnQgdGltZXMgcmFuZ2UgZnJvbSA2IHRvIDE0IG1vbnRocyBkZXBlbmRpbmcgb24gY29tcGxleGl0eS4gV2l0aCBvdXIgM0QgZGlnaXRhbCBzY2FubmVyLCB5b3Ugd2lsbCBzZWUgYSBzdGVwLWJ5LXN0ZXAgdmlydHVhbCBtb2RlbCBvZiB5b3VyIGZ1dHVyZSBzbWlsZSBkdXJpbmcgeW91ciBmaXJzdCBjb25zdWx0YXRpb24uXCJcbiAgICB9LFxuICAgIHtcbiAgICAgIHF1ZXN0aW9uOiBcIkRvIHlvdSBvZmZlciAwJSBpbnRlcmVzdCBFTUkgcGF5bWVudCBvcHRpb25zP1wiLFxuICAgICAgYW5zd2VyOiBcIlllcyEgV2UgcGFydG5lciB3aXRoIG1ham9yIGJhbmtzIGFuZCBoZWFsdGhjYXJlIGZpbnRlY2hzIHRvIG9mZmVyIDMsIDYsIDksIGFuZCAxMi1tb250aCAwJSBpbnRlcmVzdCBFTUkgb3B0aW9ucyB3aXRoIG5vIGhpZGRlbiBmZWVzIGFuZCBpbnN0YW50IGFwcHJvdmFsLlwiXG4gICAgfSxcbiAgICB7XG4gICAgICBxdWVzdGlvbjogXCJDYW4gSSBnZXQgYSBkZW50YWwgaW1wbGFudCBkb25lIG9uIHRoZSBzYW1lIGRheSBhcyBleHRyYWN0aW9uP1wiLFxuICAgICAgYW5zd2VyOiBcIkluIG1vc3QgY2FzZXMsIHllcyEgSW1tZWRpYXRlIGxvYWRpbmcgaW1wbGFudHMgYWxsb3cgdXMgdG8gcGxhY2UgdGhlIGltcGxhbnQgYW5kIGZpdCBhIG5hdHVyYWwgdGVtcG9yYXJ5IGNyb3duIGluIGEgc2luZ2xlIDQ1LW1pbnV0ZSB2aXNpdC5cIlxuICAgIH0sXG4gICAge1xuICAgICAgcXVlc3Rpb246IFwiV2hhdCBzYWZldHkgYW5kIHN0ZXJpbGl6YXRpb24gcHJvdG9jb2xzIGRvIHlvdSBmb2xsb3c/XCIsXG4gICAgICBhbnN3ZXI6IFwiV2UgYWRoZXJlIHN0cmljdGx5IHRvIENsYXNzLUIgQXV0b2NsYXZlIDctc3RlcCBzdGVyaWxpemF0aW9uIHByb3RvY29scyByZWNvbW1lbmRlZCBieSB0aGUgQ0RDIGFuZCBXSE8uIEV2ZXJ5IGluc3RydW1lbnQgaXMgaW5kaXZpZHVhbGx5IHNlYWxlZCBpbiBzdGVyaWxlIHBvdWNoZXMgb3BlbmVkIGluIGZyb250IG9mIHlvdS5cIlxuICAgIH1cbiAgXSxcblxuICBzeW1wdG9tUXVpejogW1xuICAgIHtcbiAgICAgIGlkOiBcInExXCIsXG4gICAgICBxdWVzdGlvbjogXCJXaGF0IGlzIHlvdXIgbWFpbiBkZW50YWwgY29uY2Vybj9cIixcbiAgICAgIG9wdGlvbnM6IFtcbiAgICAgICAgeyB0ZXh0OiBcIk1pc3Npbmcgb3IgbG9zdCB0ZWV0aFwiLCBtYXRjaFNlcnZpY2U6IFwiaW1wbGFudHNcIiB9LFxuICAgICAgICB7IHRleHQ6IFwiQ3Jvb2tlZCBvciBjcm93ZGVkIHRlZXRoXCIsIG1hdGNoU2VydmljZTogXCJpbnZpc2FsaWduXCIgfSxcbiAgICAgICAgeyB0ZXh0OiBcIkRpc2NvbG9yZWQgb3Igc3RhaW5lZCBzbWlsZVwiLCBtYXRjaFNlcnZpY2U6IFwid2hpdGVuaW5nXCIgfSxcbiAgICAgICAgeyB0ZXh0OiBcIlNldmVyZSB0b290aCBwYWluIG9yIHRvb3RoYWNoZVwiLCBtYXRjaFNlcnZpY2U6IFwicm9vdGNhbmFsXCIgfSxcbiAgICAgICAgeyB0ZXh0OiBcIkRlc2lyZSBhIGNlbGVicml0eSBzbWlsZSBtYWtlb3ZlclwiLCBtYXRjaFNlcnZpY2U6IFwidmVuZWVyc1wiIH1cbiAgICAgIF1cbiAgICB9LFxuICAgIHtcbiAgICAgIGlkOiBcInEyXCIsXG4gICAgICBxdWVzdGlvbjogXCJIb3cgdXJnZW50bHkgZG8geW91IHJlcXVpcmUgdHJlYXRtZW50P1wiLFxuICAgICAgb3B0aW9uczogW1xuICAgICAgICB7IHRleHQ6IFwiSW1tZWRpYXRlbHkgKFdpdGhpbiAyNCBIb3VycyAvIEVtZXJnZW5jeSlcIiB9LFxuICAgICAgICB7IHRleHQ6IFwiVGhpcyBXZWVrXCIgfSxcbiAgICAgICAgeyB0ZXh0OiBcIlBsYW5uaW5nIGZvciBOZXh0IE1vbnRoXCIgfVxuICAgICAgXVxuICAgIH1cbiAgXVxufTtcbiJdfQ==