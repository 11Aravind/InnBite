import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport17_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=383ccf5c";
import { ThemeProvider } from "/src/context/ThemeContext.tsx";
import { Navbar } from "/src/components/Navbar.tsx";
import { HeroSection } from "/src/components/HeroSection.tsx";
import { TrustMetrics } from "/src/components/TrustMetrics.tsx";
import { ServicesSection } from "/src/components/ServicesSection.tsx";
import { SmileGallerySection } from "/src/components/SmileGallerySection.tsx";
import { InteractiveToolsSection } from "/src/components/InteractiveToolsSection.tsx";
import { PainlessTechSection } from "/src/components/PainlessTechSection.tsx";
import { DoctorsSection } from "/src/components/DoctorsSection.tsx";
import { TestimonialsSection } from "/src/components/TestimonialsSection.tsx";
import { PricingInsuranceSection } from "/src/components/PricingInsuranceSection.tsx";
import { FAQSection } from "/src/components/FAQSection.tsx";
import { ContactMapSection } from "/src/components/ContactMapSection.tsx";
import { Footer } from "/src/components/Footer.tsx";
import { AppointmentModal } from "/src/components/AppointmentModal.tsx";
import { FloatingEmergencyWidget } from "/src/components/FloatingEmergencyWidget.tsx";
var _jsxFileName = "D:/Aravind-Works/Dentel clinic/src/App.tsx";
import __vite__cjsImport17_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=383ccf5c";
var _s = $RefreshSig$();
export function DentalStudioApp() {
	_s();
	const [bookingModalOpen, setBookingModalOpen] = useState(false);
	const [selectedServiceId, setSelectedServiceId] = useState(undefined);
	const [selectedDoctorId, setSelectedDoctorId] = useState(undefined);
	const handleOpenBooking = (serviceId, doctorId) => {
		setSelectedServiceId(serviceId);
		setSelectedDoctorId(doctorId);
		setBookingModalOpen(true);
	};
	const handleCloseBooking = () => {
		setBookingModalOpen(false);
		setSelectedServiceId(undefined);
		setSelectedDoctorId(undefined);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "min-h-screen flex flex-col font-sans selection:bg-sky-500 selection:text-white",
		children: [
			/* @__PURE__ */ _jsxDEV(Navbar, { onOpenBooking: handleOpenBooking }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 39,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1",
				children: [
					/* @__PURE__ */ _jsxDEV(HeroSection, { onOpenBooking: handleOpenBooking }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 43,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(TrustMetrics, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(ServicesSection, { onOpenBooking: handleOpenBooking }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(SmileGallerySection, { onOpenBooking: handleOpenBooking }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(InteractiveToolsSection, { onOpenBooking: handleOpenBooking }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(PainlessTechSection, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(DoctorsSection, { onOpenBooking: handleOpenBooking }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(TestimonialsSection, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(PricingInsuranceSection, { onOpenBooking: handleOpenBooking }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(FAQSection, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(ContactMapSection, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 42,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Footer, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(AppointmentModal, {
				isOpen: bookingModalOpen,
				onClose: handleCloseBooking,
				initialServiceId: selectedServiceId,
				initialDoctorId: selectedDoctorId
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 60,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(FloatingEmergencyWidget, { onOpenBooking: () => handleOpenBooking() }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 37,
		columnNumber: 5
	}, this);
}
_s(DentalStudioApp, "cWikyhGAinJXYsuV6SDQ5D1xQ00=");
_c = DentalStudioApp;
export default function App() {
	return /* @__PURE__ */ _jsxDEV(ThemeProvider, { children: /* @__PURE__ */ _jsxDEV(DentalStudioApp, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 76,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 75,
		columnNumber: 5
	}, this);
}
_c2 = App;
var _c, _c2;
$RefreshReg$(_c, "DentalStudioApp");
$RefreshReg$(_c2, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Aravind-Works/Dentel clinic/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Aravind-Works/Dentel clinic/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Aravind-Works/Dentel clinic/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLHFCQUFxQjtBQUM5QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUywyQkFBMkI7QUFDcEMsU0FBUywrQkFBK0I7QUFDeEMsU0FBUywyQkFBMkI7QUFDcEMsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUywyQkFBMkI7QUFDcEMsU0FBUywrQkFBK0I7QUFDeEMsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyx5QkFBeUI7QUFDbEMsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMsK0JBQStCOzs7O0FBRXhDLE9BQU8sU0FBUyxrQkFBa0I7O0NBQ2hDLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQVMsS0FBSztDQUM5RCxNQUFNLENBQUMsbUJBQW1CLHdCQUF3QixTQUE2QixTQUFTO0NBQ3hGLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQTZCLFNBQVM7Q0FFdEYsTUFBTSxxQkFBcUIsV0FBb0IsYUFBc0I7RUFDbkUscUJBQXFCLFNBQVM7RUFDOUIsb0JBQW9CLFFBQVE7RUFDNUIsb0JBQW9CLElBQUk7Q0FDMUI7Q0FFQSxNQUFNLDJCQUEyQjtFQUMvQixvQkFBb0IsS0FBSztFQUN6QixxQkFBcUIsU0FBUztFQUM5QixvQkFBb0IsU0FBUztDQUMvQjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUVFLHdCQUFDLFFBQUQsRUFBUSxlQUFlLGtCQUFvQjs7Ozs7R0FHM0Msd0JBQUMsUUFBRDtJQUFNLFdBQVU7Y0FBaEI7S0FDRSx3QkFBQyxhQUFELEVBQWEsZUFBZSxrQkFBb0I7Ozs7O0tBQ2hELHdCQUFDLGNBQUQsQ0FBZTs7Ozs7S0FDZix3QkFBQyxpQkFBRCxFQUFpQixlQUFlLGtCQUFvQjs7Ozs7S0FDcEQsd0JBQUMscUJBQUQsRUFBcUIsZUFBZSxrQkFBb0I7Ozs7O0tBQ3hELHdCQUFDLHlCQUFELEVBQXlCLGVBQWUsa0JBQW9COzs7OztLQUM1RCx3QkFBQyxxQkFBRCxDQUFzQjs7Ozs7S0FDdEIsd0JBQUMsZ0JBQUQsRUFBZ0IsZUFBZSxrQkFBb0I7Ozs7O0tBQ25ELHdCQUFDLHFCQUFELENBQXNCOzs7OztLQUN0Qix3QkFBQyx5QkFBRCxFQUF5QixlQUFlLGtCQUFvQjs7Ozs7S0FDNUQsd0JBQUMsWUFBRCxDQUFhOzs7OztLQUNiLHdCQUFDLG1CQUFELENBQW9COzs7OztJQUNoQjs7Ozs7O0dBR04sd0JBQUMsUUFBRCxDQUFTOzs7OztHQUdULHdCQUFDLGtCQUFEO0lBQ0UsUUFBUTtJQUNSLFNBQVM7SUFDVCxrQkFBa0I7SUFDbEIsaUJBQWlCO0dBQ2xCOzs7OztHQUdELHdCQUFDLHlCQUFELEVBQXlCLHFCQUFxQixrQkFBa0IsRUFBSTs7Ozs7RUFDakU7Ozs7OztBQUVUOzs7QUFFQSxlQUFlLFNBQVMsTUFBTTtDQUM1QixPQUNFLHdCQUFDLGVBQUQsWUFDRSx3QkFBQyxpQkFBRCxDQUFrQjs7OztVQUNMOzs7OztBQUVuQiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFRoZW1lUHJvdmlkZXIgfSBmcm9tICdAL2NvbnRleHQvVGhlbWVDb250ZXh0JztcbmltcG9ydCB7IE5hdmJhciB9IGZyb20gJ0AvY29tcG9uZW50cy9OYXZiYXInO1xuaW1wb3J0IHsgSGVyb1NlY3Rpb24gfSBmcm9tICdAL2NvbXBvbmVudHMvSGVyb1NlY3Rpb24nO1xuaW1wb3J0IHsgVHJ1c3RNZXRyaWNzIH0gZnJvbSAnQC9jb21wb25lbnRzL1RydXN0TWV0cmljcyc7XG5pbXBvcnQgeyBTZXJ2aWNlc1NlY3Rpb24gfSBmcm9tICdAL2NvbXBvbmVudHMvU2VydmljZXNTZWN0aW9uJztcbmltcG9ydCB7IFNtaWxlR2FsbGVyeVNlY3Rpb24gfSBmcm9tICdAL2NvbXBvbmVudHMvU21pbGVHYWxsZXJ5U2VjdGlvbic7XG5pbXBvcnQgeyBJbnRlcmFjdGl2ZVRvb2xzU2VjdGlvbiB9IGZyb20gJ0AvY29tcG9uZW50cy9JbnRlcmFjdGl2ZVRvb2xzU2VjdGlvbic7XG5pbXBvcnQgeyBQYWlubGVzc1RlY2hTZWN0aW9uIH0gZnJvbSAnQC9jb21wb25lbnRzL1BhaW5sZXNzVGVjaFNlY3Rpb24nO1xuaW1wb3J0IHsgRG9jdG9yc1NlY3Rpb24gfSBmcm9tICdAL2NvbXBvbmVudHMvRG9jdG9yc1NlY3Rpb24nO1xuaW1wb3J0IHsgVGVzdGltb25pYWxzU2VjdGlvbiB9IGZyb20gJ0AvY29tcG9uZW50cy9UZXN0aW1vbmlhbHNTZWN0aW9uJztcbmltcG9ydCB7IFByaWNpbmdJbnN1cmFuY2VTZWN0aW9uIH0gZnJvbSAnQC9jb21wb25lbnRzL1ByaWNpbmdJbnN1cmFuY2VTZWN0aW9uJztcbmltcG9ydCB7IEZBUVNlY3Rpb24gfSBmcm9tICdAL2NvbXBvbmVudHMvRkFRU2VjdGlvbic7XG5pbXBvcnQgeyBDb250YWN0TWFwU2VjdGlvbiB9IGZyb20gJ0AvY29tcG9uZW50cy9Db250YWN0TWFwU2VjdGlvbic7XG5pbXBvcnQgeyBGb290ZXIgfSBmcm9tICdAL2NvbXBvbmVudHMvRm9vdGVyJztcbmltcG9ydCB7IEFwcG9pbnRtZW50TW9kYWwgfSBmcm9tICdAL2NvbXBvbmVudHMvQXBwb2ludG1lbnRNb2RhbCc7XG5pbXBvcnQgeyBGbG9hdGluZ0VtZXJnZW5jeVdpZGdldCB9IGZyb20gJ0AvY29tcG9uZW50cy9GbG9hdGluZ0VtZXJnZW5jeVdpZGdldCc7XG5cbmV4cG9ydCBmdW5jdGlvbiBEZW50YWxTdHVkaW9BcHAoKSB7XG4gIGNvbnN0IFtib29raW5nTW9kYWxPcGVuLCBzZXRCb29raW5nTW9kYWxPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgW3NlbGVjdGVkU2VydmljZUlkLCBzZXRTZWxlY3RlZFNlcnZpY2VJZF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCB1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XG4gIGNvbnN0IFtzZWxlY3RlZERvY3RvcklkLCBzZXRTZWxlY3RlZERvY3RvcklkXSA9IHVzZVN0YXRlPHN0cmluZyB8IHVuZGVmaW5lZD4odW5kZWZpbmVkKTtcblxuICBjb25zdCBoYW5kbGVPcGVuQm9va2luZyA9IChzZXJ2aWNlSWQ/OiBzdHJpbmcsIGRvY3RvcklkPzogc3RyaW5nKSA9PiB7XG4gICAgc2V0U2VsZWN0ZWRTZXJ2aWNlSWQoc2VydmljZUlkKTtcbiAgICBzZXRTZWxlY3RlZERvY3RvcklkKGRvY3RvcklkKTtcbiAgICBzZXRCb29raW5nTW9kYWxPcGVuKHRydWUpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUNsb3NlQm9va2luZyA9ICgpID0+IHtcbiAgICBzZXRCb29raW5nTW9kYWxPcGVuKGZhbHNlKTtcbiAgICBzZXRTZWxlY3RlZFNlcnZpY2VJZCh1bmRlZmluZWQpO1xuICAgIHNldFNlbGVjdGVkRG9jdG9ySWQodW5kZWZpbmVkKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGZsZXggZmxleC1jb2wgZm9udC1zYW5zIHNlbGVjdGlvbjpiZy1za3ktNTAwIHNlbGVjdGlvbjp0ZXh0LXdoaXRlXCI+XG4gICAgICB7LyogSGVhZGVyICYgTmF2YmFyICovfVxuICAgICAgPE5hdmJhciBvbk9wZW5Cb29raW5nPXtoYW5kbGVPcGVuQm9va2luZ30gLz5cblxuICAgICAgey8qIE1haW4gQ29udGVudCBTZWN0aW9ucyAqL31cbiAgICAgIDxtYWluIGNsYXNzTmFtZT1cImZsZXgtMVwiPlxuICAgICAgICA8SGVyb1NlY3Rpb24gb25PcGVuQm9va2luZz17aGFuZGxlT3BlbkJvb2tpbmd9IC8+XG4gICAgICAgIDxUcnVzdE1ldHJpY3MgLz5cbiAgICAgICAgPFNlcnZpY2VzU2VjdGlvbiBvbk9wZW5Cb29raW5nPXtoYW5kbGVPcGVuQm9va2luZ30gLz5cbiAgICAgICAgPFNtaWxlR2FsbGVyeVNlY3Rpb24gb25PcGVuQm9va2luZz17aGFuZGxlT3BlbkJvb2tpbmd9IC8+XG4gICAgICAgIDxJbnRlcmFjdGl2ZVRvb2xzU2VjdGlvbiBvbk9wZW5Cb29raW5nPXtoYW5kbGVPcGVuQm9va2luZ30gLz5cbiAgICAgICAgPFBhaW5sZXNzVGVjaFNlY3Rpb24gLz5cbiAgICAgICAgPERvY3RvcnNTZWN0aW9uIG9uT3BlbkJvb2tpbmc9e2hhbmRsZU9wZW5Cb29raW5nfSAvPlxuICAgICAgICA8VGVzdGltb25pYWxzU2VjdGlvbiAvPlxuICAgICAgICA8UHJpY2luZ0luc3VyYW5jZVNlY3Rpb24gb25PcGVuQm9va2luZz17aGFuZGxlT3BlbkJvb2tpbmd9IC8+XG4gICAgICAgIDxGQVFTZWN0aW9uIC8+XG4gICAgICAgIDxDb250YWN0TWFwU2VjdGlvbiAvPlxuICAgICAgPC9tYWluPlxuXG4gICAgICB7LyogRm9vdGVyICovfVxuICAgICAgPEZvb3RlciAvPlxuXG4gICAgICB7LyogR2xvYmFsIEludGVyYWN0aXZlIEJvb2tpbmcgTW9kYWwgKi99XG4gICAgICA8QXBwb2ludG1lbnRNb2RhbFxuICAgICAgICBpc09wZW49e2Jvb2tpbmdNb2RhbE9wZW59XG4gICAgICAgIG9uQ2xvc2U9e2hhbmRsZUNsb3NlQm9va2luZ31cbiAgICAgICAgaW5pdGlhbFNlcnZpY2VJZD17c2VsZWN0ZWRTZXJ2aWNlSWR9XG4gICAgICAgIGluaXRpYWxEb2N0b3JJZD17c2VsZWN0ZWREb2N0b3JJZH1cbiAgICAgIC8+XG5cbiAgICAgIHsvKiBGbG9hdGluZyBFbWVyZ2VuY3kgJiBRdWljayBBY3Rpb24gV2lkZ2V0ICovfVxuICAgICAgPEZsb2F0aW5nRW1lcmdlbmN5V2lkZ2V0IG9uT3BlbkJvb2tpbmc9eygpID0+IGhhbmRsZU9wZW5Cb29raW5nKCl9IC8+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCgpIHtcbiAgcmV0dXJuIChcbiAgICA8VGhlbWVQcm92aWRlcj5cbiAgICAgIDxEZW50YWxTdHVkaW9BcHAgLz5cbiAgICA8L1RoZW1lUHJvdmlkZXI+XG4gICk7XG59XG4iXX0=