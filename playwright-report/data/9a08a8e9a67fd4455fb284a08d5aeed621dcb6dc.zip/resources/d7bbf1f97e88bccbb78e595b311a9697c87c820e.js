import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/FAQSection.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=383ccf5c";
import { motion, AnimatePresence } from "/node_modules/.vite/deps/framer-motion.js?v=d79d3615";
import { ChevronDown, HelpCircle, MessageCircle } from "/node_modules/.vite/deps/lucide-react.js?v=a18529f7";
import { useTheme } from "/src/context/ThemeContext.tsx";
var _jsxFileName = "D:/Aravind-Works/Dentel clinic/src/components/FAQSection.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=383ccf5c";
var _s = $RefreshSig$();
export const FAQSection = () => {
	_s();
	const { config } = useTheme();
	const [openIndex, setOpenIndex] = useState(0);
	const toggleFAQ = (index) => {
		setOpenIndex(openIndex === index ? null : index);
	};
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "faq",
		className: "py-20 relative",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-4xl mx-auto px-4 sm:px-6 lg:px-8",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "text-center space-y-3",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-100 dark:bg-sky-950/80 text-sky-800 dark:text-sky-300 text-xs font-bold uppercase tracking-wider",
							children: [/* @__PURE__ */ _jsxDEV(HelpCircle, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 21,
								columnNumber: 13
							}, this), "Frequently Asked Questions"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 20,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight",
							children: ["Have Questions? ", /* @__PURE__ */ _jsxDEV("span", {
								className: "text-gradient",
								children: "We Have Answers"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 25,
								columnNumber: 29
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 24,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-slate-600 dark:text-slate-300 text-sm sm:text-base",
							children: "Everything you need to know about our painless procedures, 0% EMI financing, and appointment guidelines."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 27,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 19,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-12 space-y-4",
					children: config.faqs.map((faq, idx) => {
						const isOpen = openIndex === idx;
						return /* @__PURE__ */ _jsxDEV("div", {
							className: "glass-card rounded-2xl border border-slate-200/90 dark:border-slate-800 overflow-hidden transition",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => toggleFAQ(idx),
								className: "w-full p-5 text-left flex items-center justify-between font-bold text-sm sm:text-base text-slate-900 dark:text-white hover:text-sky-500 transition cursor-pointer",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "pr-4",
									children: faq.question
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 45,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: `w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 transition-transform duration-300 ${isOpen ? "rotate-180 bg-sky-500 text-white" : ""}`,
									children: /* @__PURE__ */ _jsxDEV(ChevronDown, { className: "w-4 h-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 47,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 46,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 41,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV(AnimatePresence, { children: isOpen && /* @__PURE__ */ _jsxDEV(motion.div, {
								initial: {
									opacity: 0,
									height: 0
								},
								animate: {
									opacity: 1,
									height: "auto"
								},
								exit: {
									opacity: 0,
									height: 0
								},
								transition: { duration: .3 },
								children: /* @__PURE__ */ _jsxDEV("div", {
									className: "px-5 pb-5 pt-0 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-slate-800/80",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "pt-3",
										children: faq.answer
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 60,
										columnNumber: 25
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 59,
									columnNumber: 23
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 53,
								columnNumber: 21
							}, this) }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 51,
								columnNumber: 17
							}, this)]
						}, idx, true, {
							fileName: _jsxFileName,
							lineNumber: 37,
							columnNumber: 15
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-10 text-center p-6 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 flex flex-col sm:flex-row items-center justify-between gap-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "text-left space-y-1",
						children: [/* @__PURE__ */ _jsxDEV("h4", {
							className: "text-sm font-bold text-slate-900 dark:text-white",
							children: "Still have a specific question about your smile?"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 75,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-600 dark:text-slate-300",
							children: "Our clinical coordinator is online on WhatsApp to assist you instantly."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 78,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("a", {
						href: `https://wa.me/${config.contact.whatsapp.number}?text=${encodeURIComponent(config.contact.whatsapp.defaultMessage)}`,
						target: "_blank",
						rel: "noopener noreferrer",
						className: "px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-md flex items-center gap-2 whitespace-nowrap",
						children: [/* @__PURE__ */ _jsxDEV(MessageCircle, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 89,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Ask On WhatsApp" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 16,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 5
	}, this);
};
_s(FAQSection, "4N5zVFbzH+dJeEIcsXcPyDJUtUw=", false, function() {
	return [useTheme];
});
_c = FAQSection;
var _c;
$RefreshReg$(_c, "FAQSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/FAQSection.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Aravind-Works/Dentel clinic/src/components/FAQSection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Aravind-Works/Dentel clinic/src/components/FAQSection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Aravind-Works/Dentel clinic/src/components/FAQSection.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLFFBQVEsdUJBQXVCO0FBQ3hDLFNBQVMsYUFBYSxZQUFZLHFCQUFxQjtBQUN2RCxTQUFTLGdCQUFnQjs7OztBQUV6QixPQUFPLE1BQU0sbUJBQTZCOztDQUN4QyxNQUFNLEVBQUUsV0FBVyxTQUFTO0NBQzVCLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUF3QixDQUFDO0NBRTNELE1BQU0sYUFBYSxVQUFrQjtFQUNuQyxhQUFhLGNBQWMsUUFBUSxPQUFPLEtBQUs7Q0FDakQ7Q0FFQSxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxJQUFHO0VBQU0sV0FBVTtZQUMxQix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBR0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsWUFBRCxFQUFZLFdBQVUsY0FBZTs7OztpQkFBQyw0QkFFbkM7Ozs7OztNQUNMLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkLENBQWtHLG9CQUNoRix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBZ0I7T0FBcUI7Ozs7ZUFDbkU7Ozs7OztNQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUEwRDtNQUVwRTs7Ozs7S0FDQTs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWixPQUFPLEtBQUssS0FBSyxLQUFLLFFBQVE7TUFDN0IsTUFBTSxTQUFTLGNBQWM7TUFDN0IsT0FDRSx3QkFBQyxPQUFEO09BRUUsV0FBVTtpQkFGWixDQUlFLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLFVBQVUsR0FBRztRQUM1QixXQUFVO2tCQUZaLENBSUUsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQVEsSUFBSTtRQUFlOzs7O2tCQUMzQyx3QkFBQyxPQUFEO1NBQUssV0FBVyx5SUFBeUksU0FBUyxxQ0FBcUM7bUJBQ3JNLHdCQUFDLGFBQUQsRUFBYSxXQUFVLFVBQVc7Ozs7O1FBQy9COzs7O2dCQUNDOzs7OztpQkFFUix3QkFBQyxpQkFBRCxZQUNHLFVBQ0Msd0JBQUMsT0FBTyxLQUFSO1FBQ0UsU0FBUztTQUFFLFNBQVM7U0FBRyxRQUFRO1FBQUU7UUFDakMsU0FBUztTQUFFLFNBQVM7U0FBRyxRQUFRO1FBQU87UUFDdEMsTUFBTTtTQUFFLFNBQVM7U0FBRyxRQUFRO1FBQUU7UUFDOUIsWUFBWSxFQUFFLFVBQVUsR0FBSTtrQkFFNUIsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ2Isd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1osSUFBSTtTQUNGOzs7OztRQUNGOzs7OztPQUNLOzs7O2dCQUVDOzs7O2VBQ2Q7U0E3QkU7Ozs7YUE2QkY7S0FFVCxDQUFDO0lBQ0U7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQW1EO01BRTdEOzs7O2dCQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUE2QztNQUV2RDs7OztjQUNBOzs7OztlQUVMLHdCQUFDLEtBQUQ7TUFDRSxNQUFNLGlCQUFpQixPQUFPLFFBQVEsU0FBUyxPQUFPLFFBQVEsbUJBQW1CLE9BQU8sUUFBUSxTQUFTLGNBQWM7TUFDdkgsUUFBTztNQUNQLEtBQUk7TUFDSixXQUFVO2dCQUpaLENBTUUsd0JBQUMsZUFBRCxFQUFlLFdBQVUsVUFBVzs7OztnQkFDcEMsd0JBQUMsUUFBRCxZQUFNLGtCQUFxQjs7OztjQUMxQjs7Ozs7YUFDQTs7Ozs7O0dBRUY7Ozs7OztDQUNFOzs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkZBUVNlY3Rpb24udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IG1vdGlvbiwgQW5pbWF0ZVByZXNlbmNlIH0gZnJvbSAnZnJhbWVyLW1vdGlvbic7XG5pbXBvcnQgeyBDaGV2cm9uRG93biwgSGVscENpcmNsZSwgTWVzc2FnZUNpcmNsZSB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJ0AvY29udGV4dC9UaGVtZUNvbnRleHQnO1xuXG5leHBvcnQgY29uc3QgRkFRU2VjdGlvbjogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIGNvbnN0IHsgY29uZmlnIH0gPSB1c2VUaGVtZSgpO1xuICBjb25zdCBbb3BlbkluZGV4LCBzZXRPcGVuSW5kZXhdID0gdXNlU3RhdGU8bnVtYmVyIHwgbnVsbD4oMCk7XG5cbiAgY29uc3QgdG9nZ2xlRkFRID0gKGluZGV4OiBudW1iZXIpID0+IHtcbiAgICBzZXRPcGVuSW5kZXgob3BlbkluZGV4ID09PSBpbmRleCA/IG51bGwgOiBpbmRleCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBpZD1cImZhcVwiIGNsYXNzTmFtZT1cInB5LTIwIHJlbGF0aXZlXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTR4bCBteC1hdXRvIHB4LTQgc206cHgtNiBsZzpweC04XCI+XG4gICAgICAgIFxuICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHNwYWNlLXktM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgYmctc2t5LTEwMCBkYXJrOmJnLXNreS05NTAvODAgdGV4dC1za3ktODAwIGRhcms6dGV4dC1za3ktMzAwIHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgPEhlbHBDaXJjbGUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgRnJlcXVlbnRseSBBc2tlZCBRdWVzdGlvbnNcbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0zeGwgc206dGV4dC00eGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICBIYXZlIFF1ZXN0aW9ucz8gPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmFkaWVudFwiPldlIEhhdmUgQW5zd2Vyczwvc3Bhbj5cbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgdGV4dC1zbSBzbTp0ZXh0LWJhc2VcIj5cbiAgICAgICAgICAgIEV2ZXJ5dGhpbmcgeW91IG5lZWQgdG8ga25vdyBhYm91dCBvdXIgcGFpbmxlc3MgcHJvY2VkdXJlcywgMCUgRU1JIGZpbmFuY2luZywgYW5kIGFwcG9pbnRtZW50IGd1aWRlbGluZXMuXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQWNjb3JkaW9ucyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMiBzcGFjZS15LTRcIj5cbiAgICAgICAgICB7Y29uZmlnLmZhcXMubWFwKChmYXEsIGlkeCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgaXNPcGVuID0gb3BlbkluZGV4ID09PSBpZHg7XG4gICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAga2V5PXtpZHh9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2xhc3MtY2FyZCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC85MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgb3ZlcmZsb3ctaGlkZGVuIHRyYW5zaXRpb25cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdG9nZ2xlRkFRKGlkeCl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC01IHRleHQtbGVmdCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZm9udC1ib2xkIHRleHQtc20gc206dGV4dC1iYXNlIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBob3Zlcjp0ZXh0LXNreS01MDAgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHItNFwiPntmYXEucXVlc3Rpb259PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B3LTggaC04IHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS0xMDAgZGFyazpiZy1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1zbGF0ZS01MDAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwICR7aXNPcGVuID8gJ3JvdGF0ZS0xODAgYmctc2t5LTUwMCB0ZXh0LXdoaXRlJyA6ICcnfWB9PlxuICAgICAgICAgICAgICAgICAgICA8Q2hldnJvbkRvd24gY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgIDxBbmltYXRlUHJlc2VuY2U+XG4gICAgICAgICAgICAgICAgICB7aXNPcGVuICYmIChcbiAgICAgICAgICAgICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIGhlaWdodDogMCB9fVxuICAgICAgICAgICAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgaGVpZ2h0OiAnYXV0bycgfX1cbiAgICAgICAgICAgICAgICAgICAgICBleGl0PXt7IG9wYWNpdHk6IDAsIGhlaWdodDogMCB9fVxuICAgICAgICAgICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuMyB9fVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC01IHBiLTUgcHQtMCB0ZXh0LXhzIHNtOnRleHQtc20gdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBsZWFkaW5nLXJlbGF4ZWQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDAvODBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZmFxLmFuc3dlcn1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvQW5pbWF0ZVByZXNlbmNlPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBTdGlsbCBoYXZlIHF1ZXN0aW9ucyBXaGF0c0FwcCBwcm9tcHQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTAgdGV4dC1jZW50ZXIgcC02IHJvdW5kZWQtMnhsIGJnLWVtZXJhbGQtNTAgZGFyazpiZy1lbWVyYWxkLTk1MC82MCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwIGZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICBTdGlsbCBoYXZlIGEgc3BlY2lmaWMgcXVlc3Rpb24gYWJvdXQgeW91ciBzbWlsZT9cbiAgICAgICAgICAgIDwvaDQ+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgT3VyIGNsaW5pY2FsIGNvb3JkaW5hdG9yIGlzIG9ubGluZSBvbiBXaGF0c0FwcCB0byBhc3Npc3QgeW91IGluc3RhbnRseS5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxhXG4gICAgICAgICAgICBocmVmPXtgaHR0cHM6Ly93YS5tZS8ke2NvbmZpZy5jb250YWN0LndoYXRzYXBwLm51bWJlcn0/dGV4dD0ke2VuY29kZVVSSUNvbXBvbmVudChjb25maWcuY29udGFjdC53aGF0c2FwcC5kZWZhdWx0TWVzc2FnZSl9YH1cbiAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMi41IHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdGV4dC13aGl0ZSBiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTcwMCBzaGFkb3ctbWQgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgd2hpdGVzcGFjZS1ub3dyYXBcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxNZXNzYWdlQ2lyY2xlIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgPHNwYW4+QXNrIE9uIFdoYXRzQXBwPC9zcGFuPlxuICAgICAgICAgIDwvYT5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn07XG4iXX0=