import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/HeroSection.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=383ccf5c";
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=d79d3615";
import { Calendar, Sparkles, ShieldCheck, Star, ArrowRight, Clock, CheckCircle2, Calculator, Award, HeartPulse } from "/node_modules/.vite/deps/lucide-react.js?v=a18529f7";
import { useTheme } from "/src/context/ThemeContext.tsx";
var _jsxFileName = "D:/Aravind-Works/Dentel clinic/src/components/HeroSection.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=383ccf5c";
var _s = $RefreshSig$();
export const HeroSection = ({ onOpenBooking }) => {
	_s();
	const { config } = useTheme();
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "hero",
		className: "relative pt-8 pb-16 lg:pt-16 lg:pb-24 bg-gradient-to-b from-sky-50/60 via-white to-white overflow-hidden border-b border-slate-100",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { className: "absolute top-0 right-10 w-96 h-96 bg-sky-200/40 rounded-full blur-3xl pointer-events-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { className: "absolute top-20 left-10 w-96 h-96 bg-teal-200/30 rounded-full blur-3xl pointer-events-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative",
				children: /* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center",
					children: [/* @__PURE__ */ _jsxDEV(motion.div, {
						initial: {
							opacity: 0,
							y: 20
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: { duration: .6 },
						className: "lg:col-span-7 space-y-6 text-center lg:text-left",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "inline-flex items-center gap-2 px-4 py-2 rounded-full bg-sky-100/90 border border-sky-200 text-sky-900 text-xs font-bold shadow-sm",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "flex items-center gap-1 text-amber-500",
										children: [/* @__PURE__ */ _jsxDEV(Star, { className: "w-4 h-4 fill-amber-500" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 44,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-black text-slate-900",
											children: config.metrics.googleRating
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 45,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 43,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400",
										children: "•"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 47,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: [config.metrics.reviewsCount, " Verified Reviews"] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 48,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "hidden sm:inline text-slate-400",
										children: "•"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 49,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "hidden sm:inline font-extrabold text-teal-700",
										children: "100% Painless Technology"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 50,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 42,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("h1", {
								className: "text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-slate-900 leading-[1.12]",
								children: [
									config.tagline.split(",")[0],
									" ",
									/* @__PURE__ */ _jsxDEV("br", { className: "hidden sm:block" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 55,
										columnNumber: 46
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-gradient",
										children: config.tagline.split(",")[1] || "Designed For Your Smile"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 56,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-base sm:text-lg text-slate-600 max-w-2xl mx-auto lg:mx-0 font-normal leading-relaxed",
								children: config.subtagline
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2 text-xs font-bold text-slate-800 bg-white p-2.5 rounded-xl border border-slate-200 shadow-sm",
										children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-500 flex-shrink-0" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 69,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Computer-Guided Implants" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 70,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 68,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2 text-xs font-bold text-slate-800 bg-white p-2.5 rounded-xl border border-slate-200 shadow-sm",
										children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-500 flex-shrink-0" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 73,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "3D Clear Aligners" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 74,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 72,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-2 text-xs font-bold text-slate-800 bg-white p-2.5 rounded-xl border border-slate-200 shadow-sm",
										children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-500 flex-shrink-0" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 77,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "0% EMI Available" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 78,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 76,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 67,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-4",
								children: [/* @__PURE__ */ _jsxDEV(motion.button, {
									whileHover: { scale: 1.03 },
									whileTap: { scale: .97 },
									onClick: () => onOpenBooking(),
									className: "w-full sm:w-auto px-8 py-4.5 rounded-2xl font-extrabold text-white bg-gradient-to-r from-sky-600 via-teal-600 to-sky-700 hover:from-sky-700 hover:to-teal-700 shadow-xl shadow-sky-600/30 flex items-center justify-center gap-3 text-base cursor-pointer",
									children: [
										/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-5 h-5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 90,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", { children: "Book Instant Consultation" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 91,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV(ArrowRight, { className: "w-5 h-5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 92,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 84,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("a", {
									href: "#cost-calculator",
									className: "w-full sm:w-auto px-7 py-4.5 rounded-2xl font-bold text-slate-800 bg-white border border-slate-200 hover:border-sky-400 shadow-md flex items-center justify-center gap-2 text-sm transition",
									children: [/* @__PURE__ */ _jsxDEV(Calculator, { className: "w-4 h-4 text-sky-600" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 99,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Calculate Cost & EMI" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 100,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 95,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "pt-2 flex items-center justify-center lg:justify-start gap-2 text-xs font-semibold text-slate-600",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "relative flex h-2.5 w-2.5",
									children: [/* @__PURE__ */ _jsxDEV("span", { className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 107,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { className: "relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 108,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 106,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["Next Available Slot: ", /* @__PURE__ */ _jsxDEV("strong", {
									className: "text-slate-900 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200",
									children: "Today at 3:30 PM"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 110,
									columnNumber: 42
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 110,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 105,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(motion.div, {
						initial: {
							opacity: 0,
							scale: .95
						},
						animate: {
							opacity: 1,
							scale: 1
						},
						transition: {
							duration: .6,
							delay: .2
						},
						className: "lg:col-span-5 relative",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "relative rounded-3xl overflow-hidden bg-white p-3 border border-slate-200 shadow-2xl",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "relative h-80 sm:h-96 rounded-2xl overflow-hidden group",
									children: [
										/* @__PURE__ */ _jsxDEV("img", {
											src: "https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&w=1000&q=80",
											alt: "ApexCare Dental Studio Clean White Clinic",
											className: "w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 125,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0 bg-gradient-to-t from-slate-900/60 via-slate-900/10 to-transparent" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 132,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute top-4 right-4 bg-white/95 backdrop-blur-md px-3 py-1.5 rounded-full border border-slate-200 text-slate-900 text-xs font-bold flex items-center gap-1.5 shadow-lg",
											children: [/* @__PURE__ */ _jsxDEV(Award, { className: "w-4 h-4 text-amber-500" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 136,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: "ISO 9001 Certified" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 137,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 135,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-white/95 backdrop-blur-md border border-slate-200 text-slate-900 shadow-xl space-y-1",
											children: /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center justify-between",
												children: [/* @__PURE__ */ _jsxDEV("div", {
													className: "flex items-center gap-2.5",
													children: [/* @__PURE__ */ _jsxDEV("div", {
														className: "w-9 h-9 rounded-xl bg-sky-100 border border-sky-300 flex items-center justify-center text-sky-700 font-black text-xs",
														children: "3D"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 144,
														columnNumber: 23
													}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
														className: "text-xs font-extrabold text-slate-900",
														children: "Digital Smile Design (DSD)"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 148,
														columnNumber: 25
													}, this), /* @__PURE__ */ _jsxDEV("p", {
														className: "text-[11px] text-slate-500",
														children: "Preview your smile before treatment"
													}, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 149,
														columnNumber: 25
													}, this)] }, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 147,
														columnNumber: 23
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 143,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "text-[10px] font-extrabold text-emerald-700 bg-emerald-100 px-2.5 py-1 rounded-full border border-emerald-300",
													children: "100% Painless"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 152,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 142,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 141,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 124,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(motion.div, {
									animate: { y: [
										0,
										-6,
										0
									] },
									transition: {
										duration: 4,
										repeat: Infinity,
										ease: "easeInOut"
									},
									className: "absolute -bottom-5 -left-5 hidden sm:flex items-center gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-xl",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "w-10 h-10 rounded-xl bg-teal-100 flex items-center justify-center text-teal-700 font-bold",
										children: /* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-5 h-5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 166,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 165,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "text-xs font-extrabold text-slate-900",
										children: "99.4% Success Rate"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 169,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-[11px] text-slate-500",
										children: "4,200+ Guided Implants"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 170,
										columnNumber: 19
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 168,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 160,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(motion.div, {
									animate: { y: [
										0,
										6,
										0
									] },
									transition: {
										duration: 5,
										repeat: Infinity,
										ease: "easeInOut"
									},
									className: "absolute -top-4 -left-4 hidden sm:flex items-center gap-2 bg-slate-900 text-white px-3.5 py-2 rounded-xl border border-slate-800 shadow-lg text-xs font-bold",
									children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-4 h-4 text-emerald-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 180,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Class-B Sterilization" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 181,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 175,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 121,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 115,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 25,
		columnNumber: 5
	}, this);
};
_s(HeroSection, "qQ7g6tIEyataPS75zVi2PFhrMqc=", false, function() {
	return [useTheme];
});
_c = HeroSection;
var _c;
$RefreshReg$(_c, "HeroSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/HeroSection.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Aravind-Works/Dentel clinic/src/components/HeroSection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Aravind-Works/Dentel clinic/src/components/HeroSection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Aravind-Works/Dentel clinic/src/components/HeroSection.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsY0FBYztBQUN2QixTQUNFLFVBQ0EsVUFDQSxhQUNBLE1BQ0EsWUFDQSxPQUNBLGNBQ0EsWUFDQSxPQUNBLGtCQUNLO0FBQ1AsU0FBUyxnQkFBZ0I7Ozs7QUFNekIsT0FBTyxNQUFNLGVBQTJDLEVBQUUsb0JBQW9COztDQUM1RSxNQUFNLEVBQUUsV0FBVyxTQUFTO0NBRTVCLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLElBQUc7RUFBTyxXQUFVO1lBQTdCO0dBR0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsNEZBQTZGOzs7OztHQUM1Ryx3QkFBQyxPQUFELEVBQUssV0FBVSw2RkFBOEY7Ozs7O0dBRTdHLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUdFLHdCQUFDLE9BQU8sS0FBUjtNQUNFLFNBQVM7T0FBRSxTQUFTO09BQUcsR0FBRztNQUFHO01BQzdCLFNBQVM7T0FBRSxTQUFTO09BQUcsR0FBRztNQUFFO01BQzVCLFlBQVksRUFBRSxVQUFVLEdBQUk7TUFDNUIsV0FBVTtnQkFKWjtPQU9FLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWhCLENBQ0Usd0JBQUMsTUFBRCxFQUFNLFdBQVUseUJBQTBCOzs7O29CQUMxQyx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBNkIsT0FBTyxRQUFRO1VBQW1COzs7O2tCQUMzRTs7Ozs7O1NBQ04sd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQWlCO1NBQU87Ozs7O1NBQ3hDLHdCQUFDLFFBQUQsYUFBTyxPQUFPLFFBQVEsY0FBYSxtQkFBdUI7Ozs7O1NBQzFELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFrQztTQUFPOzs7OztTQUN6RCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBZ0Q7U0FBOEI7Ozs7O1FBQzNGOzs7Ozs7T0FHTCx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZDtTQUNHLE9BQU8sUUFBUSxNQUFNLEdBQUcsQ0FBQyxDQUFDO1NBQUc7U0FBQyx3QkFBQyxNQUFELEVBQUksV0FBVSxrQkFBa0I7Ozs7O1NBQy9ELHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiLE9BQU8sUUFBUSxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU07U0FDN0I7Ozs7O1FBQ0o7Ozs7OztPQUdKLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUNWLE9BQU87T0FDUDs7Ozs7T0FHSCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsY0FBRCxFQUFjLFdBQVUseUNBQTBDOzs7O29CQUNsRSx3QkFBQyxRQUFELFlBQU0sMkJBQThCOzs7O2tCQUNqQzs7Ozs7O1NBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxjQUFELEVBQWMsV0FBVSx5Q0FBMEM7Ozs7b0JBQ2xFLHdCQUFDLFFBQUQsWUFBTSxvQkFBdUI7Ozs7a0JBQzFCOzs7Ozs7U0FDTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLHlDQUEwQzs7OztvQkFDbEUsd0JBQUMsUUFBRCxZQUFNLG1CQUFzQjs7OztrQkFDekI7Ozs7OztRQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQU8sUUFBUjtTQUNFLFlBQVksRUFBRSxPQUFPLEtBQUs7U0FDMUIsVUFBVSxFQUFFLE9BQU8sSUFBSztTQUN4QixlQUFlLGNBQWM7U0FDN0IsV0FBVTttQkFKWjtVQU1FLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFVBQVc7Ozs7O1VBQy9CLHdCQUFDLFFBQUQsWUFBTSw0QkFBK0I7Ozs7O1VBQ3JDLHdCQUFDLFlBQUQsRUFBWSxXQUFVLFVBQVc7Ozs7O1NBQ3BCOzs7OztrQkFFZix3QkFBQyxLQUFEO1NBQ0UsTUFBSztTQUNMLFdBQVU7bUJBRlosQ0FJRSx3QkFBQyxZQUFELEVBQVksV0FBVSx1QkFBd0I7Ozs7bUJBQzlDLHdCQUFDLFFBQUQsWUFBTSx1QkFBMEI7Ozs7aUJBQy9COzs7OztnQkFDQTs7Ozs7O09BR0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEIsQ0FDRSx3QkFBQyxRQUFELEVBQU0sV0FBVSx5RkFBK0Y7Ozs7bUJBQy9HLHdCQUFDLFFBQUQsRUFBTSxXQUFVLCtEQUFxRTs7OztpQkFDakY7Ozs7O2tCQUNOLHdCQUFDLFFBQUQsYUFBTSx5QkFBcUIsd0JBQUMsVUFBRDtTQUFRLFdBQVU7bUJBQTZFO1FBQXdCOzs7O2dCQUFPOzs7O2dCQUN0Sjs7Ozs7O01BQ0s7Ozs7O2VBR1osd0JBQUMsT0FBTyxLQUFSO01BQ0UsU0FBUztPQUFFLFNBQVM7T0FBRyxPQUFPO01BQUs7TUFDbkMsU0FBUztPQUFFLFNBQVM7T0FBRyxPQUFPO01BQUU7TUFDaEMsWUFBWTtPQUFFLFVBQVU7T0FBSyxPQUFPO01BQUk7TUFDeEMsV0FBVTtnQkFFVix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUdFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsT0FBRDtXQUNFLEtBQUk7V0FDSixLQUFJO1dBQ0osV0FBVTtVQUNYOzs7OztVQUdELHdCQUFDLE9BQUQsRUFBSyxXQUFVLHNGQUF1Rjs7Ozs7VUFHdEcsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSx5QkFBMEI7Ozs7cUJBQzNDLHdCQUFDLFFBQUQsWUFBTSxxQkFBd0I7Ozs7bUJBQzNCOzs7Ozs7VUFHTCx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDYix3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLE9BQUQ7YUFBSyxXQUFVO3VCQUFmLENBQ0Usd0JBQUMsT0FBRDtjQUFLLFdBQVU7d0JBQXVIO2FBRWpJOzs7O3VCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO2NBQUksV0FBVTt3QkFBd0M7YUFBOEI7Ozs7dUJBQ3BGLHdCQUFDLEtBQUQ7Y0FBRyxXQUFVO3dCQUE2QjthQUFzQzs7OztxQkFDN0U7Ozs7cUJBQ0Y7Ozs7O3NCQUNMLHdCQUFDLFFBQUQ7YUFBTSxXQUFVO3VCQUFnSDtZQUUxSDs7OztvQkFDSDs7Ozs7O1VBQ0Y7Ozs7O1NBQ0Y7Ozs7OztRQUdMLHdCQUFDLE9BQU8sS0FBUjtTQUNFLFNBQVMsRUFBRSxHQUFHO1VBQUM7VUFBRyxDQUFDO1VBQUc7U0FBQyxFQUFFO1NBQ3pCLFlBQVk7VUFBRSxVQUFVO1VBQUcsUUFBUTtVQUFVLE1BQU07U0FBWTtTQUMvRCxXQUFVO21CQUhaLENBS0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ2Isd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7Ozs7U0FDNUI7Ozs7bUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUF3QztTQUF1Qjs7OzttQkFDOUUsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQTZCO1NBQTJCOzs7O2lCQUNwRTs7OztpQkFDSzs7Ozs7O1FBR1osd0JBQUMsT0FBTyxLQUFSO1NBQ0UsU0FBUyxFQUFFLEdBQUc7VUFBQztVQUFHO1VBQUc7U0FBQyxFQUFFO1NBQ3hCLFlBQVk7VUFBRSxVQUFVO1VBQUcsUUFBUTtVQUFVLE1BQU07U0FBWTtTQUMvRCxXQUFVO21CQUhaLENBS0Usd0JBQUMsYUFBRCxFQUFhLFdBQVUsMkJBQTRCOzs7O21CQUNuRCx3QkFBQyxRQUFELFlBQU0sd0JBQTJCOzs7O2lCQUN2Qjs7Ozs7O09BRVQ7Ozs7OztLQUNLOzs7O2FBRVQ7Ozs7OztHQUNGOzs7OztFQUNFOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJIZXJvU2VjdGlvbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IG1vdGlvbiB9IGZyb20gJ2ZyYW1lci1tb3Rpb24nO1xuaW1wb3J0IHsgXG4gIENhbGVuZGFyLCBcbiAgU3BhcmtsZXMsIFxuICBTaGllbGRDaGVjaywgXG4gIFN0YXIsIFxuICBBcnJvd1JpZ2h0LCBcbiAgQ2xvY2ssIFxuICBDaGVja0NpcmNsZTIsIFxuICBDYWxjdWxhdG9yLFxuICBBd2FyZCxcbiAgSGVhcnRQdWxzZVxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICdAL2NvbnRleHQvVGhlbWVDb250ZXh0JztcblxuaW50ZXJmYWNlIEhlcm9TZWN0aW9uUHJvcHMge1xuICBvbk9wZW5Cb29raW5nOiAoc2VydmljZUlkPzogc3RyaW5nKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgSGVyb1NlY3Rpb246IFJlYWN0LkZDPEhlcm9TZWN0aW9uUHJvcHM+ID0gKHsgb25PcGVuQm9va2luZyB9KSA9PiB7XG4gIGNvbnN0IHsgY29uZmlnIH0gPSB1c2VUaGVtZSgpO1xuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gaWQ9XCJoZXJvXCIgY2xhc3NOYW1lPVwicmVsYXRpdmUgcHQtOCBwYi0xNiBsZzpwdC0xNiBsZzpwYi0yNCBiZy1ncmFkaWVudC10by1iIGZyb20tc2t5LTUwLzYwIHZpYS13aGl0ZSB0by13aGl0ZSBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTEwMFwiPlxuICAgICAgXG4gICAgICB7LyogQmFja2dyb3VuZCBTb2Z0IEdsb3cgQnVsYnMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0wIHJpZ2h0LTEwIHctOTYgaC05NiBiZy1za3ktMjAwLzQwIHJvdW5kZWQtZnVsbCBibHVyLTN4bCBwb2ludGVyLWV2ZW50cy1ub25lXCIgLz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTIwIGxlZnQtMTAgdy05NiBoLTk2IGJnLXRlYWwtMjAwLzMwIHJvdW5kZWQtZnVsbCBibHVyLTN4bCBwb2ludGVyLWV2ZW50cy1ub25lXCIgLz5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy03eGwgbXgtYXV0byBweC00IHNtOnB4LTYgbGc6cHgtOCByZWxhdGl2ZVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLTEyIGdhcC0xMiBsZzpnYXAtOCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICBcbiAgICAgICAgICB7LyogTGVmdCBIZXJvIENvbnRlbnQgKi99XG4gICAgICAgICAgPG1vdGlvbi5kaXYgXG4gICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDIwIH19XG4gICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHk6IDAgfX1cbiAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuNiB9fVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNyBzcGFjZS15LTYgdGV4dC1jZW50ZXIgbGc6dGV4dC1sZWZ0XCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICB7LyogVHJ1c3QgQmFkZ2UgUGlsbCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTQgcHktMiByb3VuZGVkLWZ1bGwgYmctc2t5LTEwMC85MCBib3JkZXIgYm9yZGVyLXNreS0yMDAgdGV4dC1za3ktOTAwIHRleHQteHMgZm9udC1ib2xkIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LWFtYmVyLTUwMFwiPlxuICAgICAgICAgICAgICAgIDxTdGFyIGNsYXNzTmFtZT1cInctNCBoLTQgZmlsbC1hbWJlci01MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYmxhY2sgdGV4dC1zbGF0ZS05MDBcIj57Y29uZmlnLm1ldHJpY3MuZ29vZ2xlUmF0aW5nfTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPuKAojwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4+e2NvbmZpZy5tZXRyaWNzLnJldmlld3NDb3VudH0gVmVyaWZpZWQgUmV2aWV3czwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZSB0ZXh0LXNsYXRlLTQwMFwiPuKAojwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHNtOmlubGluZSBmb250LWV4dHJhYm9sZCB0ZXh0LXRlYWwtNzAwXCI+MTAwJSBQYWlubGVzcyBUZWNobm9sb2d5PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBNYWluIEhlYWRsaW5lICovfVxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtNHhsIHNtOnRleHQtNXhsIGxnOnRleHQtNnhsIGZvbnQtYmxhY2sgdHJhY2tpbmctdGlnaHQgdGV4dC1zbGF0ZS05MDAgbGVhZGluZy1bMS4xMl1cIj5cbiAgICAgICAgICAgICAge2NvbmZpZy50YWdsaW5lLnNwbGl0KCcsJylbMF19IDxiciBjbGFzc05hbWU9XCJoaWRkZW4gc206YmxvY2tcIi8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JhZGllbnRcIj5cbiAgICAgICAgICAgICAgICB7Y29uZmlnLnRhZ2xpbmUuc3BsaXQoJywnKVsxXSB8fCBcIkRlc2lnbmVkIEZvciBZb3VyIFNtaWxlXCJ9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDwvaDE+XG5cbiAgICAgICAgICAgIHsvKiBTdWJoZWFkaW5nICovfVxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1iYXNlIHNtOnRleHQtbGcgdGV4dC1zbGF0ZS02MDAgbWF4LXctMnhsIG14LWF1dG8gbGc6bXgtMCBmb250LW5vcm1hbCBsZWFkaW5nLXJlbGF4ZWRcIj5cbiAgICAgICAgICAgICAge2NvbmZpZy5zdWJ0YWdsaW5lfVxuICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICB7LyogS2V5IFZhbHVlIEhpZ2hsaWdodHMgR3JpZCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBzbTpncmlkLWNvbHMtMyBnYXAtMyBwdC0yXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS04MDAgYmctd2hpdGUgcC0yLjUgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1lbWVyYWxkLTUwMCBmbGV4LXNocmluay0wXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5Db21wdXRlci1HdWlkZWQgSW1wbGFudHM8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGJnLXdoaXRlIHAtMi41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC01MDAgZmxleC1zaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+M0QgQ2xlYXIgQWxpZ25lcnM8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGJnLXdoaXRlIHAtMi41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtZW1lcmFsZC01MDAgZmxleC1zaHJpbmstMFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+MCUgRU1JIEF2YWlsYWJsZTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEhlcm8gQ1RBcyAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgbGc6anVzdGlmeS1zdGFydCBnYXAtNCBwdC00XCI+XG4gICAgICAgICAgICAgIDxtb3Rpb24uYnV0dG9uXG4gICAgICAgICAgICAgICAgd2hpbGVIb3Zlcj17eyBzY2FsZTogMS4wMyB9fVxuICAgICAgICAgICAgICAgIHdoaWxlVGFwPXt7IHNjYWxlOiAwLjk3IH19XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25PcGVuQm9va2luZygpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LWF1dG8gcHgtOCBweS00LjUgcm91bmRlZC0yeGwgZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSBiZy1ncmFkaWVudC10by1yIGZyb20tc2t5LTYwMCB2aWEtdGVhbC02MDAgdG8tc2t5LTcwMCBob3Zlcjpmcm9tLXNreS03MDAgaG92ZXI6dG8tdGVhbC03MDAgc2hhZG93LXhsIHNoYWRvdy1za3ktNjAwLzMwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0zIHRleHQtYmFzZSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+Qm9vayBJbnN0YW50IENvbnN1bHRhdGlvbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgICAgPC9tb3Rpb24uYnV0dG9uPlxuXG4gICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAgaHJlZj1cIiNjb3N0LWNhbGN1bGF0b3JcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBzbTp3LWF1dG8gcHgtNyBweS00LjUgcm91bmRlZC0yeGwgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGJnLXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGhvdmVyOmJvcmRlci1za3ktNDAwIHNoYWRvdy1tZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMiB0ZXh0LXNtIHRyYW5zaXRpb25cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPENhbGN1bGF0b3IgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LXNreS02MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkNhbGN1bGF0ZSBDb3N0ICYgRU1JPC9zcGFuPlxuICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFJlYWx0aW1lIExpdmUgQXZhaWxhYmlsaXR5IEJhbm5lciAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBsZzpqdXN0aWZ5LXN0YXJ0IGdhcC0yIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTYwMFwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBmbGV4IGgtMi41IHctMi41XCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYW5pbWF0ZS1waW5nIGFic29sdXRlIGlubGluZS1mbGV4IGgtZnVsbCB3LWZ1bGwgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtNDAwIG9wYWNpdHktNzVcIj48L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmVsYXRpdmUgaW5saW5lLWZsZXggcm91bmRlZC1mdWxsIGgtMi41IHctMi41IGJnLWVtZXJhbGQtNTAwXCI+PC9zcGFuPlxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuPk5leHQgQXZhaWxhYmxlIFNsb3Q6IDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS05MDAgYmctZW1lcmFsZC01MCBweC0yIHB5LTAuNSByb3VuZGVkIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDBcIj5Ub2RheSBhdCAzOjMwIFBNPC9zdHJvbmc+PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9tb3Rpb24uZGl2PlxuXG4gICAgICAgICAgey8qIFJpZ2h0IEhlcm8gVmlzdWFsIFNob3djYXNlIENhcmQgKi99XG4gICAgICAgICAgPG1vdGlvbi5kaXYgXG4gICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHNjYWxlOiAwLjk1IH19XG4gICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHNjYWxlOiAxIH19XG4gICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjYsIGRlbGF5OiAwLjIgfX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImxnOmNvbC1zcGFuLTUgcmVsYXRpdmVcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcm91bmRlZC0zeGwgb3ZlcmZsb3ctaGlkZGVuIGJnLXdoaXRlIHAtMyBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBzaGFkb3ctMnhsXCI+XG4gICAgICAgICAgICAgIFxuICAgICAgICAgICAgICB7LyogU3R1ZGlvICYgU21pbGUgSW1hZ2UgQ29udGFpbmVyICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGgtODAgc206aC05NiByb3VuZGVkLTJ4bCBvdmVyZmxvdy1oaWRkZW4gZ3JvdXBcIj5cbiAgICAgICAgICAgICAgICA8aW1nIFxuICAgICAgICAgICAgICAgICAgc3JjPVwiaHR0cHM6Ly9pbWFnZXMudW5zcGxhc2guY29tL3Bob3RvLTE2Mjk5MDk2MTM2NTQtMjhlMzc3YzM3YjA5P2F1dG89Zm9ybWF0JmZpdD1jcm9wJnc9MTAwMCZxPTgwXCIgXG4gICAgICAgICAgICAgICAgICBhbHQ9XCJBcGV4Q2FyZSBEZW50YWwgU3R1ZGlvIENsZWFuIFdoaXRlIENsaW5pY1wiIFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXIgZ3JvdXAtaG92ZXI6c2NhbGUtMTA1IHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTcwMFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICB7LyogR3JhZGllbnQgT3ZlcmxheSAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LTAgYmctZ3JhZGllbnQtdG8tdCBmcm9tLXNsYXRlLTkwMC82MCB2aWEtc2xhdGUtOTAwLzEwIHRvLXRyYW5zcGFyZW50XCIgLz5cblxuICAgICAgICAgICAgICAgIHsvKiBGbG9hdGluZyBCYWRnZSBUb3AgUmlnaHQgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNCByaWdodC00IGJnLXdoaXRlLzk1IGJhY2tkcm9wLWJsdXItbWQgcHgtMyBweS0xLjUgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHRleHQtc2xhdGUtOTAwIHRleHQteHMgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgc2hhZG93LWxnXCI+XG4gICAgICAgICAgICAgICAgICA8QXdhcmQgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWFtYmVyLTUwMFwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5JU08gOTAwMSBDZXJ0aWZpZWQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogQm90dG9tIE92ZXJsYXkgQ2FyZCAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS00IGxlZnQtNCByaWdodC00IHAtNCByb3VuZGVkLXhsIGJnLXdoaXRlLzk1IGJhY2tkcm9wLWJsdXItbWQgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgdGV4dC1zbGF0ZS05MDAgc2hhZG93LXhsIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMi41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTkgaC05IHJvdW5kZWQteGwgYmctc2t5LTEwMCBib3JkZXIgYm9yZGVyLXNreS0zMDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1za3ktNzAwIGZvbnQtYmxhY2sgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgM0RcbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5EaWdpdGFsIFNtaWxlIERlc2lnbiAoRFNEKTwvaDQ+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMFwiPlByZXZpZXcgeW91ciBzbWlsZSBiZWZvcmUgdHJlYXRtZW50PC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1leHRyYWJvbGQgdGV4dC1lbWVyYWxkLTcwMCBiZy1lbWVyYWxkLTEwMCBweC0yLjUgcHktMSByb3VuZGVkLWZ1bGwgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTMwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDEwMCUgUGFpbmxlc3NcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBGbG9hdGluZyBTdGF0IENhcmQgQm90dG9tIExlZnQgKi99XG4gICAgICAgICAgICAgIDxtb3Rpb24uZGl2IFxuICAgICAgICAgICAgICAgIGFuaW1hdGU9e3sgeTogWzAsIC02LCAwXSB9fVxuICAgICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDQsIHJlcGVhdDogSW5maW5pdHksIGVhc2U6IFwiZWFzZUluT3V0XCIgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtYm90dG9tLTUgLWxlZnQtNSBoaWRkZW4gc206ZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgYmctd2hpdGUgcC00IHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHNoYWRvdy14bFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLXhsIGJnLXRlYWwtMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtdGVhbC03MDAgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwidy01IGgtNVwiIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMFwiPjk5LjQlIFN1Y2Nlc3MgUmF0ZTwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMFwiPjQsMjAwKyBHdWlkZWQgSW1wbGFudHM8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9tb3Rpb24uZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBGbG9hdGluZyBTdGF0IENhcmQgVG9wIExlZnQgKi99XG4gICAgICAgICAgICAgIDxtb3Rpb24uZGl2IFxuICAgICAgICAgICAgICAgIGFuaW1hdGU9e3sgeTogWzAsIDYsIDBdIH19XG4gICAgICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogNSwgcmVwZWF0OiBJbmZpbml0eSwgZWFzZTogXCJlYXNlSW5PdXRcIiB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIC10b3AtNCAtbGVmdC00IGhpZGRlbiBzbTpmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBiZy1zbGF0ZS05MDAgdGV4dC13aGl0ZSBweC0zLjUgcHktMiByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHNoYWRvdy1sZyB0ZXh0LXhzIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNDAwXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5DbGFzcy1CIFN0ZXJpbGl6YXRpb248L3NwYW4+XG4gICAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cblxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9tb3Rpb24uZGl2PlxuXG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9zZWN0aW9uPlxuICApO1xufTtcbiJdfQ==