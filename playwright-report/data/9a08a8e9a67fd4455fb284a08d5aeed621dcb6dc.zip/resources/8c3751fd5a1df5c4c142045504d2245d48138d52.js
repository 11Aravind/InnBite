import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SmileGallerySection.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=383ccf5c";
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=d79d3615";
import { Sparkles, Calendar, CheckCircle2, User, ArrowLeftRight } from "/node_modules/.vite/deps/lucide-react.js?v=a18529f7";
import { useTheme } from "/src/context/ThemeContext.tsx";
var _jsxFileName = "D:/Aravind-Works/Dentel clinic/src/components/SmileGallerySection.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=383ccf5c";
var _s = $RefreshSig$();
export const SmileGallerySection = ({ onOpenBooking }) => {
	_s();
	const { config } = useTheme();
	const [activeCaseIndex, setActiveCaseIndex] = useState(0);
	const [sliderPosition, setSliderPosition] = useState(50);
	const activeCase = config.transformations[activeCaseIndex] || config.transformations[0];
	const handleSliderMove = (e) => {
		const rect = e.currentTarget.getBoundingClientRect();
		const clientX = "touches" in e ? e.touches[0].clientX : e.clientX;
		const x = clientX - rect.left;
		const percentage = Math.min(Math.max(x / rect.width * 100, 0), 100);
		setSliderPosition(percentage);
	};
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "transformations",
		className: "py-20 bg-slate-50/70 border-y border-slate-200 relative overflow-hidden",
		children: [
			/* @__PURE__ */ _jsxDEV("div", { className: "absolute top-0 right-0 w-96 h-96 bg-sky-100/50 rounded-full blur-3xl pointer-events-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", { className: "absolute bottom-0 left-0 w-96 h-96 bg-teal-100/50 rounded-full blur-3xl pointer-events-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "text-center max-w-3xl mx-auto space-y-3",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-100 border border-sky-200 text-sky-900 text-xs font-bold uppercase tracking-wider",
								children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3.5 h-3.5 text-sky-600" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 37,
									columnNumber: 13
								}, this), "Real Patients • Real Smile Results"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 36,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight",
								children: ["Smile Transformations ", /* @__PURE__ */ _jsxDEV("span", {
									className: "text-gradient",
									children: "Gallery"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 41,
									columnNumber: 35
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 40,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-slate-600 text-sm sm:text-base font-normal",
								children: "Drag the interactive slider below to witness dramatic before-and-after smile restyling crafted by our specialist surgeons."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 43,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-8 flex flex-wrap justify-center gap-3",
						children: config.transformations.map((c, idx) => /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => {
								setActiveCaseIndex(idx);
								setSliderPosition(50);
							},
							className: `px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${activeCaseIndex === idx ? "bg-gradient-to-r from-sky-600 to-teal-600 text-white shadow-md scale-105" : "bg-white text-slate-700 border border-slate-200 hover:border-sky-400"}`,
							children: c.category
						}, c.id, false, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 13
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mt-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "lg:col-span-7",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "relative rounded-3xl overflow-hidden border border-slate-200 shadow-2xl bg-white select-none",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "relative h-80 sm:h-96 md:h-[420px] w-full cursor-ew-resize overflow-hidden",
									onMouseMove: handleSliderMove,
									onTouchMove: handleSliderMove,
									children: [
										/* @__PURE__ */ _jsxDEV("img", {
											src: activeCase.afterImage,
											alt: `${activeCase.treatmentName} After`,
											className: "absolute inset-0 w-full h-full object-cover"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 81,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "absolute top-4 right-4 bg-emerald-600 text-white font-extrabold text-xs px-3.5 py-1 rounded-full shadow-lg",
											children: "AFTER RESULT"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 88,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute top-0 bottom-0 left-0 overflow-hidden",
											style: { width: `${sliderPosition}%` },
											children: [/* @__PURE__ */ _jsxDEV("img", {
												src: activeCase.beforeImage,
												alt: `${activeCase.treatmentName} Before`,
												className: "absolute inset-0 w-full h-full object-cover max-w-none",
												style: {
													width: "100%",
													height: "100%"
												}
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 97,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "absolute top-4 left-4 bg-slate-900/90 text-white font-extrabold text-xs px-3.5 py-1 rounded-full border border-slate-700 shadow-lg",
												children: "BEFORE"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 104,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 93,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "absolute top-0 bottom-0 w-1 bg-white shadow-[0_0_10px_rgba(0,0,0,0.5)] cursor-ew-resize flex items-center justify-center pointer-events-none",
											style: { left: `${sliderPosition}%` },
											children: /* @__PURE__ */ _jsxDEV("div", {
												className: "w-10 h-10 rounded-full bg-white text-slate-900 shadow-2xl border-2 border-sky-600 flex items-center justify-center font-bold text-xs",
												children: /* @__PURE__ */ _jsxDEV(ArrowLeftRight, { className: "w-4 h-4 text-sky-600" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 115,
													columnNumber: 21
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 114,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 110,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 75,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 bg-white text-center text-xs font-semibold text-slate-500 border-t border-slate-200 flex items-center justify-center gap-2",
									children: [/* @__PURE__ */ _jsxDEV(ArrowLeftRight, { className: "w-3.5 h-3.5 text-sky-600" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 123,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Drag slider left or right to compare transformational results" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 124,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 122,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 73,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 72,
							columnNumber: 11
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "lg:col-span-5 space-y-6",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-2",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-extrabold uppercase tracking-wider text-sky-600",
											children: ["Case Study • ", activeCase.category]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 132,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("h3", {
											className: "text-2xl sm:text-3xl font-bold text-slate-900",
											children: activeCase.treatmentName
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 135,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-sm text-slate-600 leading-relaxed font-normal",
											children: activeCase.description
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 138,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 131,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-4 p-5 rounded-2xl bg-white border border-slate-200 text-xs shadow-sm",
									children: [
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-500 block font-semibold",
											children: "Patient Name"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 146,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("strong", {
											className: "text-slate-900 font-extrabold flex items-center gap-1.5 mt-0.5",
											children: [/* @__PURE__ */ _jsxDEV(User, { className: "w-3.5 h-3.5 text-sky-600" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 148,
												columnNumber: 19
											}, this), activeCase.patientName]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 147,
											columnNumber: 17
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 145,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-slate-500 block font-semibold",
											children: "Total Duration"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 153,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("strong", {
											className: "text-emerald-700 font-extrabold mt-0.5 block",
											children: activeCase.duration
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 154,
											columnNumber: 17
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 152,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "col-span-2 pt-3 border-t border-slate-100",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-slate-500 block font-semibold",
												children: "Lead Dental Surgeon"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 159,
												columnNumber: 17
											}, this), /* @__PURE__ */ _jsxDEV("strong", {
												className: "text-slate-900 font-extrabold text-sm mt-0.5 block",
												children: activeCase.dentistName
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 160,
												columnNumber: 17
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 158,
											columnNumber: 15
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 144,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pt-2",
									children: /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => onOpenBooking(),
										className: "w-full py-4 px-6 rounded-xl font-extrabold text-white bg-gradient-to-r from-sky-600 to-teal-600 hover:from-sky-700 hover:to-teal-700 shadow-lg flex items-center justify-center gap-2 cursor-pointer text-sm",
										children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-4 h-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 172,
											columnNumber: 17
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Book A Free Smile Consultation" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 173,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 168,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 167,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 130,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 27,
		columnNumber: 5
	}, this);
};
_s(SmileGallerySection, "SGka4i5EyzDCaRTj7sGutNJVgpk=", false, function() {
	return [useTheme];
});
_c = SmileGallerySection;
var _c;
$RefreshReg$(_c, "SmileGallerySection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/SmileGallerySection.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Aravind-Works/Dentel clinic/src/components/SmileGallerySection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Aravind-Works/Dentel clinic/src/components/SmileGallerySection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Aravind-Works/Dentel clinic/src/components/SmileGallerySection.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLGNBQWM7QUFDdkIsU0FBUyxVQUFVLFVBQVUsY0FBYyxNQUFNLHNCQUFzQjtBQUN2RSxTQUFTLGdCQUFnQjs7OztBQU96QixPQUFPLE1BQU0sdUJBQTJELEVBQUUsb0JBQW9COztDQUM1RixNQUFNLEVBQUUsV0FBVyxTQUFTO0NBQzVCLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQVMsQ0FBQztDQUN4RCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLEVBQUU7Q0FFdkQsTUFBTSxhQUE4QixPQUFPLGdCQUFnQixvQkFBb0IsT0FBTyxnQkFBZ0I7Q0FFdEcsTUFBTSxvQkFBb0IsTUFBMkU7RUFDbkcsTUFBTSxPQUFPLEVBQUUsY0FBYyxzQkFBc0I7RUFDbkQsTUFBTSxVQUFVLGFBQWEsSUFBSSxFQUFFLFFBQVEsRUFBRSxDQUFDLFVBQVUsRUFBRTtFQUMxRCxNQUFNLElBQUksVUFBVSxLQUFLO0VBQ3pCLE1BQU0sYUFBYSxLQUFLLElBQUksS0FBSyxJQUFLLElBQUksS0FBSyxRQUFTLEtBQUssQ0FBQyxHQUFHLEdBQUc7RUFDcEUsa0JBQWtCLFVBQVU7Q0FDOUI7Q0FFQSxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxJQUFHO0VBQWtCLFdBQVU7WUFBeEM7R0FFRSx3QkFBQyxPQUFELEVBQUssV0FBVSwyRkFBNEY7Ozs7O0dBQzNHLHdCQUFDLE9BQUQsRUFBSyxXQUFVLDhGQUErRjs7Ozs7R0FFOUcsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUdFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSwyQkFBNEI7Ozs7a0JBQUMsb0NBRTlDOzs7Ozs7T0FDTCx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZCxDQUFrRiwwQkFDMUQsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWdCO1FBQWE7Ozs7Z0JBQ2pFOzs7Ozs7T0FDSix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBa0Q7T0FFNUQ7Ozs7O01BQ0E7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLE9BQU8sZ0JBQWdCLEtBQUssR0FBRyxRQUM5Qix3QkFBQyxVQUFEO09BRUUsZUFBZTtRQUNiLG1CQUFtQixHQUFHO1FBQ3RCLGtCQUFrQixFQUFFO09BQ3RCO09BQ0EsV0FBVyxpRkFDVCxvQkFBb0IsTUFDaEIsNkVBQ0E7aUJBR0wsRUFBRTtNQUNHLEdBWkQsRUFBRTs7OzthQVlELENBQ1Q7S0FDRTs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUdFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBRUUsd0JBQUMsT0FBRDtTQUNFLFdBQVU7U0FDVixhQUFhO1NBQ2IsYUFBYTttQkFIZjtVQU1FLHdCQUFDLE9BQUQ7V0FDRSxLQUFLLFdBQVc7V0FDaEIsS0FBSyxHQUFHLFdBQVcsY0FBYztXQUNqQyxXQUFVO1VBQ1g7Ozs7O1VBR0Qsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQTZHO1VBRXZIOzs7OztVQUdOLHdCQUFDLE9BQUQ7V0FDRSxXQUFVO1dBQ1YsT0FBTyxFQUFFLE9BQU8sR0FBRyxlQUFlLEdBQUc7cUJBRnZDLENBSUUsd0JBQUMsT0FBRDtZQUNFLEtBQUssV0FBVztZQUNoQixLQUFLLEdBQUcsV0FBVyxjQUFjO1lBQ2pDLFdBQVU7WUFDVixPQUFPO2FBQUUsT0FBTzthQUFRLFFBQVE7WUFBTztXQUN4Qzs7OztxQkFFRCx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBcUk7V0FFL0k7Ozs7bUJBQ0g7Ozs7OztVQUdMLHdCQUFDLE9BQUQ7V0FDRSxXQUFVO1dBQ1YsT0FBTyxFQUFFLE1BQU0sR0FBRyxlQUFlLEdBQUc7cUJBRXBDLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNiLHdCQUFDLGdCQUFELEVBQWdCLFdBQVUsdUJBQXdCOzs7OztXQUMvQzs7Ozs7VUFDRjs7Ozs7U0FFRjs7Ozs7a0JBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxnQkFBRCxFQUFnQixXQUFVLDJCQUE0Qjs7OzttQkFDdEQsd0JBQUMsUUFBRCxZQUFNLGdFQUFtRTs7OztpQkFDdEU7Ozs7O2dCQUNGOzs7Ozs7TUFDRjs7OztnQkFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCLENBQStFLGlCQUMvRCxXQUFXLFFBQ3JCOzs7Ozs7VUFDTix3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFDWCxXQUFXO1VBQ1Y7Ozs7O1VBQ0osd0JBQUMsS0FBRDtXQUFHLFdBQVU7cUJBQ1YsV0FBVztVQUNYOzs7OztTQUNBOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBcUM7VUFBa0I7Ozs7b0JBQ3ZFLHdCQUFDLFVBQUQ7V0FBUSxXQUFVO3FCQUFsQixDQUNFLHdCQUFDLE1BQUQsRUFBTSxXQUFVLDJCQUE0Qjs7OztxQkFDM0MsV0FBVyxXQUNOOzs7OztrQkFDTDs7Ozs7VUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQXFDO1VBQW9COzs7O29CQUN6RSx3QkFBQyxVQUFEO1dBQVEsV0FBVTtxQkFDZixXQUFXO1VBQ047Ozs7a0JBQ0w7Ozs7O1VBQ0wsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBcUM7V0FBeUI7Ozs7cUJBQzlFLHdCQUFDLFVBQUQ7WUFBUSxXQUFVO3NCQUNmLFdBQVc7V0FDTjs7OzttQkFDTDs7Ozs7O1NBQ0Y7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLFVBQUQ7VUFDRSxlQUFlLGNBQWM7VUFDN0IsV0FBVTtvQkFGWixDQUlFLHdCQUFDLFVBQUQsRUFBVSxXQUFVLFVBQVc7Ozs7b0JBQy9CLHdCQUFDLFFBQUQsWUFBTSxpQ0FBb0M7Ozs7a0JBQ3BDOzs7Ozs7UUFDTDs7Ozs7T0FDRjs7Ozs7Y0FFRjs7Ozs7O0lBRUY7Ozs7OztFQUNFOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTbWlsZUdhbGxlcnlTZWN0aW9uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBtb3Rpb24gfSBmcm9tICdmcmFtZXItbW90aW9uJztcbmltcG9ydCB7IFNwYXJrbGVzLCBDYWxlbmRhciwgQ2hlY2tDaXJjbGUyLCBVc2VyLCBBcnJvd0xlZnRSaWdodCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJ0AvY29udGV4dC9UaGVtZUNvbnRleHQnO1xuaW1wb3J0IHR5cGUgeyBCZWZvcmVBZnRlckNhc2UgfSBmcm9tICdAL2NvbmZpZy9zaXRlQ29uZmlnJztcblxuaW50ZXJmYWNlIFNtaWxlR2FsbGVyeVNlY3Rpb25Qcm9wcyB7XG4gIG9uT3BlbkJvb2tpbmc6IChzZXJ2aWNlSWQ/OiBzdHJpbmcpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBTbWlsZUdhbGxlcnlTZWN0aW9uOiBSZWFjdC5GQzxTbWlsZUdhbGxlcnlTZWN0aW9uUHJvcHM+ID0gKHsgb25PcGVuQm9va2luZyB9KSA9PiB7XG4gIGNvbnN0IHsgY29uZmlnIH0gPSB1c2VUaGVtZSgpO1xuICBjb25zdCBbYWN0aXZlQ2FzZUluZGV4LCBzZXRBY3RpdmVDYXNlSW5kZXhdID0gdXNlU3RhdGUoMCk7XG4gIGNvbnN0IFtzbGlkZXJQb3NpdGlvbiwgc2V0U2xpZGVyUG9zaXRpb25dID0gdXNlU3RhdGUoNTApOyAvLyAwIHRvIDEwMCVcblxuICBjb25zdCBhY3RpdmVDYXNlOiBCZWZvcmVBZnRlckNhc2UgPSBjb25maWcudHJhbnNmb3JtYXRpb25zW2FjdGl2ZUNhc2VJbmRleF0gfHwgY29uZmlnLnRyYW5zZm9ybWF0aW9uc1swXTtcblxuICBjb25zdCBoYW5kbGVTbGlkZXJNb3ZlID0gKGU6IFJlYWN0Lk1vdXNlRXZlbnQ8SFRNTERpdkVsZW1lbnQ+IHwgUmVhY3QuVG91Y2hFdmVudDxIVE1MRGl2RWxlbWVudD4pID0+IHtcbiAgICBjb25zdCByZWN0ID0gZS5jdXJyZW50VGFyZ2V0LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIGNvbnN0IGNsaWVudFggPSAndG91Y2hlcycgaW4gZSA/IGUudG91Y2hlc1swXS5jbGllbnRYIDogZS5jbGllbnRYO1xuICAgIGNvbnN0IHggPSBjbGllbnRYIC0gcmVjdC5sZWZ0O1xuICAgIGNvbnN0IHBlcmNlbnRhZ2UgPSBNYXRoLm1pbihNYXRoLm1heCgoeCAvIHJlY3Qud2lkdGgpICogMTAwLCAwKSwgMTAwKTtcbiAgICBzZXRTbGlkZXJQb3NpdGlvbihwZXJjZW50YWdlKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGlkPVwidHJhbnNmb3JtYXRpb25zXCIgY2xhc3NOYW1lPVwicHktMjAgYmctc2xhdGUtNTAvNzAgYm9yZGVyLXkgYm9yZGVyLXNsYXRlLTIwMCByZWxhdGl2ZSBvdmVyZmxvdy1oaWRkZW5cIj5cbiAgICAgIHsvKiBEZWNvcmF0aXZlIGFtYmllbnQgYmFja2dyb3VuZCAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCB3LTk2IGgtOTYgYmctc2t5LTEwMC81MCByb3VuZGVkLWZ1bGwgYmx1ci0zeGwgcG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS0wIGxlZnQtMCB3LTk2IGgtOTYgYmctdGVhbC0xMDAvNTAgcm91bmRlZC1mdWxsIGJsdXItM3hsIHBvaW50ZXItZXZlbnRzLW5vbmVcIiAvPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTd4bCBteC1hdXRvIHB4LTQgc206cHgtNiBsZzpweC04IHJlbGF0aXZlXCI+XG4gICAgICAgIFxuICAgICAgICB7LyogU2VjdGlvbiBIZWFkZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgbWF4LXctM3hsIG14LWF1dG8gc3BhY2UteS0zXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtMy41IHB5LTEuNSByb3VuZGVkLWZ1bGwgYmctc2t5LTEwMCBib3JkZXIgYm9yZGVyLXNreS0yMDAgdGV4dC1za3ktOTAwIHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtc2t5LTYwMFwiIC8+XG4gICAgICAgICAgICBSZWFsIFBhdGllbnRzIOKAoiBSZWFsIFNtaWxlIFJlc3VsdHNcbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0zeGwgc206dGV4dC00eGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgdHJhY2tpbmctdGlnaHRcIj5cbiAgICAgICAgICAgIFNtaWxlIFRyYW5zZm9ybWF0aW9ucyA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYWRpZW50XCI+R2FsbGVyeTwvc3Bhbj5cbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwIHRleHQtc20gc206dGV4dC1iYXNlIGZvbnQtbm9ybWFsXCI+XG4gICAgICAgICAgICBEcmFnIHRoZSBpbnRlcmFjdGl2ZSBzbGlkZXIgYmVsb3cgdG8gd2l0bmVzcyBkcmFtYXRpYyBiZWZvcmUtYW5kLWFmdGVyIHNtaWxlIHJlc3R5bGluZyBjcmFmdGVkIGJ5IG91ciBzcGVjaWFsaXN0IHN1cmdlb25zLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIENhc2Ugc2VsZWN0b3IgdGFicyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC04IGZsZXggZmxleC13cmFwIGp1c3RpZnktY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAge2NvbmZpZy50cmFuc2Zvcm1hdGlvbnMubWFwKChjLCBpZHgpID0+IChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAga2V5PXtjLmlkfVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0QWN0aXZlQ2FzZUluZGV4KGlkeCk7XG4gICAgICAgICAgICAgICAgc2V0U2xpZGVyUG9zaXRpb24oNTApO1xuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTIuNSByb3VuZGVkLXhsIHRleHQteHMgc206dGV4dC1zbSBmb250LWJvbGQgdHJhbnNpdGlvbiBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgIGFjdGl2ZUNhc2VJbmRleCA9PT0gaWR4XG4gICAgICAgICAgICAgICAgICA/ICdiZy1ncmFkaWVudC10by1yIGZyb20tc2t5LTYwMCB0by10ZWFsLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCBzY2FsZS0xMDUnXG4gICAgICAgICAgICAgICAgICA6ICdiZy13aGl0ZSB0ZXh0LXNsYXRlLTcwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBob3Zlcjpib3JkZXItc2t5LTQwMCdcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtjLmNhdGVnb3J5fVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBJbnRlcmFjdGl2ZSBCZWZvcmUgJiBBZnRlciBDYXJkICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwIGdyaWQgZ3JpZC1jb2xzLTEgbGc6Z3JpZC1jb2xzLTEyIGdhcC04IGl0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgIFxuICAgICAgICAgIHsvKiBMZWZ0OiBJbnRlcmFjdGl2ZSBEcmFnIENvbXBhcmlzb24gSW1hZ2UgQ29udGFpbmVyICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tN1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSByb3VuZGVkLTN4bCBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgc2hhZG93LTJ4bCBiZy13aGl0ZSBzZWxlY3Qtbm9uZVwiPlxuICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgPGRpdiBcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBoLTgwIHNtOmgtOTYgbWQ6aC1bNDIwcHhdIHctZnVsbCBjdXJzb3ItZXctcmVzaXplIG92ZXJmbG93LWhpZGRlblwiXG4gICAgICAgICAgICAgICAgb25Nb3VzZU1vdmU9e2hhbmRsZVNsaWRlck1vdmV9XG4gICAgICAgICAgICAgICAgb25Ub3VjaE1vdmU9e2hhbmRsZVNsaWRlck1vdmV9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7LyogQUZURVIgSU1BR0UgKEJhc2UgSW1hZ2UpICovfVxuICAgICAgICAgICAgICAgIDxpbWcgXG4gICAgICAgICAgICAgICAgICBzcmM9e2FjdGl2ZUNhc2UuYWZ0ZXJJbWFnZX0gXG4gICAgICAgICAgICAgICAgICBhbHQ9e2Ake2FjdGl2ZUNhc2UudHJlYXRtZW50TmFtZX0gQWZ0ZXJgfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCB3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlclwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICBcbiAgICAgICAgICAgICAgICB7LyogQWZ0ZXIgTGFiZWwgKi99XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTQgcmlnaHQtNCBiZy1lbWVyYWxkLTYwMCB0ZXh0LXdoaXRlIGZvbnQtZXh0cmFib2xkIHRleHQteHMgcHgtMy41IHB5LTEgcm91bmRlZC1mdWxsIHNoYWRvdy1sZ1wiPlxuICAgICAgICAgICAgICAgICAgQUZURVIgUkVTVUxUXG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgICAgICAgey8qIEJFRk9SRSBJTUFHRSAoQ2xpcHBlZCBvdmVybGF5KSAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgYm90dG9tLTAgbGVmdC0wIG92ZXJmbG93LWhpZGRlblwiXG4gICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7c2xpZGVyUG9zaXRpb259JWAgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8aW1nIFxuICAgICAgICAgICAgICAgICAgICBzcmM9e2FjdGl2ZUNhc2UuYmVmb3JlSW1hZ2V9IFxuICAgICAgICAgICAgICAgICAgICBhbHQ9e2Ake2FjdGl2ZUNhc2UudHJlYXRtZW50TmFtZX0gQmVmb3JlYH1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaW5zZXQtMCB3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlciBtYXgtdy1ub25lXCJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6ICcxMDAlJywgaGVpZ2h0OiAnMTAwJScgfX1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICB7LyogQmVmb3JlIExhYmVsICovfVxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTQgbGVmdC00IGJnLXNsYXRlLTkwMC85MCB0ZXh0LXdoaXRlIGZvbnQtZXh0cmFib2xkIHRleHQteHMgcHgtMy41IHB5LTEgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHNoYWRvdy1sZ1wiPlxuICAgICAgICAgICAgICAgICAgICBCRUZPUkVcbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBWZXJ0aWNhbCBEaXZpZGVyICYgRHJhZyBIYW5kbGUgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0wIGJvdHRvbS0wIHctMSBiZy13aGl0ZSBzaGFkb3ctWzBfMF8xMHB4X3JnYmEoMCwwLDAsMC41KV0gY3Vyc29yLWV3LXJlc2l6ZSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwb2ludGVyLWV2ZW50cy1ub25lXCJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGxlZnQ6IGAke3NsaWRlclBvc2l0aW9ufSVgIH19XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC1mdWxsIGJnLXdoaXRlIHRleHQtc2xhdGUtOTAwIHNoYWRvdy0yeGwgYm9yZGVyLTIgYm9yZGVyLXNreS02MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZm9udC1ib2xkIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAgPEFycm93TGVmdFJpZ2h0IGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1za3ktNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBTbGlkZXIgSW5zdHJ1Y3Rpb24gRm9vdGVyICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy13aGl0ZSB0ZXh0LWNlbnRlciB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS01MDAgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTIwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxBcnJvd0xlZnRSaWdodCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXNreS02MDBcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkRyYWcgc2xpZGVyIGxlZnQgb3IgcmlnaHQgdG8gY29tcGFyZSB0cmFuc2Zvcm1hdGlvbmFsIHJlc3VsdHM8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogUmlnaHQ6IENhc2UgRGV0YWlscyAmIERvY3RvciBJbmZvICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNSBzcGFjZS15LTZcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1leHRyYWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2t5LTYwMFwiPlxuICAgICAgICAgICAgICAgIENhc2UgU3R1ZHkg4oCiIHthY3RpdmVDYXNlLmNhdGVnb3J5fVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBzbTp0ZXh0LTN4bCBmb250LWJvbGQgdGV4dC1zbGF0ZS05MDBcIj5cbiAgICAgICAgICAgICAgICB7YWN0aXZlQ2FzZS50cmVhdG1lbnROYW1lfVxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtc2xhdGUtNjAwIGxlYWRpbmctcmVsYXhlZCBmb250LW5vcm1hbFwiPlxuICAgICAgICAgICAgICAgIHthY3RpdmVDYXNlLmRlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIE1ldHJpY3MgQnJlYWtkb3duICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00IHAtNSByb3VuZGVkLTJ4bCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCB0ZXh0LXhzIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwIGJsb2NrIGZvbnQtc2VtaWJvbGRcIj5QYXRpZW50IE5hbWU8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTkwMCBmb250LWV4dHJhYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IG10LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgPFVzZXIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1za3ktNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIHthY3RpdmVDYXNlLnBhdGllbnROYW1lfVxuICAgICAgICAgICAgICAgIDwvc3Ryb25nPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBibG9jayBmb250LXNlbWlib2xkXCI+VG90YWwgRHVyYXRpb248L3NwYW4+XG4gICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNzAwIGZvbnQtZXh0cmFib2xkIG10LTAuNSBibG9ja1wiPlxuICAgICAgICAgICAgICAgICAge2FjdGl2ZUNhc2UuZHVyYXRpb259XG4gICAgICAgICAgICAgICAgPC9zdHJvbmc+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTIgcHQtMyBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS01MDAgYmxvY2sgZm9udC1zZW1pYm9sZFwiPkxlYWQgRGVudGFsIFN1cmdlb248L3NwYW4+XG4gICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTkwMCBmb250LWV4dHJhYm9sZCB0ZXh0LXNtIG10LTAuNSBibG9ja1wiPlxuICAgICAgICAgICAgICAgICAge2FjdGl2ZUNhc2UuZGVudGlzdE5hbWV9XG4gICAgICAgICAgICAgICAgPC9zdHJvbmc+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBDVEEgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTJcIj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uT3BlbkJvb2tpbmcoKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktNCBweC02IHJvdW5kZWQteGwgZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZSBiZy1ncmFkaWVudC10by1yIGZyb20tc2t5LTYwMCB0by10ZWFsLTYwMCBob3Zlcjpmcm9tLXNreS03MDAgaG92ZXI6dG8tdGVhbC03MDAgc2hhZG93LWxnIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyIHRleHQtc21cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPENhbGVuZGFyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkJvb2sgQSBGcmVlIFNtaWxlIENvbnN1bHRhdGlvbjwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8L2Rpdj5cblxuICAgICAgPC9kaXY+XG4gICAgPC9zZWN0aW9uPlxuICApO1xufTtcbiJdfQ==