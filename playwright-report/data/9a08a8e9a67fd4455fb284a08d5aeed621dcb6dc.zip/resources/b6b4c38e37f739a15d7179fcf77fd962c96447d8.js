import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Footer.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=383ccf5c";
import { Phone, Mail, MapPin, Clock, ShieldCheck, Heart, ArrowUp, Globe, Share2 } from "/node_modules/.vite/deps/lucide-react.js?v=a18529f7";
import { useTheme } from "/src/context/ThemeContext.tsx";
import { DynamicIcon } from "/src/components/DynamicIcon.tsx";
var _jsxFileName = "D:/Aravind-Works/Dentel clinic/src/components/Footer.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=383ccf5c";
var _s = $RefreshSig$();
export const Footer = () => {
	_s();
	const { config } = useTheme();
	const scrollToTop = () => {
		window.scrollTo({
			top: 0,
			behavior: "smooth"
		});
	};
	return /* @__PURE__ */ _jsxDEV("footer", {
		className: "bg-slate-50 text-slate-700 pt-16 pb-8 border-t border-slate-200",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-slate-200",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "lg:col-span-4 space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("a", {
								href: "#hero",
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-600 to-teal-600 flex items-center justify-center text-white shadow-md",
									children: /* @__PURE__ */ _jsxDEV(DynamicIcon, {
										name: config.logo.icon,
										className: "w-6 h-6"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 34,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 33,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xl font-black tracking-tight text-slate-900 block font-['Outfit']",
									children: config.logo.text
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 37,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "block text-[10px] font-bold tracking-wider uppercase text-sky-600",
									children: config.logo.subtext
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 40,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 36,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 32,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-600 leading-relaxed max-w-sm font-normal",
								children: config.subtagline
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 46,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "pt-2 flex items-center gap-3 text-slate-600",
								children: [
									/* @__PURE__ */ _jsxDEV("a", {
										href: config.socials.instagram,
										target: "_blank",
										rel: "noreferrer",
										"aria-label": "Instagram",
										className: "p-2 rounded-xl bg-white border border-slate-200 hover:border-sky-500 hover:text-sky-600 transition shadow-sm",
										children: /* @__PURE__ */ _jsxDEV("svg", {
											className: "w-4 h-4 fill-current",
											viewBox: "0 0 24 24",
											children: /* @__PURE__ */ _jsxDEV("path", { d: "M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 52,
												columnNumber: 75
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 52,
											columnNumber: 17
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 51,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("a", {
										href: config.socials.facebook,
										target: "_blank",
										rel: "noreferrer",
										"aria-label": "Facebook",
										className: "p-2 rounded-xl bg-white border border-slate-200 hover:border-sky-500 hover:text-sky-600 transition shadow-sm",
										children: /* @__PURE__ */ _jsxDEV("svg", {
											className: "w-4 h-4 fill-current",
											viewBox: "0 0 24 24",
											children: /* @__PURE__ */ _jsxDEV("path", { d: "M9 8H6v4h3v12h5V12h3.642L18 8h-4V6.333C14 5.374 14.5 5 15.714 5H18V0h-3.808C10.592 0 9 1.583 9 4.615V8z" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 55,
												columnNumber: 75
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 55,
											columnNumber: 17
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 54,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("a", {
										href: config.socials.youtube,
										target: "_blank",
										rel: "noreferrer",
										"aria-label": "YouTube",
										className: "p-2 rounded-xl bg-white border border-slate-200 hover:border-sky-500 hover:text-sky-600 transition shadow-sm",
										children: /* @__PURE__ */ _jsxDEV("svg", {
											className: "w-4 h-4 fill-current",
											viewBox: "0 0 24 24",
											children: /* @__PURE__ */ _jsxDEV("path", { d: "M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 58,
												columnNumber: 75
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 58,
											columnNumber: 17
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 57,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ _jsxDEV("a", {
										href: config.socials.twitter,
										target: "_blank",
										rel: "noreferrer",
										"aria-label": "Twitter",
										className: "p-2 rounded-xl bg-white border border-slate-200 hover:border-sky-500 hover:text-sky-600 transition shadow-sm",
										children: /* @__PURE__ */ _jsxDEV("svg", {
											className: "w-4 h-4 fill-current",
											viewBox: "0 0 24 24",
											children: /* @__PURE__ */ _jsxDEV("path", { d: "M24 4.557c-.883.392-1.832.656-2.828.775 1.017-.609 1.798-1.574 2.165-2.724-.951.564-2.005.974-3.127 1.195-.897-.957-2.178-1.555-3.594-1.555-3.179 0-5.515 2.966-4.797 6.045-4.091-.205-7.719-2.165-10.148-5.144-1.29 2.213-.669 5.108 1.523 6.574-.806-.026-1.566-.247-2.229-.616-.054 2.281 1.581 4.415 3.949 4.89-.693.188-1.452.232-2.224.084.626 1.956 2.444 3.379 4.6 3.419-2.07 1.623-4.678 2.348-7.29 2.04 2.179 1.397 4.768 2.212 7.548 2.212 9.142 0 14.307-7.721 13.995-14.646.962-.695 1.797-1.562 2.457-2.549z" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 61,
												columnNumber: 75
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 61,
											columnNumber: 17
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 60,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 50,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "lg:col-span-3 space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("h4", {
							className: "text-xs font-bold text-slate-900 uppercase tracking-wider",
							children: "Quick Navigation"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("ul", {
							className: "space-y-2 text-xs",
							children: config.navigation.map((item) => /* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("a", {
								href: item.href,
								className: "text-slate-600 hover:text-sky-600 transition font-medium",
								children: item.name
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 74,
								columnNumber: 19
							}, this) }, item.name, false, {
								fileName: _jsxFileName,
								lineNumber: 73,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 71,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "lg:col-span-3 space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("h4", {
							className: "text-xs font-bold text-slate-900 uppercase tracking-wider",
							children: "Studio Locations"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3 text-xs",
							children: config.contact.branches.map((b, idx) => /* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-0.5",
								children: [
									/* @__PURE__ */ _jsxDEV("strong", {
										className: "text-slate-900 block font-bold",
										children: b.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 90,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-slate-600 font-normal",
										children: b.address
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 91,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-sky-700 font-bold",
										children: b.phone
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 92,
										columnNumber: 19
									}, this)
								]
							}, idx, true, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "lg:col-span-2 space-y-3",
						children: [/* @__PURE__ */ _jsxDEV("h4", {
							className: "text-xs font-bold text-slate-900 uppercase tracking-wider",
							children: "Hours & Emergency"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 100,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2 text-xs text-slate-600",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-start gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 105,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "font-semibold text-slate-900",
									children: config.contact.workingHours.weekdays
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 107,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "text-[10px] text-slate-500 mt-0.5",
									children: config.contact.workingHours.sunday
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 108,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 106,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "pt-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] uppercase font-extrabold text-amber-600 block",
									children: "24/7 Emergency Line"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 113,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("a", {
									href: `tel:${config.contact.emergencyPhone}`,
									className: "text-sm font-extrabold text-slate-900 hover:underline",
									children: config.contact.emergencyPhone
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 114,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 112,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [
					"© ",
					new Date().getFullYear(),
					" ",
					config.name,
					". All rights reserved. Precision Dentistry Studio."
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 125,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-4",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "flex items-center gap-1 font-semibold text-slate-700",
						children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-4 h-4 text-sky-600" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 131,
							columnNumber: 15
						}, this), " ISO 9001 Certified"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 130,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: scrollToTop,
						className: "p-2 rounded-xl bg-white border border-slate-200 text-slate-700 hover:text-sky-600 hover:border-sky-400 transition shadow-sm",
						"aria-label": "Back to Top",
						children: /* @__PURE__ */ _jsxDEV(ArrowUp, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 139,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 134,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 129,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 124,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 5
	}, this);
};
_s(Footer, "qQ7g6tIEyataPS75zVi2PFhrMqc=", false, function() {
	return [useTheme];
});
_c = Footer;
var _c;
$RefreshReg$(_c, "Footer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Footer.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Aravind-Works/Dentel clinic/src/components/Footer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Aravind-Works/Dentel clinic/src/components/Footer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Aravind-Works/Dentel clinic/src/components/Footer.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQ0UsT0FDQSxNQUNBLFFBQ0EsT0FDQSxhQUNBLE9BQ0EsU0FDQSxPQUNBLGNBQ0s7QUFDUCxTQUFTLGdCQUFnQjtBQUN6QixTQUFTLG1CQUFtQjs7OztBQUU1QixPQUFPLE1BQU0sZUFBeUI7O0NBQ3BDLE1BQU0sRUFBRSxXQUFXLFNBQVM7Q0FFNUIsTUFBTSxvQkFBb0I7RUFDeEIsT0FBTyxTQUFTO0dBQUUsS0FBSztHQUFHLFVBQVU7RUFBUyxDQUFDO0NBQ2hEO0NBRUEsT0FDRSx3QkFBQyxVQUFEO0VBQVEsV0FBVTtZQUNoQix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBR0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUdFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsS0FBRDtRQUFHLE1BQUs7UUFBUSxXQUFVO2tCQUExQixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNiLHdCQUFDLGFBQUQ7VUFBYSxNQUFNLE9BQU8sS0FBSztVQUFNLFdBQVU7U0FBVzs7Ozs7UUFDdkQ7Ozs7a0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNiLE9BQU8sS0FBSztRQUNUOzs7O2tCQUNOLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNiLE9BQU8sS0FBSztRQUNUOzs7O2dCQUNIOzs7O2dCQUNKOzs7Ozs7T0FFSCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFDVixPQUFPO09BQ1A7Ozs7O09BRUgsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxLQUFEO1VBQUcsTUFBTSxPQUFPLFFBQVE7VUFBVyxRQUFPO1VBQVMsS0FBSTtVQUFhLGNBQVc7VUFBWSxXQUFVO29CQUNuRyx3QkFBQyxPQUFEO1dBQUssV0FBVTtXQUF1QixTQUFRO3FCQUFZLHdCQUFDLFFBQUQsRUFBTSxHQUFFLGlqQ0FBaWpDOzs7OztVQUFNOzs7OztTQUN4bkM7Ozs7O1NBQ0gsd0JBQUMsS0FBRDtVQUFHLE1BQU0sT0FBTyxRQUFRO1VBQVUsUUFBTztVQUFTLEtBQUk7VUFBYSxjQUFXO1VBQVcsV0FBVTtvQkFDakcsd0JBQUMsT0FBRDtXQUFLLFdBQVU7V0FBdUIsU0FBUTtxQkFBWSx3QkFBQyxRQUFELEVBQU0sR0FBRSwwR0FBMEc7Ozs7O1VBQU07Ozs7O1NBQ2pMOzs7OztTQUNILHdCQUFDLEtBQUQ7VUFBRyxNQUFNLE9BQU8sUUFBUTtVQUFTLFFBQU87VUFBUyxLQUFJO1VBQWEsY0FBVztVQUFVLFdBQVU7b0JBQy9GLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO1dBQXVCLFNBQVE7cUJBQVksd0JBQUMsUUFBRCxFQUFNLEdBQUUsK1ZBQStWOzs7OztVQUFNOzs7OztTQUN0YTs7Ozs7U0FDSCx3QkFBQyxLQUFEO1VBQUcsTUFBTSxPQUFPLFFBQVE7VUFBUyxRQUFPO1VBQVMsS0FBSTtVQUFhLGNBQVc7VUFBVSxXQUFVO29CQUMvRix3QkFBQyxPQUFEO1dBQUssV0FBVTtXQUF1QixTQUFRO3FCQUFZLHdCQUFDLFFBQUQsRUFBTSxHQUFFLDZmQUE2Zjs7Ozs7VUFBTTs7Ozs7U0FDcGtCOzs7OztRQUNBOzs7Ozs7TUFDRjs7Ozs7O0tBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBNEQ7TUFFdEU7Ozs7Z0JBQ0osd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQ1gsT0FBTyxXQUFXLEtBQUssU0FDdEIsd0JBQUMsTUFBRCxZQUNFLHdCQUFDLEtBQUQ7UUFBRyxNQUFNLEtBQUs7UUFBTSxXQUFVO2tCQUMzQixLQUFLO09BQ0w7Ozs7Z0JBQ0QsR0FKSyxLQUFLOzs7O2NBSVYsQ0FDTDtNQUNDOzs7O2NBQ0Q7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQTREO01BRXRFOzs7O2dCQUNKLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLE9BQU8sUUFBUSxTQUFTLEtBQUssR0FBRyxRQUMvQix3QkFBQyxPQUFEO1FBQWUsV0FBVTtrQkFBekI7U0FDRSx3QkFBQyxVQUFEO1VBQVEsV0FBVTtvQkFBa0MsRUFBRTtTQUFhOzs7OztTQUNuRSx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBOEIsRUFBRTtTQUFXOzs7OztTQUN4RCx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBMEIsRUFBRTtTQUFTOzs7OztRQUMvQztVQUpLOzs7O2NBSUwsQ0FDTjtNQUNFOzs7O2NBQ0Y7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQTREO01BRXRFOzs7O2dCQUNKLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSxnREFBaUQ7Ozs7a0JBQ2xFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZ0MsT0FBTyxRQUFRLGFBQWE7UUFBYzs7OztrQkFDekYsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQXFDLE9BQU8sUUFBUSxhQUFhO1FBQVk7Ozs7Z0JBQ3pGOzs7O2dCQUNGOzs7OztpQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUE0RDtRQUF5Qjs7OztrQkFDckcsd0JBQUMsS0FBRDtTQUFHLE1BQU0sT0FBTyxPQUFPLFFBQVE7U0FBa0IsV0FBVTttQkFDeEQsT0FBTyxRQUFRO1FBQ2Y7Ozs7Z0JBQ0E7Ozs7O2VBQ0Y7Ozs7O2NBQ0Y7Ozs7OztJQUVGOzs7OzthQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUs7S0FDQSxJQUFJLEtBQUssQ0FBQyxDQUFDLFlBQVk7S0FBRTtLQUFFLE9BQU87S0FBSztJQUN2Qzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEIsQ0FDRSx3QkFBQyxhQUFELEVBQWEsV0FBVSx1QkFBd0I7Ozs7Z0JBQUMscUJBQzVDOzs7OztlQUVOLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtNQUNWLGNBQVc7Z0JBRVgsd0JBQUMsU0FBRCxFQUFTLFdBQVUsVUFBVzs7Ozs7S0FDeEI7Ozs7YUFDTDs7Ozs7WUFDRjs7Ozs7V0FFRjs7Ozs7O0NBQ0M7Ozs7O0FBRVoiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRm9vdGVyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgXG4gIFBob25lLCBcbiAgTWFpbCwgXG4gIE1hcFBpbiwgXG4gIENsb2NrLCBcbiAgU2hpZWxkQ2hlY2ssIFxuICBIZWFydCxcbiAgQXJyb3dVcCxcbiAgR2xvYmUsXG4gIFNoYXJlMlxufSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICdAL2NvbnRleHQvVGhlbWVDb250ZXh0JztcbmltcG9ydCB7IER5bmFtaWNJY29uIH0gZnJvbSAnQC9jb21wb25lbnRzL0R5bmFtaWNJY29uJztcblxuZXhwb3J0IGNvbnN0IEZvb3RlcjogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIGNvbnN0IHsgY29uZmlnIH0gPSB1c2VUaGVtZSgpO1xuXG4gIGNvbnN0IHNjcm9sbFRvVG9wID0gKCkgPT4ge1xuICAgIHdpbmRvdy5zY3JvbGxUbyh7IHRvcDogMCwgYmVoYXZpb3I6ICdzbW9vdGgnIH0pO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGZvb3RlciBjbGFzc05hbWU9XCJiZy1zbGF0ZS01MCB0ZXh0LXNsYXRlLTcwMCBwdC0xNiBwYi04IGJvcmRlci10IGJvcmRlci1zbGF0ZS0yMDBcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctN3hsIG14LWF1dG8gcHgtNCBzbTpweC02IGxnOnB4LThcIj5cbiAgICAgICAgXG4gICAgICAgIHsvKiBNYWluIEZvb3RlciBHcmlkICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTEyIGdhcC0xMCBwYi0xMiBib3JkZXItYiBib3JkZXItc2xhdGUtMjAwXCI+XG4gICAgICAgICAgXG4gICAgICAgICAgey8qIEJyYW5kIEluZm8gKDQgY29scykgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi00IHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgPGEgaHJlZj1cIiNoZXJvXCIgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC14bCBiZy1ncmFkaWVudC10by10ciBmcm9tLXNreS02MDAgdG8tdGVhbC02MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC13aGl0ZSBzaGFkb3ctbWRcIj5cbiAgICAgICAgICAgICAgICA8RHluYW1pY0ljb24gbmFtZT17Y29uZmlnLmxvZ28uaWNvbn0gY2xhc3NOYW1lPVwidy02IGgtNlwiIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ibGFjayB0cmFja2luZy10aWdodCB0ZXh0LXNsYXRlLTkwMCBibG9jayBmb250LVsnT3V0Zml0J11cIj5cbiAgICAgICAgICAgICAgICAgIHtjb25maWcubG9nby50ZXh0fVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdHJhY2tpbmctd2lkZXIgdXBwZXJjYXNlIHRleHQtc2t5LTYwMFwiPlxuICAgICAgICAgICAgICAgICAge2NvbmZpZy5sb2dvLnN1YnRleHR9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvYT5cblxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTYwMCBsZWFkaW5nLXJlbGF4ZWQgbWF4LXctc20gZm9udC1ub3JtYWxcIj5cbiAgICAgICAgICAgICAge2NvbmZpZy5zdWJ0YWdsaW5lfVxuICAgICAgICAgICAgPC9wPlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgdGV4dC1zbGF0ZS02MDBcIj5cbiAgICAgICAgICAgICAgPGEgaHJlZj17Y29uZmlnLnNvY2lhbHMuaW5zdGFncmFtfSB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub3JlZmVycmVyXCIgYXJpYS1sYWJlbD1cIkluc3RhZ3JhbVwiIGNsYXNzTmFtZT1cInAtMiByb3VuZGVkLXhsIGJnLXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGhvdmVyOmJvcmRlci1za3ktNTAwIGhvdmVyOnRleHQtc2t5LTYwMCB0cmFuc2l0aW9uIHNoYWRvdy1zbVwiPlxuICAgICAgICAgICAgICAgIDxzdmcgY2xhc3NOYW1lPVwidy00IGgtNCBmaWxsLWN1cnJlbnRcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCI+PHBhdGggZD1cIk0xMiAyLjE2M2MzLjIwNCAwIDMuNTg0LjAxMiA0Ljg1LjA3IDMuMjUyLjE0OCA0Ljc3MSAxLjY5MSA0LjkxOSA0LjkxOS4wNTggMS4yNjUuMDY5IDEuNjQ1LjA2OSA0Ljg0OSAwIDMuMjA1LS4wMTIgMy41ODQtLjA2OSA0Ljg0OS0uMTQ5IDMuMjI1LTEuNjY0IDQuNzcxLTQuOTE5IDQuOTE5LTEuMjY2LjA1OC0xLjY0NC4wNy00Ljg1LjA3LTMuMjA0IDAtMy41ODQtLjAxMi00Ljg0OS0uMDctMy4yNi0uMTQ5LTQuNzcxLTEuNjk5LTQuOTE5LTQuOTItLjA1OC0xLjI2NS0uMDctMS42NDQtLjA3LTQuODQ5IDAtMy4yMDQuMDEzLTMuNTgzLjA3LTQuODQ5LjE0OS0zLjIyNyAxLjY2NC00Ljc3MSA0LjkxOS00LjkxOSAxLjI2Ni0uMDU3IDEuNjQ1LS4wNjkgNC44NDktLjA2OXptMC0yLjE2M2MtMy4yNTkgMC0zLjY2Ny4wMTQtNC45NDcuMDcyLTQuMzU4LjItNi43OCAyLjYxOC02Ljk4IDYuOTgtLjA1OSAxLjI4MS0uMDczIDEuNjg5LS4wNzMgNC45NDggMCAzLjI1OS4wMTQgMy42NjguMDcyIDQuOTQ4LjIgNC4zNTggMi42MTggNi43OCA2Ljk4IDYuOTggMS4yODEuMDU4IDEuNjg5LjA3MiA0Ljk0OC4wNzIgMy4yNTkgMCAzLjY2OC0uMDE0IDQuOTQ4LS4wNzIgNC4zNTQtLjIgNi43ODItMi42MTggNi45NzktNi45OC4wNTktMS4yOC4wNzMtMS42ODkuMDczLTQuOTQ4IDAtMy4yNTktLjAxNC0zLjY2Ny0uMDcyLTQuOTQ3LS4xOTYtNC4zNTQtMi42MTctNi43OC02Ljk3OS02Ljk4LTEuMjgxLS4wNTktMS42OS0uMDczLTQuOTQ5LS4wNzN6bTAgNS44MzhjLTMuNDAzIDAtNi4xNjIgMi43NTktNi4xNjIgNi4xNjJzMi43NTkgNi4xNjMgNi4xNjIgNi4xNjMgNi4xNjItMi43NTkgNi4xNjItNi4xNjNjMC0zLjQwMy0yLjc1OS02LjE2Mi02LjE2Mi02LjE2MnptMCAxMC4xNjJjLTIuMjA5IDAtNC0xLjc5LTQtNCAwLTIuMjA5IDEuNzkxLTQgNC00czQgMS43OTEgNCA0YzAgMi4yMS0xLjc5MSA0LTQgNHptNi40MDYtMTEuODQ1Yy0uNzk2IDAtMS40NDEuNjQ1LTEuNDQxIDEuNDRzLjY0NSAxLjQ0IDEuNDQxIDEuNDRjLjc5NSAwIDEuNDM5LS42NDUgMS40MzktMS40NHMtLjY0NC0xLjQ0LTEuNDM5LTEuNDR6XCIvPjwvc3ZnPlxuICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgIDxhIGhyZWY9e2NvbmZpZy5zb2NpYWxzLmZhY2Vib29rfSB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub3JlZmVycmVyXCIgYXJpYS1sYWJlbD1cIkZhY2Vib29rXCIgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQteGwgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgaG92ZXI6Ym9yZGVyLXNreS01MDAgaG92ZXI6dGV4dC1za3ktNjAwIHRyYW5zaXRpb24gc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00IGZpbGwtY3VycmVudFwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj48cGF0aCBkPVwiTTkgOEg2djRoM3YxMmg1VjEyaDMuNjQyTDE4IDhoLTRWNi4zMzNDMTQgNS4zNzQgMTQuNSA1IDE1LjcxNCA1SDE4VjBoLTMuODA4QzEwLjU5MiAwIDkgMS41ODMgOSA0LjYxNVY4elwiLz48L3N2Zz5cbiAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICA8YSBocmVmPXtjb25maWcuc29jaWFscy55b3V0dWJlfSB0YXJnZXQ9XCJfYmxhbmtcIiByZWw9XCJub3JlZmVycmVyXCIgYXJpYS1sYWJlbD1cIllvdVR1YmVcIiBjbGFzc05hbWU9XCJwLTIgcm91bmRlZC14bCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBob3Zlcjpib3JkZXItc2t5LTUwMCBob3Zlcjp0ZXh0LXNreS02MDAgdHJhbnNpdGlvbiBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgICAgICA8c3ZnIGNsYXNzTmFtZT1cInctNCBoLTQgZmlsbC1jdXJyZW50XCIgdmlld0JveD1cIjAgMCAyNCAyNFwiPjxwYXRoIGQ9XCJNMjMuNDk4IDYuMTg2YTMuMDE2IDMuMDE2IDAgMCAwLTIuMTIyLTIuMTM2QzE5LjUwNSAzLjU0NSAxMiAzLjU0NSAxMiAzLjU0NXMtNy41MDUgMC05LjM3Ny41MDVBMy4wMTcgMy4wMTcgMCAwIDAgLjUwMiA2LjE4NkMwIDguMDcgMCAxMiAwIDEyczAgMy45My41MDIgNS44MTRhMy4wMTYgMy4wMTYgMCAwIDAgMi4xMjIgMi4xMzZjMS44NzEuNTA1IDkuMzc2LjUwNSA5LjM3Ni41MDVzNy41MDUgMCA5LjM3Ny0uNTA1YTMuMDE1IDMuMDE1IDAgMCAwIDIuMTIyLTIuMTM2QzI0IDE1LjkzIDI0IDEyIDI0IDEyczAtMy45My0uNTAyLTUuODE0ek05LjU0NSAxNS41NjhWOC40MzJMMTUuODE4IDEybC02LjI3MyAzLjU2OHpcIi8+PC9zdmc+XG4gICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgPGEgaHJlZj17Y29uZmlnLnNvY2lhbHMudHdpdHRlcn0gdGFyZ2V0PVwiX2JsYW5rXCIgcmVsPVwibm9yZWZlcnJlclwiIGFyaWEtbGFiZWw9XCJUd2l0dGVyXCIgY2xhc3NOYW1lPVwicC0yIHJvdW5kZWQteGwgYmctd2hpdGUgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgaG92ZXI6Ym9yZGVyLXNreS01MDAgaG92ZXI6dGV4dC1za3ktNjAwIHRyYW5zaXRpb24gc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgICAgPHN2ZyBjbGFzc05hbWU9XCJ3LTQgaC00IGZpbGwtY3VycmVudFwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIj48cGF0aCBkPVwiTTI0IDQuNTU3Yy0uODgzLjM5Mi0xLjgzMi42NTYtMi44MjguNzc1IDEuMDE3LS42MDkgMS43OTgtMS41NzQgMi4xNjUtMi43MjQtLjk1MS41NjQtMi4wMDUuOTc0LTMuMTI3IDEuMTk1LS44OTctLjk1Ny0yLjE3OC0xLjU1NS0zLjU5NC0xLjU1NS0zLjE3OSAwLTUuNTE1IDIuOTY2LTQuNzk3IDYuMDQ1LTQuMDkxLS4yMDUtNy43MTktMi4xNjUtMTAuMTQ4LTUuMTQ0LTEuMjkgMi4yMTMtLjY2OSA1LjEwOCAxLjUyMyA2LjU3NC0uODA2LS4wMjYtMS41NjYtLjI0Ny0yLjIyOS0uNjE2LS4wNTQgMi4yODEgMS41ODEgNC40MTUgMy45NDkgNC44OS0uNjkzLjE4OC0xLjQ1Mi4yMzItMi4yMjQuMDg0LjYyNiAxLjk1NiAyLjQ0NCAzLjM3OSA0LjYgMy40MTktMi4wNyAxLjYyMy00LjY3OCAyLjM0OC03LjI5IDIuMDQgMi4xNzkgMS4zOTcgNC43NjggMi4yMTIgNy41NDggMi4yMTIgOS4xNDIgMCAxNC4zMDctNy43MjEgMTMuOTk1LTE0LjY0Ni45NjItLjY5NSAxLjc5Ny0xLjU2MiAyLjQ1Ny0yLjU0OXpcIi8+PC9zdmc+XG4gICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgey8qIFF1aWNrIExpbmtzICgyIGNvbHMpICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tMyBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgICAgUXVpY2sgTmF2aWdhdGlvblxuICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJzcGFjZS15LTIgdGV4dC14c1wiPlxuICAgICAgICAgICAgICB7Y29uZmlnLm5hdmlnYXRpb24ubWFwKChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgPGxpIGtleT17aXRlbS5uYW1lfT5cbiAgICAgICAgICAgICAgICAgIDxhIGhyZWY9e2l0ZW0uaHJlZn0gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgaG92ZXI6dGV4dC1za3ktNjAwIHRyYW5zaXRpb24gZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAge2l0ZW0ubmFtZX1cbiAgICAgICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICAgICA8L2xpPlxuICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQnJhbmNoIFN0dWRpb3MgKDMgY29scykgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi0zIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICBTdHVkaW8gTG9jYXRpb25zXG4gICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTMgdGV4dC14c1wiPlxuICAgICAgICAgICAgICB7Y29uZmlnLmNvbnRhY3QuYnJhbmNoZXMubWFwKChiLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2IGtleT17aWR4fSBjbGFzc05hbWU9XCJzcGFjZS15LTAuNVwiPlxuICAgICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTkwMCBibG9jayBmb250LWJvbGRcIj57Yi5uYW1lfTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS02MDAgZm9udC1ub3JtYWxcIj57Yi5hZGRyZXNzfTwvcD5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2t5LTcwMCBmb250LWJvbGRcIj57Yi5waG9uZX08L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogRW1lcmdlbmN5ICYgSG91cnMgKDIgY29scykgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi0yIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgICBIb3VycyAmIEVtZXJnZW5jeVxuICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yIHRleHQteHMgdGV4dC1zbGF0ZS02MDBcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICA8Q2xvY2sgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNjAwIGZsZXgtc2hyaW5rLTAgbXQtMC41XCIgLz5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtc2xhdGUtOTAwXCI+e2NvbmZpZy5jb250YWN0LndvcmtpbmdIb3Vycy53ZWVrZGF5c308L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgbXQtMC41XCI+e2NvbmZpZy5jb250YWN0LndvcmtpbmdIb3Vycy5zdW5kYXl9PC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtMlwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSBmb250LWV4dHJhYm9sZCB0ZXh0LWFtYmVyLTYwMCBibG9ja1wiPjI0LzcgRW1lcmdlbmN5IExpbmU8L3NwYW4+XG4gICAgICAgICAgICAgICAgPGEgaHJlZj17YHRlbDoke2NvbmZpZy5jb250YWN0LmVtZXJnZW5jeVBob25lfWB9IGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgaG92ZXI6dW5kZXJsaW5lXCI+XG4gICAgICAgICAgICAgICAgICB7Y29uZmlnLmNvbnRhY3QuZW1lcmdlbmN5UGhvbmV9XG4gICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBCb3R0b20gQmFyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTggZmxleCBmbGV4LWNvbCBzbTpmbGV4LXJvdyBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC00IHRleHQteHMgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgwqkge25ldyBEYXRlKCkuZ2V0RnVsbFllYXIoKX0ge2NvbmZpZy5uYW1lfS4gQWxsIHJpZ2h0cyByZXNlcnZlZC4gUHJlY2lzaW9uIERlbnRpc3RyeSBTdHVkaW8uXG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwXCI+XG4gICAgICAgICAgICAgIDxTaGllbGRDaGVjayBjbGFzc05hbWU9XCJ3LTQgaC00IHRleHQtc2t5LTYwMFwiIC8+IElTTyA5MDAxIENlcnRpZmllZFxuICAgICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e3Njcm9sbFRvVG9wfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTIgcm91bmRlZC14bCBiZy13aGl0ZSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCB0ZXh0LXNsYXRlLTcwMCBob3Zlcjp0ZXh0LXNreS02MDAgaG92ZXI6Ym9yZGVyLXNreS00MDAgdHJhbnNpdGlvbiBzaGFkb3ctc21cIlxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiQmFjayB0byBUb3BcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8QXJyb3dVcCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgPC9kaXY+XG4gICAgPC9mb290ZXI+XG4gICk7XG59O1xuIl19