import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/DoctorsSection.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=383ccf5c";
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=d79d3615";
import { Award, Star, Calendar, CheckCircle2, Clock, ShieldCheck } from "/node_modules/.vite/deps/lucide-react.js?v=a18529f7";
import { useTheme } from "/src/context/ThemeContext.tsx";
var _jsxFileName = "D:/Aravind-Works/Dentel clinic/src/components/DoctorsSection.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=383ccf5c";
var _s = $RefreshSig$();
export const DoctorsSection = ({ onOpenBooking }) => {
	_s();
	const { config } = useTheme();
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "doctors",
		className: "py-20 bg-slate-100/70 dark:bg-slate-900/50 relative",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "text-center max-w-3xl mx-auto space-y-3",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-100 dark:bg-sky-950/80 text-sky-800 dark:text-sky-300 text-xs font-bold uppercase tracking-wider",
						children: [/* @__PURE__ */ _jsxDEV(Award, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 21,
							columnNumber: 13
						}, this), "Specialist Clinical Team"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 20,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight",
						children: ["Meet Our Senior ", /* @__PURE__ */ _jsxDEV("span", {
							className: "text-gradient",
							children: "Dental Specialists"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 25,
							columnNumber: 29
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-slate-600 dark:text-slate-300 text-sm sm:text-base",
						children: "Internationally trained implantologists, orthodontists, and laser specialists with over 38+ combined years of clinical expertise."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "mt-12 grid grid-cols-1 md:grid-cols-3 gap-8",
				children: config.doctors.map((doctor) => /* @__PURE__ */ _jsxDEV(motion.div, {
					initial: {
						opacity: 0,
						y: 20
					},
					whileInView: {
						opacity: 1,
						y: 0
					},
					viewport: { once: true },
					transition: { duration: .4 },
					className: "glass-card rounded-3xl overflow-hidden border border-slate-200/90 dark:border-slate-800 flex flex-col justify-between group",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "relative h-64 overflow-hidden bg-slate-200 dark:bg-slate-800",
						children: [
							/* @__PURE__ */ _jsxDEV("img", {
								src: doctor.image,
								alt: doctor.name,
								className: "w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 46,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { className: "absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 51,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "absolute bottom-3 left-3 bg-slate-900/90 text-white text-xs px-2.5 py-1 rounded-full border border-slate-700 flex items-center gap-1 font-bold",
								children: [
									/* @__PURE__ */ _jsxDEV(Star, { className: "w-3.5 h-3.5 text-amber-400 fill-amber-400" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 55,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("span", { children: doctor.rating }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 56,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400 font-normal",
										children: [
											"(",
											doctor.reviewsCount,
											" reviews)"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 57,
										columnNumber: 21
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "absolute top-3 right-3 bg-teal-500 text-slate-950 text-[10px] font-extrabold uppercase px-2.5 py-1 rounded-full shadow-md",
								children: [doctor.experienceYears, "+ Yrs Exp."]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 61,
								columnNumber: 19
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "p-6 space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xl font-bold text-slate-900 dark:text-white",
									children: doctor.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 69,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs font-semibold text-sky-600 dark:text-sky-400 mt-0.5",
									children: doctor.role
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 72,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-500 dark:text-slate-400 font-medium mt-1",
									children: doctor.qualification
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 75,
									columnNumber: 21
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 68,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-600 dark:text-slate-300 leading-relaxed",
								children: doctor.bio
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 80,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-1.5 pt-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] font-bold uppercase tracking-wider text-slate-400",
									children: "Key Expertise:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 86,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "flex flex-wrap gap-1.5",
									children: doctor.specialties.map((spec, idx) => /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2 py-0.5 rounded-md border border-slate-200 dark:border-slate-700",
										children: spec
									}, idx, false, {
										fileName: _jsxFileName,
										lineNumber: 89,
										columnNumber: 25
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 87,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 85,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5 pt-2 border-t border-slate-100 dark:border-slate-800",
								children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-3.5 h-3.5 text-emerald-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 98,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["Slots: ", /* @__PURE__ */ _jsxDEV("strong", {
									className: "text-slate-800 dark:text-slate-200",
									children: doctor.availableDays
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 99,
									columnNumber: 34
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 99,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 97,
								columnNumber: 19
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 17
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 43,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "p-6 pt-0",
						children: /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => onOpenBooking(undefined, doctor.id),
							className: "w-full py-3 px-4 rounded-xl font-bold text-xs text-white bg-slate-900 hover:bg-sky-600 dark:bg-sky-500 dark:hover:bg-sky-600 transition shadow-md flex items-center justify-center gap-2 cursor-pointer",
							children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 110,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["Consult With ", doctor.name.split(" ")[1]] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 111,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 106,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 15
					}, this)]
				}, doctor.id, true, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 13
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 16,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 5
	}, this);
};
_s(DoctorsSection, "qQ7g6tIEyataPS75zVi2PFhrMqc=", false, function() {
	return [useTheme];
});
_c = DoctorsSection;
var _c;
$RefreshReg$(_c, "DoctorsSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/DoctorsSection.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Aravind-Works/Dentel clinic/src/components/DoctorsSection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Aravind-Works/Dentel clinic/src/components/DoctorsSection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Aravind-Works/Dentel clinic/src/components/DoctorsSection.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsY0FBYztBQUN2QixTQUFTLE9BQU8sTUFBTSxVQUFVLGNBQWMsT0FBTyxtQkFBbUI7QUFDeEUsU0FBUyxnQkFBZ0I7Ozs7QUFPekIsT0FBTyxNQUFNLGtCQUFpRCxFQUFFLG9CQUFvQjs7Q0FDbEYsTUFBTSxFQUFFLFdBQVcsU0FBUztDQUU1QixPQUNFLHdCQUFDLFdBQUQ7RUFBUyxJQUFHO0VBQVUsV0FBVTtZQUM5Qix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBR0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsY0FBZTs7OztnQkFBQywwQkFFOUI7Ozs7OztLQUNMLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFkLENBQWtHLG9CQUNoRix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBZ0I7TUFBd0I7Ozs7Y0FDdEU7Ozs7OztLQUNKLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUEwRDtLQUVwRTs7Ozs7SUFDQTs7Ozs7YUFHTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNaLE9BQU8sUUFBUSxLQUFLLFdBQ25CLHdCQUFDLE9BQU8sS0FBUjtLQUVFLFNBQVM7TUFBRSxTQUFTO01BQUcsR0FBRztLQUFHO0tBQzdCLGFBQWE7TUFBRSxTQUFTO01BQUcsR0FBRztLQUFFO0tBQ2hDLFVBQVUsRUFBRSxNQUFNLEtBQUs7S0FDdkIsWUFBWSxFQUFFLFVBQVUsR0FBSTtLQUM1QixXQUFVO2VBTlosQ0FRRSx3QkFBQyxPQUFELGFBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxPQUFEO1FBQ0UsS0FBSyxPQUFPO1FBQ1osS0FBSyxPQUFPO1FBQ1osV0FBVTtPQUNYOzs7OztPQUNELHdCQUFDLE9BQUQsRUFBSyxXQUFVLHFGQUFzRjs7Ozs7T0FHckcsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSw0Q0FBNkM7Ozs7O1NBQzdELHdCQUFDLFFBQUQsWUFBTyxPQUFPLE9BQWE7Ozs7O1NBQzNCLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQjtXQUE2QztXQUFFLE9BQU87V0FBYTtVQUFlOzs7Ozs7UUFDL0U7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0csT0FBTyxpQkFBZ0IsWUFDckI7Ozs7OztNQUNGOzs7OztlQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRDtRQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNYLE9BQU87UUFDTjs7Ozs7UUFDSix3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFDVixPQUFPO1FBQ1A7Ozs7O1FBQ0gsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQ1YsT0FBTztRQUNQOzs7OztPQUNBOzs7OztPQUVMLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUNWLE9BQU87T0FDUDs7Ozs7T0FHSCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFnRTtRQUFvQjs7OztrQkFDcEcsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ1osT0FBTyxZQUFZLEtBQUssTUFBTSxRQUM3Qix3QkFBQyxRQUFEO1VBQWdCLFdBQVU7b0JBQ3ZCO1NBQ0csR0FGSzs7OztnQkFFTCxDQUNQO1FBQ0U7Ozs7Z0JBQ0Y7Ozs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFPLFdBQVUsK0JBQWdDOzs7O2tCQUNqRCx3QkFBQyxRQUFELGFBQU0sV0FBTyx3QkFBQyxVQUFEO1NBQVEsV0FBVTttQkFBc0MsT0FBTztRQUFzQjs7OztnQkFBTzs7OztnQkFDdEc7Ozs7OztNQUNGOzs7OzthQUNGOzs7O2VBR0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ2Isd0JBQUMsVUFBRDtPQUNFLGVBQWUsY0FBYyxXQUFXLE9BQU8sRUFBRTtPQUNqRCxXQUFVO2lCQUZaLENBSUUsd0JBQUMsVUFBRCxFQUFVLFdBQVUsY0FBZTs7OztpQkFDbkMsd0JBQUMsUUFBRCxhQUFNLGlCQUFjLE9BQU8sS0FBSyxNQUFNLEdBQUcsQ0FBQyxDQUFDLEVBQVM7Ozs7ZUFDOUM7Ozs7OztLQUNMOzs7O2FBQ0s7T0E5RUwsT0FBTzs7OztXQThFRixDQUNiO0dBQ0U7Ozs7V0FFRjs7Ozs7O0NBQ0U7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRG9jdG9yc1NlY3Rpb24udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBtb3Rpb24gfSBmcm9tICdmcmFtZXItbW90aW9uJztcbmltcG9ydCB7IEF3YXJkLCBTdGFyLCBDYWxlbmRhciwgQ2hlY2tDaXJjbGUyLCBDbG9jaywgU2hpZWxkQ2hlY2sgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICdAL2NvbnRleHQvVGhlbWVDb250ZXh0JztcbmltcG9ydCB0eXBlIHsgRG9jdG9yIH0gZnJvbSAnQC9jb25maWcvc2l0ZUNvbmZpZyc7XG5cbmludGVyZmFjZSBEb2N0b3JzU2VjdGlvblByb3BzIHtcbiAgb25PcGVuQm9va2luZzogKHNlcnZpY2VJZD86IHN0cmluZywgZG9jdG9ySWQ/OiBzdHJpbmcpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBEb2N0b3JzU2VjdGlvbjogUmVhY3QuRkM8RG9jdG9yc1NlY3Rpb25Qcm9wcz4gPSAoeyBvbk9wZW5Cb29raW5nIH0pID0+IHtcbiAgY29uc3QgeyBjb25maWcgfSA9IHVzZVRoZW1lKCk7XG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBpZD1cImRvY3RvcnNcIiBjbGFzc05hbWU9XCJweS0yMCBiZy1zbGF0ZS0xMDAvNzAgZGFyazpiZy1zbGF0ZS05MDAvNTAgcmVsYXRpdmVcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctN3hsIG14LWF1dG8gcHgtNCBzbTpweC02IGxnOnB4LThcIj5cbiAgICAgICAgXG4gICAgICAgIHsvKiBTZWN0aW9uIEhlYWRlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBtYXgtdy0zeGwgbXgtYXV0byBzcGFjZS15LTNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC0zIHB5LTEgcm91bmRlZC1mdWxsIGJnLXNreS0xMDAgZGFyazpiZy1za3ktOTUwLzgwIHRleHQtc2t5LTgwMCBkYXJrOnRleHQtc2t5LTMwMCB0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgIDxBd2FyZCBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICBTcGVjaWFsaXN0IENsaW5pY2FsIFRlYW1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0zeGwgc206dGV4dC00eGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICBNZWV0IE91ciBTZW5pb3IgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmFkaWVudFwiPkRlbnRhbCBTcGVjaWFsaXN0czwvc3Bhbj5cbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgdGV4dC1zbSBzbTp0ZXh0LWJhc2VcIj5cbiAgICAgICAgICAgIEludGVybmF0aW9uYWxseSB0cmFpbmVkIGltcGxhbnRvbG9naXN0cywgb3J0aG9kb250aXN0cywgYW5kIGxhc2VyIHNwZWNpYWxpc3RzIHdpdGggb3ZlciAzOCsgY29tYmluZWQgeWVhcnMgb2YgY2xpbmljYWwgZXhwZXJ0aXNlLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIERvY3RvcnMgR3JpZCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xMiBncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0zIGdhcC04XCI+XG4gICAgICAgICAge2NvbmZpZy5kb2N0b3JzLm1hcCgoZG9jdG9yKSA9PiAoXG4gICAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICBrZXk9e2RvY3Rvci5pZH1cbiAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCB5OiAyMCB9fVxuICAgICAgICAgICAgICB3aGlsZUluVmlldz17eyBvcGFjaXR5OiAxLCB5OiAwIH19XG4gICAgICAgICAgICAgIHZpZXdwb3J0PXt7IG9uY2U6IHRydWUgfX1cbiAgICAgICAgICAgICAgdHJhbnNpdGlvbj17eyBkdXJhdGlvbjogMC40IH19XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImdsYXNzLWNhcmQgcm91bmRlZC0zeGwgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciBib3JkZXItc2xhdGUtMjAwLzkwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBncm91cFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgey8qIERvY3RvciBIZWFkc2hvdCBDb250YWluZXIgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBoLTY0IG92ZXJmbG93LWhpZGRlbiBiZy1zbGF0ZS0yMDAgZGFyazpiZy1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgc3JjPXtkb2N0b3IuaW1hZ2V9XG4gICAgICAgICAgICAgICAgICAgIGFsdD17ZG9jdG9yLm5hbWV9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyIG9iamVjdC1jZW50ZXIgZ3JvdXAtaG92ZXI6c2NhbGUtMTA1IHRyYW5zaXRpb24tdHJhbnNmb3JtIGR1cmF0aW9uLTUwMFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBpbnNldC0wIGJnLWdyYWRpZW50LXRvLXQgZnJvbS1zbGF0ZS05NTAvODAgdmlhLXRyYW5zcGFyZW50IHRvLXRyYW5zcGFyZW50XCIgLz5cblxuICAgICAgICAgICAgICAgICAgey8qIFJhdGluZyBCYWRnZSBPdmVybGF5ICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMyBsZWZ0LTMgYmctc2xhdGUtOTAwLzkwIHRleHQtd2hpdGUgdGV4dC14cyBweC0yLjUgcHktMSByb3VuZGVkLWZ1bGwgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgIDxTdGFyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtYW1iZXItNDAwIGZpbGwtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2RvY3Rvci5yYXRpbmd9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBmb250LW5vcm1hbFwiPih7ZG9jdG9yLnJldmlld3NDb3VudH0gcmV2aWV3cyk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIEV4cGVyaWVuY2UgQmFkZ2UgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0zIHJpZ2h0LTMgYmctdGVhbC01MDAgdGV4dC1zbGF0ZS05NTAgdGV4dC1bMTBweF0gZm9udC1leHRyYWJvbGQgdXBwZXJjYXNlIHB4LTIuNSBweS0xIHJvdW5kZWQtZnVsbCBzaGFkb3ctbWRcIj5cbiAgICAgICAgICAgICAgICAgICAge2RvY3Rvci5leHBlcmllbmNlWWVhcnN9KyBZcnMgRXhwLlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogQm9keSBEZXRhaWxzICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtkb2N0b3IubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2t5LTYwMCBkYXJrOnRleHQtc2t5LTQwMCBtdC0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7ZG9jdG9yLnJvbGV9XG4gICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBmb250LW1lZGl1bSBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2RvY3Rvci5xdWFsaWZpY2F0aW9ufVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgICB7ZG9jdG9yLmJpb31cbiAgICAgICAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgICAgICAgey8qIFNwZWNpYWx0aWVzIFBpbGxzICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNSBwdC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDBcIj5LZXkgRXhwZXJ0aXNlOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAge2RvY3Rvci5zcGVjaWFsdGllcy5tYXAoKHNwZWMsIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4ga2V5PXtpZHh9IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtc2VtaWJvbGQgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNzAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgcHgtMiBweS0wLjUgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge3NwZWN9XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIHsvKiBBdmFpbGFiaWxpdHkgKi99XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSBwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWVtZXJhbGQtNTAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2xvdHM6IDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS04MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPntkb2N0b3IuYXZhaWxhYmxlRGF5c308L3N0cm9uZz48L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgey8qIEFjdGlvbiBCdXR0b24gKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC02IHB0LTBcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk9wZW5Cb29raW5nKHVuZGVmaW5lZCwgZG9jdG9yLmlkKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0zIHB4LTQgcm91bmRlZC14bCBmb250LWJvbGQgdGV4dC14cyB0ZXh0LXdoaXRlIGJnLXNsYXRlLTkwMCBob3ZlcjpiZy1za3ktNjAwIGRhcms6Ymctc2t5LTUwMCBkYXJrOmhvdmVyOmJnLXNreS02MDAgdHJhbnNpdGlvbiBzaGFkb3ctbWQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxDYWxlbmRhciBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5Db25zdWx0IFdpdGgge2RvY3Rvci5uYW1lLnNwbGl0KCcgJylbMV19PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn07XG4iXX0=