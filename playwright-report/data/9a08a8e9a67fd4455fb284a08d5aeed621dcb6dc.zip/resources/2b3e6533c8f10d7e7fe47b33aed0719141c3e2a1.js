import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PainlessTechSection.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=383ccf5c";
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=d79d3615";
import { Cpu, Sparkles, ShieldCheck, Zap, Activity, Award } from "/node_modules/.vite/deps/lucide-react.js?v=a18529f7";
import { useTheme } from "/src/context/ThemeContext.tsx";
var _jsxFileName = "D:/Aravind-Works/Dentel clinic/src/components/PainlessTechSection.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=383ccf5c";
var _s = $RefreshSig$();
export const PainlessTechSection = () => {
	_s();
	const { config } = useTheme();
	const techStack = [
		{
			title: "3D Intraoral Digital Scanner",
			desc: "Replaces uncomfortable impression paste trays with a 3D laser wand scanning your teeth in 60 seconds with sub-millimeter precision.",
			icon: Cpu,
			tag: "Zero Gagging",
			color: "text-sky-500",
			bgColor: "bg-sky-500/10"
		},
		{
			title: "Painless Wand Local Anesthesia",
			desc: "Computerized micro-dosing system delivers anesthesia comfortably without traditional needle pressure or lingering facial numbness.",
			icon: Zap,
			tag: "Needle-Free Feel",
			color: "text-teal-500",
			bgColor: "bg-teal-500/10"
		},
		{
			title: "German Cold Dental Laser",
			desc: "Used for precise gum sculpting, instant teeth whitening, and sterilizing root canals without drills or scalpel incisions.",
			icon: Sparkles,
			tag: "Rapid Healing",
			color: "text-amber-500",
			bgColor: "bg-amber-500/10"
		},
		{
			title: "Class-B 7-Step Sterilization",
			desc: "Hospital-grade vacuum autoclaves ensure 100% sterile instruments. Each set is individually sealed and opened in front of you.",
			icon: ShieldCheck,
			tag: "WHO & CDC Standard",
			color: "text-emerald-500",
			bgColor: "bg-emerald-500/10"
		}
	];
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "technology",
		className: "py-20 relative",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "text-center max-w-3xl mx-auto space-y-3",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-300 text-xs font-bold uppercase tracking-wider",
						children: [/* @__PURE__ */ _jsxDEV(Activity, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 13
						}, this), "Next-Gen Painless Dentistry"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight",
						children: ["Advanced Clinical ", /* @__PURE__ */ _jsxDEV("span", {
							className: "text-gradient",
							children: "Technology & Hygiene"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 55,
							columnNumber: 31
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-slate-600 dark:text-slate-300 text-sm sm:text-base",
						children: "We invest in state-of-the-art dental innovations to eliminate fear, ensure zero pain, and deliver exceptional results."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "mt-12 grid grid-cols-1 md:grid-cols-2 gap-6",
				children: techStack.map((item, idx) => {
					const Icon = item.icon;
					return /* @__PURE__ */ _jsxDEV(motion.div, {
						initial: {
							opacity: 0,
							y: 15
						},
						whileInView: {
							opacity: 1,
							y: 0
						},
						viewport: { once: true },
						transition: {
							duration: .4,
							delay: idx * .1
						},
						className: "glass-card rounded-2xl p-6 sm:p-8 flex items-start gap-5 border border-slate-200/90 dark:border-slate-800 relative group",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: `w-14 h-14 rounded-2xl ${item.bgColor} flex items-center justify-center flex-shrink-0 ${item.color} group-hover:scale-110 transition-transform`,
							children: /* @__PURE__ */ _jsxDEV(Icon, { className: "w-7 h-7" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 76,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 75,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-lg font-bold text-slate-900 dark:text-white",
									children: item.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 81,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] font-extrabold uppercase tracking-wider bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 px-2.5 py-1 rounded-full",
									children: item.tag
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 84,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 80,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed",
								children: item.desc
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 17
						}, this)]
					}, idx, true, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 15
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 63,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 46,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 45,
		columnNumber: 5
	}, this);
};
_s(PainlessTechSection, "qQ7g6tIEyataPS75zVi2PFhrMqc=", false, function() {
	return [useTheme];
});
_c = PainlessTechSection;
var _c;
$RefreshReg$(_c, "PainlessTechSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/PainlessTechSection.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Aravind-Works/Dentel clinic/src/components/PainlessTechSection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Aravind-Works/Dentel clinic/src/components/PainlessTechSection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Aravind-Works/Dentel clinic/src/components/PainlessTechSection.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsY0FBYztBQUN2QixTQUFTLEtBQUssVUFBVSxhQUFhLEtBQUssVUFBVSxhQUFhO0FBQ2pFLFNBQVMsZ0JBQWdCOzs7O0FBRXpCLE9BQU8sTUFBTSw0QkFBc0M7O0NBQ2pELE1BQU0sRUFBRSxXQUFXLFNBQVM7Q0FFNUIsTUFBTSxZQUFZO0VBQ2hCO0dBQ0UsT0FBTztHQUNQLE1BQU07R0FDTixNQUFNO0dBQ04sS0FBSztHQUNMLE9BQU87R0FDUCxTQUFTO0VBQ1g7RUFDQTtHQUNFLE9BQU87R0FDUCxNQUFNO0dBQ04sTUFBTTtHQUNOLEtBQUs7R0FDTCxPQUFPO0dBQ1AsU0FBUztFQUNYO0VBQ0E7R0FDRSxPQUFPO0dBQ1AsTUFBTTtHQUNOLE1BQU07R0FDTixLQUFLO0dBQ0wsT0FBTztHQUNQLFNBQVM7RUFDWDtFQUNBO0dBQ0UsT0FBTztHQUNQLE1BQU07R0FDTixNQUFNO0dBQ04sS0FBSztHQUNMLE9BQU87R0FDUCxTQUFTO0VBQ1g7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLElBQUc7RUFBYSxXQUFVO1lBQ2pDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FHRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7O2dCQUFDLDZCQUVqQzs7Ozs7O0tBQ0wsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWQsQ0FBa0csc0JBQzlFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFnQjtNQUEwQjs7OztjQUMxRTs7Ozs7O0tBQ0osd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQTBEO0tBRXBFOzs7OztJQUNBOzs7OzthQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osVUFBVSxLQUFLLE1BQU0sUUFBUTtLQUM1QixNQUFNLE9BQU8sS0FBSztLQUNsQixPQUNFLHdCQUFDLE9BQU8sS0FBUjtNQUVFLFNBQVM7T0FBRSxTQUFTO09BQUcsR0FBRztNQUFHO01BQzdCLGFBQWE7T0FBRSxTQUFTO09BQUcsR0FBRztNQUFFO01BQ2hDLFVBQVUsRUFBRSxNQUFNLEtBQUs7TUFDdkIsWUFBWTtPQUFFLFVBQVU7T0FBSyxPQUFPLE1BQU07TUFBSTtNQUM5QyxXQUFVO2dCQU5aLENBUUUsd0JBQUMsT0FBRDtPQUFLLFdBQVcseUJBQXlCLEtBQUssUUFBUSxrREFBa0QsS0FBSyxNQUFNO2lCQUNqSCx3QkFBQyxNQUFELEVBQU0sV0FBVSxVQUFXOzs7OztNQUN4Qjs7OztnQkFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQ1gsS0FBSztRQUNKOzs7O2tCQUNKLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNiLEtBQUs7UUFDRjs7OztnQkFDSDs7Ozs7aUJBRUwsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQ1YsS0FBSztPQUNMOzs7O2VBQ0E7Ozs7O2NBQ0s7UUF6Qkw7Ozs7WUF5Qks7SUFFaEIsQ0FBQztHQUNFOzs7O1dBRUY7Ozs7OztDQUNFOzs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlBhaW5sZXNzVGVjaFNlY3Rpb24udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBtb3Rpb24gfSBmcm9tICdmcmFtZXItbW90aW9uJztcbmltcG9ydCB7IENwdSwgU3BhcmtsZXMsIFNoaWVsZENoZWNrLCBaYXAsIEFjdGl2aXR5LCBBd2FyZCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJ0AvY29udGV4dC9UaGVtZUNvbnRleHQnO1xuXG5leHBvcnQgY29uc3QgUGFpbmxlc3NUZWNoU2VjdGlvbjogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIGNvbnN0IHsgY29uZmlnIH0gPSB1c2VUaGVtZSgpO1xuXG4gIGNvbnN0IHRlY2hTdGFjayA9IFtcbiAgICB7XG4gICAgICB0aXRsZTogXCIzRCBJbnRyYW9yYWwgRGlnaXRhbCBTY2FubmVyXCIsXG4gICAgICBkZXNjOiBcIlJlcGxhY2VzIHVuY29tZm9ydGFibGUgaW1wcmVzc2lvbiBwYXN0ZSB0cmF5cyB3aXRoIGEgM0QgbGFzZXIgd2FuZCBzY2FubmluZyB5b3VyIHRlZXRoIGluIDYwIHNlY29uZHMgd2l0aCBzdWItbWlsbGltZXRlciBwcmVjaXNpb24uXCIsXG4gICAgICBpY29uOiBDcHUsXG4gICAgICB0YWc6IFwiWmVybyBHYWdnaW5nXCIsXG4gICAgICBjb2xvcjogXCJ0ZXh0LXNreS01MDBcIixcbiAgICAgIGJnQ29sb3I6IFwiYmctc2t5LTUwMC8xMFwiXG4gICAgfSxcbiAgICB7XG4gICAgICB0aXRsZTogXCJQYWlubGVzcyBXYW5kIExvY2FsIEFuZXN0aGVzaWFcIixcbiAgICAgIGRlc2M6IFwiQ29tcHV0ZXJpemVkIG1pY3JvLWRvc2luZyBzeXN0ZW0gZGVsaXZlcnMgYW5lc3RoZXNpYSBjb21mb3J0YWJseSB3aXRob3V0IHRyYWRpdGlvbmFsIG5lZWRsZSBwcmVzc3VyZSBvciBsaW5nZXJpbmcgZmFjaWFsIG51bWJuZXNzLlwiLFxuICAgICAgaWNvbjogWmFwLFxuICAgICAgdGFnOiBcIk5lZWRsZS1GcmVlIEZlZWxcIixcbiAgICAgIGNvbG9yOiBcInRleHQtdGVhbC01MDBcIixcbiAgICAgIGJnQ29sb3I6IFwiYmctdGVhbC01MDAvMTBcIlxuICAgIH0sXG4gICAge1xuICAgICAgdGl0bGU6IFwiR2VybWFuIENvbGQgRGVudGFsIExhc2VyXCIsXG4gICAgICBkZXNjOiBcIlVzZWQgZm9yIHByZWNpc2UgZ3VtIHNjdWxwdGluZywgaW5zdGFudCB0ZWV0aCB3aGl0ZW5pbmcsIGFuZCBzdGVyaWxpemluZyByb290IGNhbmFscyB3aXRob3V0IGRyaWxscyBvciBzY2FscGVsIGluY2lzaW9ucy5cIixcbiAgICAgIGljb246IFNwYXJrbGVzLFxuICAgICAgdGFnOiBcIlJhcGlkIEhlYWxpbmdcIixcbiAgICAgIGNvbG9yOiBcInRleHQtYW1iZXItNTAwXCIsXG4gICAgICBiZ0NvbG9yOiBcImJnLWFtYmVyLTUwMC8xMFwiXG4gICAgfSxcbiAgICB7XG4gICAgICB0aXRsZTogXCJDbGFzcy1CIDctU3RlcCBTdGVyaWxpemF0aW9uXCIsXG4gICAgICBkZXNjOiBcIkhvc3BpdGFsLWdyYWRlIHZhY3V1bSBhdXRvY2xhdmVzIGVuc3VyZSAxMDAlIHN0ZXJpbGUgaW5zdHJ1bWVudHMuIEVhY2ggc2V0IGlzIGluZGl2aWR1YWxseSBzZWFsZWQgYW5kIG9wZW5lZCBpbiBmcm9udCBvZiB5b3UuXCIsXG4gICAgICBpY29uOiBTaGllbGRDaGVjayxcbiAgICAgIHRhZzogXCJXSE8gJiBDREMgU3RhbmRhcmRcIixcbiAgICAgIGNvbG9yOiBcInRleHQtZW1lcmFsZC01MDBcIixcbiAgICAgIGJnQ29sb3I6IFwiYmctZW1lcmFsZC01MDAvMTBcIlxuICAgIH1cbiAgXTtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGlkPVwidGVjaG5vbG9neVwiIGNsYXNzTmFtZT1cInB5LTIwIHJlbGF0aXZlXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTd4bCBteC1hdXRvIHB4LTQgc206cHgtNiBsZzpweC04XCI+XG4gICAgICAgIFxuICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIG1heC13LTN4bCBteC1hdXRvIHNwYWNlLXktM1wiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTMgcHktMSByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC0xMDAgZGFyazpiZy1lbWVyYWxkLTk1MC84MCB0ZXh0LWVtZXJhbGQtODAwIGRhcms6dGV4dC1lbWVyYWxkLTMwMCB0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgIDxBY3Rpdml0eSBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNVwiIC8+XG4gICAgICAgICAgICBOZXh0LUdlbiBQYWlubGVzcyBEZW50aXN0cnlcbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0zeGwgc206dGV4dC00eGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICBBZHZhbmNlZCBDbGluaWNhbCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWdyYWRpZW50XCI+VGVjaG5vbG9neSAmIEh5Z2llbmU8L3NwYW4+XG4gICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHRleHQtc20gc206dGV4dC1iYXNlXCI+XG4gICAgICAgICAgICBXZSBpbnZlc3QgaW4gc3RhdGUtb2YtdGhlLWFydCBkZW50YWwgaW5ub3ZhdGlvbnMgdG8gZWxpbWluYXRlIGZlYXIsIGVuc3VyZSB6ZXJvIHBhaW4sIGFuZCBkZWxpdmVyIGV4Y2VwdGlvbmFsIHJlc3VsdHMuXG4gICAgICAgICAgPC9wPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogVGVjaCBHcmlkICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEyIGdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgZ2FwLTZcIj5cbiAgICAgICAgICB7dGVjaFN0YWNrLm1hcCgoaXRlbSwgaWR4KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBJY29uID0gaXRlbS5pY29uO1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgICAgICBrZXk9e2lkeH1cbiAgICAgICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHk6IDE1IH19XG4gICAgICAgICAgICAgICAgd2hpbGVJblZpZXc9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxuICAgICAgICAgICAgICAgIHZpZXdwb3J0PXt7IG9uY2U6IHRydWUgfX1cbiAgICAgICAgICAgICAgICB0cmFuc2l0aW9uPXt7IGR1cmF0aW9uOiAwLjQsIGRlbGF5OiBpZHggKiAwLjEgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnbGFzcy1jYXJkIHJvdW5kZWQtMnhsIHAtNiBzbTpwLTggZmxleCBpdGVtcy1zdGFydCBnYXAtNSBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC85MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgcmVsYXRpdmUgZ3JvdXBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2B3LTE0IGgtMTQgcm91bmRlZC0yeGwgJHtpdGVtLmJnQ29sb3J9IGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGZsZXgtc2hyaW5rLTAgJHtpdGVtLmNvbG9yfSBncm91cC1ob3ZlcjpzY2FsZS0xMTAgdHJhbnNpdGlvbi10cmFuc2Zvcm1gfT5cbiAgICAgICAgICAgICAgICAgIDxJY29uIGNsYXNzTmFtZT1cInctNyBoLTdcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1leHRyYWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHB4LTIuNSBweS0xIHJvdW5kZWQtZnVsbFwiPlxuICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnRhZ31cbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgc206dGV4dC1zbSB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAgICB7aXRlbS5kZXNjfVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgPC9kaXY+XG4gICAgPC9zZWN0aW9uPlxuICApO1xufTtcbiJdfQ==