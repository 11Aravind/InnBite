import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Navbar.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=383ccf5c";
import { motion, AnimatePresence } from "/node_modules/.vite/deps/framer-motion.js?v=d79d3615";
import { Phone, MessageCircle, Calendar, Menu, X, Sparkles, MapPin, Clock, ShieldCheck } from "/node_modules/.vite/deps/lucide-react.js?v=a18529f7";
import { useTheme } from "/src/context/ThemeContext.tsx";
import { DynamicIcon } from "/src/components/DynamicIcon.tsx";
var _jsxFileName = "D:/Aravind-Works/Dentel clinic/src/components/Navbar.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=383ccf5c";
var _s = $RefreshSig$();
export const Navbar = ({ onOpenBooking }) => {
	_s();
	const { config } = useTheme();
	const [isScrolled, setIsScrolled] = useState(false);
	const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
	useEffect(() => {
		const handleScroll = () => {
			setIsScrolled(window.scrollY > 20);
		};
		window.addEventListener("scroll", handleScroll);
		return () => window.removeEventListener("scroll", handleScroll);
	}, []);
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("div", {
			className: "bg-gradient-to-r from-sky-600 via-sky-500 to-teal-600 text-white text-xs py-2.5 px-4 shadow-sm",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-2",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-4 text-xs font-semibold",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "inline-flex items-center gap-1.5 bg-white/20 backdrop-blur-md px-3 py-1 rounded-full border border-white/30 text-white shadow-sm",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-emerald-300 animate-ping" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 41,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-emerald-400 absolute" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 42,
								columnNumber: 15
							}, this),
							"Open Today: ",
							config.contact.workingHours.weekdays
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "hidden sm:inline-flex items-center gap-1 text-sky-100 font-medium",
						children: [
							/* @__PURE__ */ _jsxDEV(MapPin, { className: "w-3.5 h-3.5 text-sky-200" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 46,
								columnNumber: 15
							}, this),
							config.contact.city,
							" Studio Branch"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-4 text-xs font-bold",
					children: [/* @__PURE__ */ _jsxDEV("a", {
						href: `tel:${config.contact.emergencyPhone}`,
						className: "flex items-center gap-1.5 text-amber-200 hover:text-white transition",
						children: [
							/* @__PURE__ */ _jsxDEV(Phone, { className: "w-3.5 h-3.5 animate-bounce" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 56,
								columnNumber: 15
							}, this),
							"24/7 Emergency: ",
							/* @__PURE__ */ _jsxDEV("span", {
								className: "underline",
								children: config.contact.emergencyPhone
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 57,
								columnNumber: 31
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("a", {
						href: `https://wa.me/${config.contact.whatsapp.number}?text=${encodeURIComponent(config.contact.whatsapp.defaultMessage)}`,
						target: "_blank",
						rel: "noopener noreferrer",
						className: "hidden md:flex items-center gap-1.5 text-emerald-200 hover:text-white transition bg-white/10 px-2.5 py-0.5 rounded-full",
						children: [/* @__PURE__ */ _jsxDEV(MessageCircle, { className: "w-3.5 h-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 15
						}, this), "WhatsApp Consult"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 51,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 38,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("header", {
			className: `sticky top-0 z-40 transition-all duration-300 ${isScrolled ? "bg-white/95 backdrop-blur-lg shadow-md py-3 border-b border-sky-100" : "bg-white/90 backdrop-blur-md py-4 border-b border-slate-100"}`,
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between",
				children: [
					/* @__PURE__ */ _jsxDEV("a", {
						href: "#hero",
						className: "flex items-center gap-3 group",
						children: [/* @__PURE__ */ _jsxDEV(motion.div, {
							whileHover: {
								rotate: 15,
								scale: 1.08
							},
							className: "w-11 h-11 rounded-2xl bg-gradient-to-tr from-sky-500 via-sky-600 to-teal-500 flex items-center justify-center text-white shadow-lg shadow-sky-500/25",
							children: /* @__PURE__ */ _jsxDEV(DynamicIcon, {
								name: config.logo.icon,
								className: "w-6 h-6"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 87,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 83,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-2xl font-black tracking-tight text-slate-900 flex items-center gap-1 font-['Outfit']",
							children: config.logo.text
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "block text-[10px] font-extrabold tracking-wider uppercase text-sky-600 -mt-0.5",
							children: config.logo.subtext
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 89,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("nav", {
						className: "hidden xl:flex items-center gap-7",
						children: config.navigation.map((item) => /* @__PURE__ */ _jsxDEV("a", {
							href: item.href,
							className: "text-sm font-extrabold text-slate-700 hover:text-sky-600 transition-colors relative group",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: item.name }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 107,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { className: "absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-sky-500 to-teal-500 group-hover:w-full transition-all duration-300 rounded-full" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 108,
								columnNumber: 17
							}, this)]
						}, item.name, true, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "hidden lg:flex items-center gap-4",
						children: [/* @__PURE__ */ _jsxDEV("a", {
							href: `tel:${config.contact.phone}`,
							className: "px-4 py-2.5 rounded-xl text-xs font-bold text-slate-800 bg-sky-50 hover:bg-sky-100 border border-sky-200 transition flex items-center gap-2",
							children: [/* @__PURE__ */ _jsxDEV(Phone, { className: "w-4 h-4 text-sky-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: config.contact.phone }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 121,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 116,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV(motion.button, {
							whileHover: {
								scale: 1.04,
								y: -1
							},
							whileTap: { scale: .96 },
							onClick: () => onOpenBooking(),
							className: "px-6 py-3 rounded-xl text-sm font-extrabold text-white bg-gradient-to-r from-sky-600 via-teal-600 to-sky-700 hover:from-sky-700 hover:to-teal-700 shadow-lg shadow-sky-600/30 flex items-center gap-2 cursor-pointer",
							children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 131,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Book Appointment" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 132,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 114,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex xl:hidden items-center gap-2",
						children: /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setMobileMenuOpen(!mobileMenuOpen),
							className: "p-2.5 rounded-xl border border-sky-200 text-slate-800 bg-sky-50",
							"aria-label": "Toggle menu",
							children: mobileMenuOpen ? /* @__PURE__ */ _jsxDEV(X, { className: "w-6 h-6" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 33
							}, this) : /* @__PURE__ */ _jsxDEV(Menu, { className: "w-6 h-6" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 143,
								columnNumber: 61
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 138,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 74,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(AnimatePresence, { children: mobileMenuOpen && /* @__PURE__ */ _jsxDEV(motion.div, {
			initial: {
				opacity: 0,
				height: 0
			},
			animate: {
				opacity: 1,
				height: "auto"
			},
			exit: {
				opacity: 0,
				height: 0
			},
			className: "xl:hidden sticky top-[65px] z-30 bg-white border-b border-sky-100 shadow-2xl overflow-hidden",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "px-6 py-6 space-y-4",
				children: [/* @__PURE__ */ _jsxDEV("nav", {
					className: "flex flex-col space-y-3",
					children: config.navigation.map((item) => /* @__PURE__ */ _jsxDEV("a", {
						href: item.href,
						onClick: () => setMobileMenuOpen(false),
						className: "text-base font-extrabold text-slate-800 hover:text-sky-600 transition",
						children: item.name
					}, item.name, false, {
						fileName: _jsxFileName,
						lineNumber: 161,
						columnNumber: 19
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 159,
					columnNumber: 15
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "pt-4 border-t border-slate-100 flex flex-col gap-3",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => {
							setMobileMenuOpen(false);
							onOpenBooking();
						},
						className: "w-full py-3.5 rounded-xl text-center text-sm font-extrabold text-white bg-gradient-to-r from-sky-600 to-teal-600 shadow-md flex items-center justify-center gap-2",
						children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-4 h-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 19
						}, this), "Book Appointment Now"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 173,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("a", {
						href: `tel:${config.contact.phone}`,
						className: "w-full py-3 rounded-xl text-center text-sm font-bold text-slate-800 border border-slate-200 bg-slate-50 flex items-center justify-center gap-2",
						children: [
							/* @__PURE__ */ _jsxDEV(Phone, { className: "w-4 h-4 text-sky-600" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 188,
								columnNumber: 19
							}, this),
							"Call Studio: ",
							config.contact.phone
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 184,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 172,
					columnNumber: 15
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 158,
				columnNumber: 13
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 152,
			columnNumber: 11
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 150,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 35,
		columnNumber: 5
	}, this);
};
_s(Navbar, "5kDKVeftxWMaHYQX1PoVekRpvF0=", false, function() {
	return [useTheme];
});
_c = Navbar;
var _c;
$RefreshReg$(_c, "Navbar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Navbar.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Aravind-Works/Dentel clinic/src/components/Navbar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Aravind-Works/Dentel clinic/src/components/Navbar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Aravind-Works/Dentel clinic/src/components/Navbar.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsUUFBUSx1QkFBdUI7QUFDeEMsU0FDRSxPQUNBLGVBQ0EsVUFDQSxNQUNBLEdBQ0EsVUFDQSxRQUNBLE9BQ0EsbUJBQ0s7QUFDUCxTQUFTLGdCQUFnQjtBQUN6QixTQUFTLG1CQUFtQjs7OztBQU01QixPQUFPLE1BQU0sVUFBaUMsRUFBRSxvQkFBb0I7O0NBQ2xFLE1BQU0sRUFBRSxXQUFXLFNBQVM7Q0FDNUIsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsS0FBSztDQUNsRCxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFTLEtBQUs7Q0FFMUQsZ0JBQWdCO0VBQ2QsTUFBTSxxQkFBcUI7R0FDekIsY0FBYyxPQUFPLFVBQVUsRUFBRTtFQUNuQztFQUNBLE9BQU8saUJBQWlCLFVBQVUsWUFBWTtFQUM5QyxhQUFhLE9BQU8sb0JBQW9CLFVBQVUsWUFBWTtDQUNoRSxHQUFHLENBQUMsQ0FBQztDQUVMLE9BQ0U7RUFFRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNiLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCO09BQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsbURBQXlEOzs7OztPQUN6RSx3QkFBQyxRQUFELEVBQU0sV0FBVSwrQ0FBcUQ7Ozs7O09BQUM7T0FDekQsT0FBTyxRQUFRLGFBQWE7TUFDckM7Ozs7O2VBQ04sd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWhCO09BQ0Usd0JBQUMsUUFBRCxFQUFRLFdBQVUsMkJBQTRCOzs7OztPQUM3QyxPQUFPLFFBQVE7T0FBSztNQUNqQjs7Ozs7YUFDSDs7Ozs7Y0FFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsS0FBRDtNQUNFLE1BQU0sT0FBTyxPQUFPLFFBQVE7TUFDNUIsV0FBVTtnQkFGWjtPQUlFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLDZCQUE4Qjs7Ozs7T0FBQztPQUNoQyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBYSxPQUFPLFFBQVE7T0FBcUI7Ozs7O01BQ2hGOzs7OztlQUVILHdCQUFDLEtBQUQ7TUFDRSxNQUFNLGlCQUFpQixPQUFPLFFBQVEsU0FBUyxPQUFPLFFBQVEsbUJBQW1CLE9BQU8sUUFBUSxTQUFTLGNBQWM7TUFDdkgsUUFBTztNQUNQLEtBQUk7TUFDSixXQUFVO2dCQUpaLENBTUUsd0JBQUMsZUFBRCxFQUFlLFdBQVUsY0FBZTs7OztnQkFBQyxrQkFFeEM7Ozs7O2FBQ0E7Ozs7O1lBQ0Y7Ozs7OztFQUNGOzs7OztFQUdMLHdCQUFDLFVBQUQ7R0FBUSxXQUFXLGlEQUNqQixhQUNJLHdFQUNBO2FBRUosd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUdFLHdCQUFDLEtBQUQ7TUFBRyxNQUFLO01BQVEsV0FBVTtnQkFBMUIsQ0FDRSx3QkFBQyxPQUFPLEtBQVI7T0FDRSxZQUFZO1FBQUUsUUFBUTtRQUFJLE9BQU87T0FBSztPQUN0QyxXQUFVO2lCQUVWLHdCQUFDLGFBQUQ7UUFBYSxNQUFNLE9BQU8sS0FBSztRQUFNLFdBQVU7T0FBVzs7Ozs7TUFDaEQ7Ozs7Z0JBQ1osd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUNiLE9BQU8sS0FBSztNQUNUOzs7O2dCQUNOLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUNiLE9BQU8sS0FBSztNQUNUOzs7O2NBQ0g7Ozs7Y0FDSjs7Ozs7O0tBR0gsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1osT0FBTyxXQUFXLEtBQUssU0FDdEIsd0JBQUMsS0FBRDtPQUVFLE1BQU0sS0FBSztPQUNYLFdBQVU7aUJBSFosQ0FLRSx3QkFBQyxRQUFELFlBQU8sS0FBSyxLQUFXOzs7O2lCQUN2Qix3QkFBQyxRQUFELEVBQU0sV0FBVSwySUFBNEk7Ozs7ZUFDM0o7U0FOSSxLQUFLOzs7O2FBTVQsQ0FDSjtLQUNFOzs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBRUUsd0JBQUMsS0FBRDtPQUNFLE1BQU0sT0FBTyxPQUFPLFFBQVE7T0FDNUIsV0FBVTtpQkFGWixDQUlFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHVCQUF3Qjs7OztpQkFDekMsd0JBQUMsUUFBRCxZQUFPLE9BQU8sUUFBUSxNQUFZOzs7O2VBQ2pDOzs7OztnQkFHSCx3QkFBQyxPQUFPLFFBQVI7T0FDRSxZQUFZO1FBQUUsT0FBTztRQUFNLEdBQUcsQ0FBQztPQUFFO09BQ2pDLFVBQVUsRUFBRSxPQUFPLElBQUs7T0FDeEIsZUFBZSxjQUFjO09BQzdCLFdBQVU7aUJBSlosQ0FNRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7O2lCQUMvQix3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7O2VBQ2Y7Ozs7O2NBQ1o7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGtCQUFrQixDQUFDLGNBQWM7T0FDaEQsV0FBVTtPQUNWLGNBQVc7aUJBRVYsaUJBQWlCLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7a0JBQUksd0JBQUMsTUFBRCxFQUFNLFdBQVUsVUFBVzs7Ozs7TUFDbkU7Ozs7O0tBQ0w7Ozs7O0lBQ0Y7Ozs7OztFQUNDOzs7OztFQUdSLHdCQUFDLGlCQUFELFlBQ0csa0JBQ0Msd0JBQUMsT0FBTyxLQUFSO0dBQ0UsU0FBUztJQUFFLFNBQVM7SUFBRyxRQUFRO0dBQUU7R0FDakMsU0FBUztJQUFFLFNBQVM7SUFBRyxRQUFRO0dBQU87R0FDdEMsTUFBTTtJQUFFLFNBQVM7SUFBRyxRQUFRO0dBQUU7R0FDOUIsV0FBVTthQUVWLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLE9BQU8sV0FBVyxLQUFLLFNBQ3RCLHdCQUFDLEtBQUQ7TUFFRSxNQUFNLEtBQUs7TUFDWCxlQUFlLGtCQUFrQixLQUFLO01BQ3RDLFdBQVU7Z0JBRVQsS0FBSztLQUNMLEdBTkksS0FBSzs7OztZQU1ULENBQ0o7SUFDRTs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxVQUFEO01BQ0UsZUFBZTtPQUNiLGtCQUFrQixLQUFLO09BQ3ZCLGNBQWM7TUFDaEI7TUFDQSxXQUFVO2dCQUxaLENBT0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OztnQkFBQyxzQkFFMUI7Ozs7O2VBRVIsd0JBQUMsS0FBRDtNQUNFLE1BQU0sT0FBTyxPQUFPLFFBQVE7TUFDNUIsV0FBVTtnQkFGWjtPQUlFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHVCQUF3Qjs7Ozs7T0FBQztPQUM1QixPQUFPLFFBQVE7TUFDNUI7Ozs7O2FBQ0E7Ozs7O1lBQ0Y7Ozs7OztFQUNLOzs7O1dBRUM7Ozs7O0NBQ2pCOzs7OztBQUVOIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk5hdmJhci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBtb3Rpb24sIEFuaW1hdGVQcmVzZW5jZSB9IGZyb20gJ2ZyYW1lci1tb3Rpb24nO1xuaW1wb3J0IHsgXG4gIFBob25lLCBcbiAgTWVzc2FnZUNpcmNsZSwgXG4gIENhbGVuZGFyLCBcbiAgTWVudSwgXG4gIFgsIFxuICBTcGFya2xlcyxcbiAgTWFwUGluLFxuICBDbG9jayxcbiAgU2hpZWxkQ2hlY2tcbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnQC9jb250ZXh0L1RoZW1lQ29udGV4dCc7XG5pbXBvcnQgeyBEeW5hbWljSWNvbiB9IGZyb20gJ0AvY29tcG9uZW50cy9EeW5hbWljSWNvbic7XG5cbmludGVyZmFjZSBOYXZiYXJQcm9wcyB7XG4gIG9uT3BlbkJvb2tpbmc6IChzZXJ2aWNlSWQ/OiBzdHJpbmcpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBOYXZiYXI6IFJlYWN0LkZDPE5hdmJhclByb3BzPiA9ICh7IG9uT3BlbkJvb2tpbmcgfSkgPT4ge1xuICBjb25zdCB7IGNvbmZpZyB9ID0gdXNlVGhlbWUoKTtcbiAgY29uc3QgW2lzU2Nyb2xsZWQsIHNldElzU2Nyb2xsZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbbW9iaWxlTWVudU9wZW4sIHNldE1vYmlsZU1lbnVPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGhhbmRsZVNjcm9sbCA9ICgpID0+IHtcbiAgICAgIHNldElzU2Nyb2xsZWQod2luZG93LnNjcm9sbFkgPiAyMCk7XG4gICAgfTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgaGFuZGxlU2Nyb2xsKTtcbiAgICByZXR1cm4gKCkgPT4gd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsIGhhbmRsZVNjcm9sbCk7XG4gIH0sIFtdKTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICB7LyogVG9wIEFubm91bmNlbWVudCBCYXIgLSBWaWJyYW50IEJyaWdodCBNZWRpY2FsIFNreSBCbHVlIC8gQ3lhbiAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctZ3JhZGllbnQtdG8tciBmcm9tLXNreS02MDAgdmlhLXNreS01MDAgdG8tdGVhbC02MDAgdGV4dC13aGl0ZSB0ZXh0LXhzIHB5LTIuNSBweC00IHNoYWRvdy1zbVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTd4bCBteC1hdXRvIGZsZXggZmxleC13cmFwIGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC00IHRleHQteHMgZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaW5saW5lLWZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgYmctd2hpdGUvMjAgYmFja2Ryb3AtYmx1ci1tZCBweC0zIHB5LTEgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItd2hpdGUvMzAgdGV4dC13aGl0ZSBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC0zMDAgYW5pbWF0ZS1waW5nXCI+PC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ3LTIgaC0yIHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTQwMCBhYnNvbHV0ZVwiPjwvc3Bhbj5cbiAgICAgICAgICAgICAgT3BlbiBUb2RheToge2NvbmZpZy5jb250YWN0LndvcmtpbmdIb3Vycy53ZWVrZGF5c31cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBzbTppbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgdGV4dC1za3ktMTAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgIDxNYXBQaW4gY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1za3ktMjAwXCIgLz5cbiAgICAgICAgICAgICAge2NvbmZpZy5jb250YWN0LmNpdHl9IFN0dWRpbyBCcmFuY2hcbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTQgdGV4dC14cyBmb250LWJvbGRcIj5cbiAgICAgICAgICAgIDxhIFxuICAgICAgICAgICAgICBocmVmPXtgdGVsOiR7Y29uZmlnLmNvbnRhY3QuZW1lcmdlbmN5UGhvbmV9YH0gXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1hbWJlci0yMDAgaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFBob25lIGNsYXNzTmFtZT1cInctMy41IGgtMy41IGFuaW1hdGUtYm91bmNlXCIgLz5cbiAgICAgICAgICAgICAgMjQvNyBFbWVyZ2VuY3k6IDxzcGFuIGNsYXNzTmFtZT1cInVuZGVybGluZVwiPntjb25maWcuY29udGFjdC5lbWVyZ2VuY3lQaG9uZX08L3NwYW4+XG4gICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIDxhIFxuICAgICAgICAgICAgICBocmVmPXtgaHR0cHM6Ly93YS5tZS8ke2NvbmZpZy5jb250YWN0LndoYXRzYXBwLm51bWJlcn0/dGV4dD0ke2VuY29kZVVSSUNvbXBvbmVudChjb25maWcuY29udGFjdC53aGF0c2FwcC5kZWZhdWx0TWVzc2FnZSl9YH1cbiAgICAgICAgICAgICAgdGFyZ2V0PVwiX2JsYW5rXCJcbiAgICAgICAgICAgICAgcmVsPVwibm9vcGVuZXIgbm9yZWZlcnJlclwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImhpZGRlbiBtZDpmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtZW1lcmFsZC0yMDAgaG92ZXI6dGV4dC13aGl0ZSB0cmFuc2l0aW9uIGJnLXdoaXRlLzEwIHB4LTIuNSBweS0wLjUgcm91bmRlZC1mdWxsXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPE1lc3NhZ2VDaXJjbGUgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICBXaGF0c0FwcCBDb25zdWx0XG4gICAgICAgICAgICA8L2E+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBNYWluIFdoaXRlIEdsYXNzIEhlYWRlciAqL31cbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPXtgc3RpY2t5IHRvcC0wIHotNDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwICR7XG4gICAgICAgIGlzU2Nyb2xsZWQgXG4gICAgICAgICAgPyAnYmctd2hpdGUvOTUgYmFja2Ryb3AtYmx1ci1sZyBzaGFkb3ctbWQgcHktMyBib3JkZXItYiBib3JkZXItc2t5LTEwMCcgXG4gICAgICAgICAgOiAnYmctd2hpdGUvOTAgYmFja2Ryb3AtYmx1ci1tZCBweS00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS0xMDAnXG4gICAgICB9YH0+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctN3hsIG14LWF1dG8gcHgtNCBzbTpweC02IGxnOnB4LTggZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgXG4gICAgICAgICAgey8qIEJyYW5kIExvZ28gKi99XG4gICAgICAgICAgPGEgaHJlZj1cIiNoZXJvXCIgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgZ3JvdXBcIj5cbiAgICAgICAgICAgIDxtb3Rpb24uZGl2IFxuICAgICAgICAgICAgICB3aGlsZUhvdmVyPXt7IHJvdGF0ZTogMTUsIHNjYWxlOiAxLjA4IH19XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctMTEgaC0xMSByb3VuZGVkLTJ4bCBiZy1ncmFkaWVudC10by10ciBmcm9tLXNreS01MDAgdmlhLXNreS02MDAgdG8tdGVhbC01MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC13aGl0ZSBzaGFkb3ctbGcgc2hhZG93LXNreS01MDAvMjVcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8RHluYW1pY0ljb24gbmFtZT17Y29uZmlnLmxvZ28uaWNvbn0gY2xhc3NOYW1lPVwidy02IGgtNlwiIC8+XG4gICAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJsYWNrIHRyYWNraW5nLXRpZ2h0IHRleHQtc2xhdGUtOTAwIGZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGZvbnQtWydPdXRmaXQnXVwiPlxuICAgICAgICAgICAgICAgIHtjb25maWcubG9nby50ZXh0fVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHRleHQtWzEwcHhdIGZvbnQtZXh0cmFib2xkIHRyYWNraW5nLXdpZGVyIHVwcGVyY2FzZSB0ZXh0LXNreS02MDAgLW10LTAuNVwiPlxuICAgICAgICAgICAgICAgIHtjb25maWcubG9nby5zdWJ0ZXh0fVxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2E+XG5cbiAgICAgICAgICB7LyogRGVza3RvcCBOYXZpZ2F0aW9uIExpbmtzICovfVxuICAgICAgICAgIDxuYXYgY2xhc3NOYW1lPVwiaGlkZGVuIHhsOmZsZXggaXRlbXMtY2VudGVyIGdhcC03XCI+XG4gICAgICAgICAgICB7Y29uZmlnLm5hdmlnYXRpb24ubWFwKChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgICAga2V5PXtpdGVtLm5hbWV9XG4gICAgICAgICAgICAgICAgaHJlZj17aXRlbS5ocmVmfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS03MDAgaG92ZXI6dGV4dC1za3ktNjAwIHRyYW5zaXRpb24tY29sb3JzIHJlbGF0aXZlIGdyb3VwXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxzcGFuPntpdGVtLm5hbWV9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS0wIGxlZnQtMCB3LTAgaC0wLjUgYmctZ3JhZGllbnQtdG8tciBmcm9tLXNreS01MDAgdG8tdGVhbC01MDAgZ3JvdXAtaG92ZXI6dy1mdWxsIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCByb3VuZGVkLWZ1bGxcIiAvPlxuICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L25hdj5cblxuICAgICAgICAgIHsvKiBIZWFkZXIgQWN0aW9uIENvbnRyb2xzICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGlkZGVuIGxnOmZsZXggaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgICB7LyogUXVpY2sgUGhvbmUgQ2FsbCAqL31cbiAgICAgICAgICAgIDxhXG4gICAgICAgICAgICAgIGhyZWY9e2B0ZWw6JHtjb25maWcuY29udGFjdC5waG9uZX1gfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIuNSByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtODAwIGJnLXNreS01MCBob3ZlcjpiZy1za3ktMTAwIGJvcmRlciBib3JkZXItc2t5LTIwMCB0cmFuc2l0aW9uIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFBob25lIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1za3ktNjAwXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+e2NvbmZpZy5jb250YWN0LnBob25lfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvYT5cblxuICAgICAgICAgICAgey8qIEJvb2sgQXBwb2ludG1lbnQgQ1RBICovfVxuICAgICAgICAgICAgPG1vdGlvbi5idXR0b25cbiAgICAgICAgICAgICAgd2hpbGVIb3Zlcj17eyBzY2FsZTogMS4wNCwgeTogLTEgfX1cbiAgICAgICAgICAgICAgd2hpbGVUYXA9e3sgc2NhbGU6IDAuOTYgfX1cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25PcGVuQm9va2luZygpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC02IHB5LTMgcm91bmRlZC14bCB0ZXh0LXNtIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgYmctZ3JhZGllbnQtdG8tciBmcm9tLXNreS02MDAgdmlhLXRlYWwtNjAwIHRvLXNreS03MDAgaG92ZXI6ZnJvbS1za3ktNzAwIGhvdmVyOnRvLXRlYWwtNzAwIHNoYWRvdy1sZyBzaGFkb3ctc2t5LTYwMC8zMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxDYWxlbmRhciBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+Qm9vayBBcHBvaW50bWVudDwvc3Bhbj5cbiAgICAgICAgICAgIDwvbW90aW9uLmJ1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHsvKiBNb2JpbGUgTWVudSBUcmlnZ2VyICovfVxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCB4bDpoaWRkZW4gaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE1vYmlsZU1lbnVPcGVuKCFtb2JpbGVNZW51T3Blbil9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMi41IHJvdW5kZWQteGwgYm9yZGVyIGJvcmRlci1za3ktMjAwIHRleHQtc2xhdGUtODAwIGJnLXNreS01MFwiXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJUb2dnbGUgbWVudVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHttb2JpbGVNZW51T3BlbiA/IDxYIGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPiA6IDxNZW51IGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPn1cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvaGVhZGVyPlxuXG4gICAgICB7LyogTW9iaWxlIERyYXdlciBNZW51ICovfVxuICAgICAgPEFuaW1hdGVQcmVzZW5jZT5cbiAgICAgICAge21vYmlsZU1lbnVPcGVuICYmIChcbiAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCBoZWlnaHQ6IDAgfX1cbiAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgaGVpZ2h0OiAnYXV0bycgfX1cbiAgICAgICAgICAgIGV4aXQ9e3sgb3BhY2l0eTogMCwgaGVpZ2h0OiAwIH19XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ4bDpoaWRkZW4gc3RpY2t5IHRvcC1bNjVweF0gei0zMCBiZy13aGl0ZSBib3JkZXItYiBib3JkZXItc2t5LTEwMCBzaGFkb3ctMnhsIG92ZXJmbG93LWhpZGRlblwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC02IHB5LTYgc3BhY2UteS00XCI+XG4gICAgICAgICAgICAgIDxuYXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICB7Y29uZmlnLm5hdmlnYXRpb24ubWFwKChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8YVxuICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0ubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgaHJlZj17aXRlbS5ocmVmfVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRNb2JpbGVNZW51T3BlbihmYWxzZSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTgwMCBob3Zlcjp0ZXh0LXNreS02MDAgdHJhbnNpdGlvblwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLm5hbWV9XG4gICAgICAgICAgICAgICAgICA8L2E+XG4gICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgIDwvbmF2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGZsZXggZmxleC1jb2wgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHNldE1vYmlsZU1lbnVPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgICAgb25PcGVuQm9va2luZygpO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0zLjUgcm91bmRlZC14bCB0ZXh0LWNlbnRlciB0ZXh0LXNtIGZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGUgYmctZ3JhZGllbnQtdG8tciBmcm9tLXNreS02MDAgdG8tdGVhbC02MDAgc2hhZG93LW1kIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0yXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICBCb29rIEFwcG9pbnRtZW50IE5vd1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgICAgIGhyZWY9e2B0ZWw6JHtjb25maWcuY29udGFjdC5waG9uZX1gfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTMgcm91bmRlZC14bCB0ZXh0LWNlbnRlciB0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBiZy1zbGF0ZS01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMlwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFBob25lIGNsYXNzTmFtZT1cInctNCBoLTQgdGV4dC1za3ktNjAwXCIgLz5cbiAgICAgICAgICAgICAgICAgIENhbGwgU3R1ZGlvOiB7Y29uZmlnLmNvbnRhY3QucGhvbmV9XG4gICAgICAgICAgICAgICAgPC9hPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvQW5pbWF0ZVByZXNlbmNlPlxuICAgIDwvPlxuICApO1xufTtcbiJdfQ==