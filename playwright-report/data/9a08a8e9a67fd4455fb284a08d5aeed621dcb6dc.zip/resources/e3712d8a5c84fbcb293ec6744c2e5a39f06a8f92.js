import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/FloatingEmergencyWidget.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=383ccf5c";
import { motion, AnimatePresence } from "/node_modules/.vite/deps/framer-motion.js?v=d79d3615";
import { Phone, MessageCircle, Calendar, X, Sparkles, AlertCircle } from "/node_modules/.vite/deps/lucide-react.js?v=a18529f7";
import { useTheme } from "/src/context/ThemeContext.tsx";
var _jsxFileName = "D:/Aravind-Works/Dentel clinic/src/components/FloatingEmergencyWidget.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=383ccf5c";
var _s = $RefreshSig$();
export const FloatingEmergencyWidget = ({ onOpenBooking }) => {
	_s();
	const { config } = useTheme();
	const [expanded, setExpanded] = useState(false);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3",
		children: [/* @__PURE__ */ _jsxDEV(AnimatePresence, { children: expanded && /* @__PURE__ */ _jsxDEV(motion.div, {
			initial: {
				opacity: 0,
				scale: .8,
				y: 10
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .8,
				y: 10
			},
			className: "flex flex-col gap-2 bg-slate-900/95 backdrop-blur-md p-3 rounded-2xl border border-slate-700 shadow-2xl text-white text-xs",
			children: [
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: () => {
						setExpanded(false);
						onOpenBooking();
					},
					className: "flex items-center gap-2 px-3 py-2 rounded-xl bg-sky-500 hover:bg-sky-600 font-bold transition text-white",
					children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-4 h-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Book Appointment" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("a", {
					href: `https://wa.me/${config.contact.whatsapp.number}?text=${encodeURIComponent(config.contact.whatsapp.defaultMessage)}`,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 font-bold transition text-white",
					children: [/* @__PURE__ */ _jsxDEV(MessageCircle, { className: "w-4 h-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "WhatsApp Consultation" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 43,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 36,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("a", {
					href: `tel:${config.contact.emergencyPhone}`,
					className: "flex items-center gap-2 px-3 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 font-bold transition text-white",
					children: [/* @__PURE__ */ _jsxDEV(Phone, { className: "w-4 h-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "24/7 Emergency Line" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 13
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 11
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV(motion.button, {
			whileHover: { scale: 1.05 },
			whileTap: { scale: .95 },
			onClick: () => setExpanded(!expanded),
			className: "w-14 h-14 rounded-full bg-gradient-to-r from-sky-500 to-teal-500 text-white shadow-xl shadow-sky-500/30 flex items-center justify-center relative border-2 border-white/20 cursor-pointer",
			"aria-label": "Quick Actions",
			children: expanded ? /* @__PURE__ */ _jsxDEV(X, { className: "w-6 h-6" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 66,
				columnNumber: 11
			}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Phone, { className: "w-6 h-6 animate-pulse" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "absolute -top-1 -right-1 w-4 h-4 bg-emerald-400 rounded-full border-2 border-slate-900 flex items-center justify-center",
				children: /* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-emerald-950 animate-ping" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 15
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 11
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 58,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 5
	}, this);
};
_s(FloatingEmergencyWidget, "3HgGwoetg3puEVwAvj6nMB1qmf8=", false, function() {
	return [useTheme];
});
_c = FloatingEmergencyWidget;
var _c;
$RefreshReg$(_c, "FloatingEmergencyWidget");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/FloatingEmergencyWidget.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Aravind-Works/Dentel clinic/src/components/FloatingEmergencyWidget.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Aravind-Works/Dentel clinic/src/components/FloatingEmergencyWidget.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Aravind-Works/Dentel clinic/src/components/FloatingEmergencyWidget.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLFFBQVEsdUJBQXVCO0FBQ3hDLFNBQVMsT0FBTyxlQUFlLFVBQVUsR0FBRyxVQUFVLG1CQUFtQjtBQUN6RSxTQUFTLGdCQUFnQjs7OztBQU16QixPQUFPLE1BQU0sMkJBQW1FLEVBQUUsb0JBQW9COztDQUNwRyxNQUFNLEVBQUUsV0FBVyxTQUFTO0NBQzVCLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxLQUFLO0NBRTlDLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUVFLHdCQUFDLGlCQUFELFlBQ0csWUFDQyx3QkFBQyxPQUFPLEtBQVI7R0FDRSxTQUFTO0lBQUUsU0FBUztJQUFHLE9BQU87SUFBSyxHQUFHO0dBQUc7R0FDekMsU0FBUztJQUFFLFNBQVM7SUFBRyxPQUFPO0lBQUcsR0FBRztHQUFFO0dBQ3RDLE1BQU07SUFBRSxTQUFTO0lBQUcsT0FBTztJQUFLLEdBQUc7R0FBRztHQUN0QyxXQUFVO2FBSlo7SUFNRSx3QkFBQyxVQUFEO0tBQ0UsZUFBZTtNQUNiLFlBQVksS0FBSztNQUNqQixjQUFjO0tBQ2hCO0tBQ0EsV0FBVTtlQUxaLENBT0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OztlQUMvQix3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7O2FBQ3RCOzs7Ozs7SUFFUix3QkFBQyxLQUFEO0tBQ0UsTUFBTSxpQkFBaUIsT0FBTyxRQUFRLFNBQVMsT0FBTyxRQUFRLG1CQUFtQixPQUFPLFFBQVEsU0FBUyxjQUFjO0tBQ3ZILFFBQU87S0FDUCxLQUFJO0tBQ0osV0FBVTtlQUpaLENBTUUsd0JBQUMsZUFBRCxFQUFlLFdBQVUsVUFBVzs7OztlQUNwQyx3QkFBQyxRQUFELFlBQU0sd0JBQTJCOzs7O2FBQ2hDOzs7Ozs7SUFFSCx3QkFBQyxLQUFEO0tBQ0UsTUFBTSxPQUFPLE9BQU8sUUFBUTtLQUM1QixXQUFVO2VBRlosQ0FJRSx3QkFBQyxPQUFELEVBQU8sV0FBVSxVQUFXOzs7O2VBQzVCLHdCQUFDLFFBQUQsWUFBTSxzQkFBeUI7Ozs7YUFDOUI7Ozs7OztHQUNPOzs7OztXQUVDOzs7O1lBR2pCLHdCQUFDLE9BQU8sUUFBUjtHQUNFLFlBQVksRUFBRSxPQUFPLEtBQUs7R0FDMUIsVUFBVSxFQUFFLE9BQU8sSUFBSztHQUN4QixlQUFlLFlBQVksQ0FBQyxRQUFRO0dBQ3BDLFdBQVU7R0FDVixjQUFXO2FBRVYsV0FDQyx3QkFBQyxHQUFELEVBQUcsV0FBVSxVQUFXOzs7O2NBRXhCLGdEQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLHdCQUF5Qjs7OzthQUMxQyx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUNkLHdCQUFDLFFBQUQsRUFBTSxXQUFVLG1EQUF5RDs7Ozs7R0FDckU7Ozs7V0FDTjs7Ozs7RUFFUzs7OztVQUNaOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJGbG9hdGluZ0VtZXJnZW5jeVdpZGdldC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgbW90aW9uLCBBbmltYXRlUHJlc2VuY2UgfSBmcm9tICdmcmFtZXItbW90aW9uJztcbmltcG9ydCB7IFBob25lLCBNZXNzYWdlQ2lyY2xlLCBDYWxlbmRhciwgWCwgU3BhcmtsZXMsIEFsZXJ0Q2lyY2xlIH0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnQC9jb250ZXh0L1RoZW1lQ29udGV4dCc7XG5cbmludGVyZmFjZSBGbG9hdGluZ0VtZXJnZW5jeVdpZGdldFByb3BzIHtcbiAgb25PcGVuQm9va2luZzogKCkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IEZsb2F0aW5nRW1lcmdlbmN5V2lkZ2V0OiBSZWFjdC5GQzxGbG9hdGluZ0VtZXJnZW5jeVdpZGdldFByb3BzPiA9ICh7IG9uT3BlbkJvb2tpbmcgfSkgPT4ge1xuICBjb25zdCB7IGNvbmZpZyB9ID0gdXNlVGhlbWUoKTtcbiAgY29uc3QgW2V4cGFuZGVkLCBzZXRFeHBhbmRlZF0gPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGJvdHRvbS02IHJpZ2h0LTYgei00MCBmbGV4IGZsZXgtY29sIGl0ZW1zLWVuZCBnYXAtM1wiPlxuICAgICAgey8qIEV4cGFuZGVkIFF1aWNrIE9wdGlvbnMgKi99XG4gICAgICA8QW5pbWF0ZVByZXNlbmNlPlxuICAgICAgICB7ZXhwYW5kZWQgJiYgKFxuICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHNjYWxlOiAwLjgsIHk6IDEwIH19XG4gICAgICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHNjYWxlOiAxLCB5OiAwIH19XG4gICAgICAgICAgICBleGl0PXt7IG9wYWNpdHk6IDAsIHNjYWxlOiAwLjgsIHk6IDEwIH19XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGdhcC0yIGJnLXNsYXRlLTkwMC85NSBiYWNrZHJvcC1ibHVyLW1kIHAtMyByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBzaGFkb3ctMnhsIHRleHQtd2hpdGUgdGV4dC14c1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0RXhwYW5kZWQoZmFsc2UpO1xuICAgICAgICAgICAgICAgIG9uT3BlbkJvb2tpbmcoKTtcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtMyBweS0yIHJvdW5kZWQteGwgYmctc2t5LTUwMCBob3ZlcjpiZy1za3ktNjAwIGZvbnQtYm9sZCB0cmFuc2l0aW9uIHRleHQtd2hpdGVcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPkJvb2sgQXBwb2ludG1lbnQ8L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgaHJlZj17YGh0dHBzOi8vd2EubWUvJHtjb25maWcuY29udGFjdC53aGF0c2FwcC5udW1iZXJ9P3RleHQ9JHtlbmNvZGVVUklDb21wb25lbnQoY29uZmlnLmNvbnRhY3Qud2hhdHNhcHAuZGVmYXVsdE1lc3NhZ2UpfWB9XG4gICAgICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXG4gICAgICAgICAgICAgIHJlbD1cIm5vb3BlbmVyIG5vcmVmZXJyZXJcIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBweC0zIHB5LTIgcm91bmRlZC14bCBiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTcwMCBmb250LWJvbGQgdHJhbnNpdGlvbiB0ZXh0LXdoaXRlXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPE1lc3NhZ2VDaXJjbGUgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPldoYXRzQXBwIENvbnN1bHRhdGlvbjwvc3Bhbj5cbiAgICAgICAgICAgIDwvYT5cblxuICAgICAgICAgICAgPGFcbiAgICAgICAgICAgICAgaHJlZj17YHRlbDoke2NvbmZpZy5jb250YWN0LmVtZXJnZW5jeVBob25lfWB9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHB4LTMgcHktMiByb3VuZGVkLXhsIGJnLXJvc2UtNjAwIGhvdmVyOmJnLXJvc2UtNzAwIGZvbnQtYm9sZCB0cmFuc2l0aW9uIHRleHQtd2hpdGVcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8UGhvbmUgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPjI0LzcgRW1lcmdlbmN5IExpbmU8L3NwYW4+XG4gICAgICAgICAgICA8L2E+XG4gICAgICAgICAgPC9tb3Rpb24uZGl2PlxuICAgICAgICApfVxuICAgICAgPC9BbmltYXRlUHJlc2VuY2U+XG5cbiAgICAgIHsvKiBNYWluIEZsb2F0aW5nIFRyaWdnZXIgQnV0dG9uICovfVxuICAgICAgPG1vdGlvbi5idXR0b25cbiAgICAgICAgd2hpbGVIb3Zlcj17eyBzY2FsZTogMS4wNSB9fVxuICAgICAgICB3aGlsZVRhcD17eyBzY2FsZTogMC45NSB9fVxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRFeHBhbmRlZCghZXhwYW5kZWQpfVxuICAgICAgICBjbGFzc05hbWU9XCJ3LTE0IGgtMTQgcm91bmRlZC1mdWxsIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1za3ktNTAwIHRvLXRlYWwtNTAwIHRleHQtd2hpdGUgc2hhZG93LXhsIHNoYWRvdy1za3ktNTAwLzMwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJlbGF0aXZlIGJvcmRlci0yIGJvcmRlci13aGl0ZS8yMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgIGFyaWEtbGFiZWw9XCJRdWljayBBY3Rpb25zXCJcbiAgICAgID5cbiAgICAgICAge2V4cGFuZGVkID8gKFxuICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPlxuICAgICAgICApIDogKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8UGhvbmUgY2xhc3NOYW1lPVwidy02IGgtNiBhbmltYXRlLXB1bHNlXCIgLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIC10b3AtMSAtcmlnaHQtMSB3LTQgaC00IGJnLWVtZXJhbGQtNDAwIHJvdW5kZWQtZnVsbCBib3JkZXItMiBib3JkZXItc2xhdGUtOTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLWVtZXJhbGQtOTUwIGFuaW1hdGUtcGluZ1wiPjwvc3Bhbj5cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8Lz5cbiAgICAgICAgKX1cbiAgICAgIDwvbW90aW9uLmJ1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=