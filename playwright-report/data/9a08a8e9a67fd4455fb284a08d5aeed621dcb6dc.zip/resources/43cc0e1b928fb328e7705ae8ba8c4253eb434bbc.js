import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ServicesSection.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=383ccf5c";
import { motion, AnimatePresence } from "/node_modules/.vite/deps/framer-motion.js?v=d79d3615";
import { Sparkles, Clock, CheckCircle2, ArrowRight, X, Calendar, ShieldCheck, Flame, Info } from "/node_modules/.vite/deps/lucide-react.js?v=a18529f7";
import { useTheme } from "/src/context/ThemeContext.tsx";
import { DynamicIcon } from "/src/components/DynamicIcon.tsx";
var _jsxFileName = "D:/Aravind-Works/Dentel clinic/src/components/ServicesSection.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=383ccf5c";
var _s = $RefreshSig$();
export const ServicesSection = ({ onOpenBooking }) => {
	_s();
	const { config } = useTheme();
	const [activeCategory, setActiveCategory] = useState("all");
	const [selectedService, setSelectedService] = useState(null);
	const categories = [
		{
			id: "all",
			label: "All Services"
		},
		{
			id: "implants",
			label: "Dental Implants"
		},
		{
			id: "orthodontics",
			label: "Clear Aligners"
		},
		{
			id: "cosmetic",
			label: "Cosmetic & Veneers"
		},
		{
			id: "restorative",
			label: "Root Canal & Crowns"
		},
		{
			id: "emergency",
			label: "Emergency Care"
		}
	];
	const filteredServices = activeCategory === "all" ? config.services : config.services.filter((s) => s.category === activeCategory);
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "services",
		className: "py-20 relative",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "text-center max-w-3xl mx-auto space-y-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-100 dark:bg-teal-950/80 text-teal-800 dark:text-teal-300 text-xs font-bold uppercase tracking-wider",
							children: [/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-3.5 h-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 47,
								columnNumber: 13
							}, this), "World-Class Clinical Offerings"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight",
							children: ["Precision Dental Treatments, ", /* @__PURE__ */ _jsxDEV("span", {
								className: "text-gradient",
								children: "Zero-Pain Guarantee"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 51,
								columnNumber: 42
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 50,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-slate-600 dark:text-slate-300 text-sm sm:text-base",
							children: "Every procedure is executed using 3D digital precision, laser sterilization, and biocompatible materials for long-lasting natural aesthetics."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-10 flex items-center justify-start sm:justify-center gap-2 overflow-x-auto pb-4 scrollbar-none",
					children: categories.map((cat) => /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setActiveCategory(cat.id),
						className: `px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-all cursor-pointer ${activeCategory === cat.id ? "bg-sky-500 text-white shadow-md shadow-sky-500/25 scale-105" : "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-sky-400"}`,
						children: cat.label
					}, cat.id, false, {
						fileName: _jsxFileName,
						lineNumber: 61,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
					children: filteredServices.map((service) => /* @__PURE__ */ _jsxDEV(motion.div, {
						layout: true,
						initial: {
							opacity: 0,
							scale: .95
						},
						animate: {
							opacity: 1,
							scale: 1
						},
						exit: {
							opacity: 0,
							scale: .95
						},
						transition: { duration: .3 },
						className: "glass-card rounded-2xl p-6 relative flex flex-col justify-between group",
						children: [
							service.popular && /* @__PURE__ */ _jsxDEV("span", {
								className: "absolute top-4 right-4 inline-flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider bg-amber-500 text-slate-950 px-2.5 py-1 rounded-full shadow-sm",
								children: [/* @__PURE__ */ _jsxDEV(Flame, { className: "w-3 h-3" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 90,
									columnNumber: 19
								}, this), " Most Popular"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 89,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "w-12 h-12 rounded-xl bg-gradient-to-tr from-sky-500/10 to-teal-500/20 border border-sky-300/40 dark:border-sky-800 flex items-center justify-center text-sky-600 dark:text-sky-400 mb-4 group-hover:scale-110 transition-transform",
									children: /* @__PURE__ */ _jsxDEV(DynamicIcon, {
										name: service.iconName,
										className: "w-6 h-6"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 97,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 96,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("h3", {
									className: "text-xl font-bold text-slate-900 dark:text-white group-hover:text-sky-500 transition-colors",
									children: service.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 101,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-600 dark:text-slate-300 mt-2 leading-relaxed",
									children: service.shortDesc
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 106,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2 text-xs",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between text-slate-500 dark:text-slate-400",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ _jsxDEV(Clock, { className: "w-3.5 h-3.5 text-sky-500" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 114,
												columnNumber: 23
											}, this), " Duration:"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 113,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-semibold text-slate-800 dark:text-slate-200",
											children: service.duration
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 116,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 112,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between text-slate-500 dark:text-slate-400",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "flex items-center gap-1.5",
											children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, { className: "w-3.5 h-3.5 text-teal-500" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 121,
												columnNumber: 23
											}, this), " Painless Tech:"]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 120,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "font-semibold text-teal-600 dark:text-teal-400",
											children: service.painlessTech
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 123,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 119,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 111,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("ul", {
									className: "mt-4 space-y-1.5",
									children: service.highlights.slice(0, 3).map((item, idx) => /* @__PURE__ */ _jsxDEV("li", {
										className: "flex items-center gap-2 text-[11px] text-slate-600 dark:text-slate-300",
										children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-3.5 h-3.5 text-emerald-500 flex-shrink-0" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 131,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: item }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 132,
											columnNumber: 23
										}, this)]
									}, idx, true, {
										fileName: _jsxFileName,
										lineNumber: 130,
										columnNumber: 21
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 128,
									columnNumber: 17
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 94,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-[11px] text-slate-500 dark:text-slate-400 font-medium",
										children: "Estimated Pricing:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 141,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-sm font-extrabold text-sky-600 dark:text-sky-400",
										children: service.priceRange
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 142,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 140,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-2 gap-2",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setSelectedService(service),
										className: "py-2.5 px-3 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition flex items-center justify-center gap-1",
										children: [/* @__PURE__ */ _jsxDEV(Info, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 150,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "View Info" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 151,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 146,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => onOpenBooking(service.id),
										className: "py-2.5 px-3 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-sky-500 to-teal-500 hover:from-sky-600 hover:to-teal-600 shadow-md flex items-center justify-center gap-1 cursor-pointer",
										children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-3.5 h-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 158,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Book Now" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 159,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 154,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 145,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 15
							}, this)
						]
					}, service.id, true, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 42,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV(AnimatePresence, { children: selectedService && /* @__PURE__ */ _jsxDEV("div", {
			className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm",
			children: /* @__PURE__ */ _jsxDEV(motion.div, {
				initial: {
					opacity: 0,
					scale: .9
				},
				animate: {
					opacity: 1,
					scale: 1
				},
				exit: {
					opacity: 0,
					scale: .9
				},
				className: "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 max-w-2xl w-full shadow-2xl relative max-h-[90vh] overflow-y-auto",
				children: [
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setSelectedService(null),
						className: "absolute top-5 right-5 p-2 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white",
						children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 179,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-4 mb-4",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-14 h-14 rounded-2xl bg-sky-500/10 border border-sky-300 dark:border-sky-800 flex items-center justify-center text-sky-600 dark:text-sky-400",
							children: /* @__PURE__ */ _jsxDEV(DynamicIcon, {
								name: selectedService.iconName,
								className: "w-7 h-7"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 188,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 187,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-bold uppercase tracking-wider text-sky-500",
							children: ["Category: ", selectedService.category]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 191,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("h3", {
							className: "text-2xl font-bold text-slate-900 dark:text-white",
							children: selectedService.title
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 194,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 190,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 186,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-6",
						children: selectedService.fullDesc
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 200,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 mb-6 text-xs",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 block font-medium",
								children: "Treatment Time"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 207,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("strong", {
								className: "text-slate-900 dark:text-white text-sm",
								children: selectedService.duration
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 208,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 206,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 block font-medium",
								children: "Estimated Pricing"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 211,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("strong", {
								className: "text-sky-600 dark:text-sky-400 text-sm",
								children: selectedService.priceRange
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 212,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 210,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 block font-medium",
								children: "Painless Technology"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 215,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("strong", {
								className: "text-teal-600 dark:text-teal-400 text-sm",
								children: selectedService.painlessTech
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 216,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 214,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400 block font-medium",
								children: "EMI Options"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 219,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("strong", {
								className: "text-emerald-600 dark:text-emerald-400 text-sm",
								children: "0% EMI Available"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 220,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 218,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 205,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "mb-6 space-y-2",
						children: [/* @__PURE__ */ _jsxDEV("h4", {
							className: "text-xs font-bold uppercase tracking-wider text-slate-400",
							children: "Key Advantages"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 226,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-2",
							children: selectedService.highlights.map((h, i) => /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-200",
								children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4 text-emerald-500" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 230,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: h }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 231,
									columnNumber: 23
								}, this)]
							}, i, true, {
								fileName: _jsxFileName,
								lineNumber: 229,
								columnNumber: 21
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 227,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 225,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row gap-3 pt-4 border-t border-slate-100 dark:border-slate-800",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => {
								const svcId = selectedService.id;
								setSelectedService(null);
								onOpenBooking(svcId);
							},
							className: "flex-1 py-3.5 px-6 rounded-xl font-bold text-white bg-gradient-to-r from-sky-500 to-teal-500 hover:from-sky-600 hover:to-teal-600 shadow-lg flex items-center justify-center gap-2 text-sm cursor-pointer",
							children: [/* @__PURE__ */ _jsxDEV(Calendar, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 247,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: ["Book Appointment For ", selectedService.title] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 248,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 239,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setSelectedService(null),
							className: "py-3.5 px-6 rounded-xl font-semibold text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-sm",
							children: "Close Window"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 250,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 238,
						columnNumber: 15
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 173,
				columnNumber: 13
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 172,
			columnNumber: 11
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 170,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 5
	}, this);
};
_s(ServicesSection, "jguRTam/dHdp3K8dPqwZZg/X2gk=", false, function() {
	return [useTheme];
});
_c = ServicesSection;
var _c;
$RefreshReg$(_c, "ServicesSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ServicesSection.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Aravind-Works/Dentel clinic/src/components/ServicesSection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Aravind-Works/Dentel clinic/src/components/ServicesSection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Aravind-Works/Dentel clinic/src/components/ServicesSection.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLFFBQVEsdUJBQXVCO0FBQ3hDLFNBQ0UsVUFDQSxPQUNBLGNBQ0EsWUFDQSxHQUNBLFVBQ0EsYUFDQSxPQUNBLFlBQ0s7QUFDUCxTQUFTLGdCQUFnQjtBQUV6QixTQUFTLG1CQUFtQjs7OztBQU01QixPQUFPLE1BQU0sbUJBQW1ELEVBQUUsb0JBQW9COztDQUNwRixNQUFNLEVBQUUsV0FBVyxTQUFTO0NBQzVCLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQWlCLEtBQUs7Q0FDbEUsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBNkIsSUFBSTtDQUUvRSxNQUFNLGFBQWE7RUFDakI7R0FBRSxJQUFJO0dBQU8sT0FBTztFQUFlO0VBQ25DO0dBQUUsSUFBSTtHQUFZLE9BQU87RUFBa0I7RUFDM0M7R0FBRSxJQUFJO0dBQWdCLE9BQU87RUFBaUI7RUFDOUM7R0FBRSxJQUFJO0dBQVksT0FBTztFQUFxQjtFQUM5QztHQUFFLElBQUk7R0FBZSxPQUFPO0VBQXNCO0VBQ2xEO0dBQUUsSUFBSTtHQUFhLE9BQU87RUFBaUI7Q0FDN0M7Q0FFQSxNQUFNLG1CQUFtQixtQkFBbUIsUUFDeEMsT0FBTyxXQUNQLE9BQU8sU0FBUyxRQUFPLE1BQUssRUFBRSxhQUFhLGNBQWM7Q0FFN0QsT0FDRSx3QkFBQyxXQUFEO0VBQVMsSUFBRztFQUFXLFdBQVU7WUFBakMsQ0FDRSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBR0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRCxFQUFVLFdBQVUsY0FBZTs7OztpQkFBQyxnQ0FFakM7Ozs7OztNQUNMLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFkLENBQWtHLGlDQUNuRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBZ0I7T0FBeUI7Ozs7ZUFDcEY7Ozs7OztNQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUEwRDtNQUVwRTs7Ozs7S0FDQTs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWixXQUFXLEtBQUssUUFDZix3QkFBQyxVQUFEO01BRUUsZUFBZSxrQkFBa0IsSUFBSSxFQUFFO01BQ3ZDLFdBQVcsMkdBQ1QsbUJBQW1CLElBQUksS0FDbkIsZ0VBQ0E7Z0JBR0wsSUFBSTtLQUNDLEdBVEQsSUFBSTs7OztZQVNILENBQ1Q7SUFDRTs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLGlCQUFpQixLQUFLLFlBQ3JCLHdCQUFDLE9BQU8sS0FBUjtNQUVFO01BQ0EsU0FBUztPQUFFLFNBQVM7T0FBRyxPQUFPO01BQUs7TUFDbkMsU0FBUztPQUFFLFNBQVM7T0FBRyxPQUFPO01BQUU7TUFDaEMsTUFBTTtPQUFFLFNBQVM7T0FBRyxPQUFPO01BQUs7TUFDaEMsWUFBWSxFQUFFLFVBQVUsR0FBSTtNQUM1QixXQUFVO2dCQVBaO09BVUcsUUFBUSxXQUNQLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUNFLHdCQUFDLE9BQUQsRUFBTyxXQUFVLFVBQVc7Ozs7a0JBQUMsZUFDekI7Ozs7OztPQUdSLHdCQUFDLE9BQUQ7UUFFRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDYix3QkFBQyxhQUFEO1VBQWEsTUFBTSxRQUFRO1VBQVUsV0FBVTtTQUFXOzs7OztRQUN2RDs7Ozs7UUFHTCx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFDWCxRQUFRO1FBQ1A7Ozs7O1FBR0osd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQ1YsUUFBUTtRQUNSOzs7OztRQUdILHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEIsQ0FDRSx3QkFBQyxPQUFELEVBQU8sV0FBVSwyQkFBNEI7Ozs7cUJBQUMsWUFDMUM7Ozs7O29CQUNOLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFvRCxRQUFRO1VBQWU7Ozs7a0JBQ3hGOzs7OzttQkFFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUNFLHdCQUFDLGFBQUQsRUFBYSxXQUFVLDRCQUE2Qjs7OztxQkFBQyxpQkFDakQ7Ozs7O29CQUNOLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFrRCxRQUFRO1VBQW1COzs7O2tCQUMxRjs7Ozs7aUJBQ0Y7Ozs7OztRQUdMLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUNYLFFBQVEsV0FBVyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLFFBQ3pDLHdCQUFDLE1BQUQ7VUFBYyxXQUFVO29CQUF4QixDQUNFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLDZDQUE4Qzs7OztvQkFDdEUsd0JBQUMsUUFBRCxZQUFPLEtBQVc7Ozs7a0JBQ2hCO1lBSEs7Ozs7Z0JBR0wsQ0FDTDtRQUNDOzs7OztPQUNEOzs7OztPQUdMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBNkQ7U0FBd0I7Ozs7bUJBQ3JHLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUF5RCxRQUFRO1NBQWlCOzs7O2lCQUMvRjs7Ozs7a0JBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1VBQ0UsZUFBZSxtQkFBbUIsT0FBTztVQUN6QyxXQUFVO29CQUZaLENBSUUsd0JBQUMsTUFBRCxFQUFNLFdBQVUsY0FBZTs7OztvQkFDL0Isd0JBQUMsUUFBRCxZQUFNLFlBQWU7Ozs7a0JBQ2Y7Ozs7O21CQUVSLHdCQUFDLFVBQUQ7VUFDRSxlQUFlLGNBQWMsUUFBUSxFQUFFO1VBQ3ZDLFdBQVU7b0JBRlosQ0FJRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxjQUFlOzs7O29CQUNuQyx3QkFBQyxRQUFELFlBQU0sV0FBYzs7OztrQkFDZDs7Ozs7aUJBQ0w7Ozs7O2dCQUNGOzs7Ozs7TUFDSztRQXBGTCxRQUFROzs7O1lBb0ZILENBQ2I7SUFDRTs7Ozs7R0FFRjs7Ozs7WUFHTCx3QkFBQyxpQkFBRCxZQUNHLG1CQUNDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ2Isd0JBQUMsT0FBTyxLQUFSO0lBQ0UsU0FBUztLQUFFLFNBQVM7S0FBRyxPQUFPO0lBQUk7SUFDbEMsU0FBUztLQUFFLFNBQVM7S0FBRyxPQUFPO0lBQUU7SUFDaEMsTUFBTTtLQUFFLFNBQVM7S0FBRyxPQUFPO0lBQUk7SUFDL0IsV0FBVTtjQUpaO0tBTUUsd0JBQUMsVUFBRDtNQUNFLGVBQWUsbUJBQW1CLElBQUk7TUFDdEMsV0FBVTtnQkFFVix3QkFBQyxHQUFELEVBQUcsV0FBVSxVQUFXOzs7OztLQUNsQjs7Ozs7S0FFUix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNiLHdCQUFDLGFBQUQ7UUFBYSxNQUFNLGdCQUFnQjtRQUFVLFdBQVU7T0FBVzs7Ozs7TUFDL0Q7Ozs7Z0JBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFoQixDQUEwRSxjQUM3RCxnQkFBZ0IsUUFDdkI7Ozs7O2dCQUNOLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUNYLGdCQUFnQjtNQUNmOzs7O2NBQ0Q7Ozs7Y0FDRjs7Ozs7O0tBRUwsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQ1YsZ0JBQWdCO0tBQ2hCOzs7OztLQUdILHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFtQztPQUFvQjs7OztpQkFDdkUsd0JBQUMsVUFBRDtRQUFRLFdBQVU7a0JBQTBDLGdCQUFnQjtPQUFpQjs7OztlQUMxRjs7Ozs7T0FDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQW1DO09BQXVCOzs7O2lCQUMxRSx3QkFBQyxVQUFEO1FBQVEsV0FBVTtrQkFBMEMsZ0JBQWdCO09BQW1COzs7O2VBQzVGOzs7OztPQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBbUM7T0FBeUI7Ozs7aUJBQzVFLHdCQUFDLFVBQUQ7UUFBUSxXQUFVO2tCQUE0QyxnQkFBZ0I7T0FBcUI7Ozs7ZUFDaEc7Ozs7O09BQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFtQztPQUFpQjs7OztpQkFDcEUsd0JBQUMsVUFBRDtRQUFRLFdBQVU7a0JBQWlEO09BQXdCOzs7O2VBQ3hGOzs7OztNQUNGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUE0RDtNQUFrQjs7OztnQkFDNUYsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1osZ0JBQWdCLFdBQVcsS0FBSyxHQUFHLE1BQ2xDLHdCQUFDLE9BQUQ7UUFBYSxXQUFVO2tCQUF2QixDQUNFLHdCQUFDLGNBQUQsRUFBYyxXQUFVLDJCQUE0Qjs7OztrQkFDcEQsd0JBQUMsUUFBRCxZQUFPLEVBQVE7Ozs7Z0JBQ1o7VUFISzs7OztjQUdMLENBQ047TUFDRTs7OztjQUNGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQ7T0FDRSxlQUFlO1FBQ2IsTUFBTSxRQUFRLGdCQUFnQjtRQUM5QixtQkFBbUIsSUFBSTtRQUN2QixjQUFjLEtBQUs7T0FDckI7T0FDQSxXQUFVO2lCQU5aLENBUUUsd0JBQUMsVUFBRCxFQUFVLFdBQVUsVUFBVzs7OztpQkFDL0Isd0JBQUMsUUFBRCxhQUFNLHlCQUFzQixnQkFBZ0IsS0FBWTs7OztlQUNsRDs7Ozs7Z0JBQ1Isd0JBQUMsVUFBRDtPQUNFLGVBQWUsbUJBQW1CLElBQUk7T0FDdEMsV0FBVTtpQkFDWDtNQUVPOzs7O2NBQ0w7Ozs7OztJQUNLOzs7Ozs7RUFDVDs7OztXQUVROzs7O1VBQ1Y7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNlcnZpY2VzU2VjdGlvbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgbW90aW9uLCBBbmltYXRlUHJlc2VuY2UgfSBmcm9tICdmcmFtZXItbW90aW9uJztcbmltcG9ydCB7IFxuICBTcGFya2xlcywgXG4gIENsb2NrLCBcbiAgQ2hlY2tDaXJjbGUyLCBcbiAgQXJyb3dSaWdodCwgXG4gIFgsIFxuICBDYWxlbmRhciwgXG4gIFNoaWVsZENoZWNrLCBcbiAgRmxhbWUsXG4gIEluZm9cbn0gZnJvbSAnbHVjaWRlLXJlYWN0JztcbmltcG9ydCB7IHVzZVRoZW1lIH0gZnJvbSAnQC9jb250ZXh0L1RoZW1lQ29udGV4dCc7XG5pbXBvcnQgdHlwZSB7IFNlcnZpY2VJdGVtIH0gZnJvbSAnQC9jb25maWcvc2l0ZUNvbmZpZyc7XG5pbXBvcnQgeyBEeW5hbWljSWNvbiB9IGZyb20gJ0AvY29tcG9uZW50cy9EeW5hbWljSWNvbic7XG5cbmludGVyZmFjZSBTZXJ2aWNlc1NlY3Rpb25Qcm9wcyB7XG4gIG9uT3BlbkJvb2tpbmc6IChzZXJ2aWNlSWQ/OiBzdHJpbmcpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBTZXJ2aWNlc1NlY3Rpb246IFJlYWN0LkZDPFNlcnZpY2VzU2VjdGlvblByb3BzPiA9ICh7IG9uT3BlbkJvb2tpbmcgfSkgPT4ge1xuICBjb25zdCB7IGNvbmZpZyB9ID0gdXNlVGhlbWUoKTtcbiAgY29uc3QgW2FjdGl2ZUNhdGVnb3J5LCBzZXRBY3RpdmVDYXRlZ29yeV0gPSB1c2VTdGF0ZTxzdHJpbmc+KCdhbGwnKTtcbiAgY29uc3QgW3NlbGVjdGVkU2VydmljZSwgc2V0U2VsZWN0ZWRTZXJ2aWNlXSA9IHVzZVN0YXRlPFNlcnZpY2VJdGVtIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgY2F0ZWdvcmllcyA9IFtcbiAgICB7IGlkOiAnYWxsJywgbGFiZWw6ICdBbGwgU2VydmljZXMnIH0sXG4gICAgeyBpZDogJ2ltcGxhbnRzJywgbGFiZWw6ICdEZW50YWwgSW1wbGFudHMnIH0sXG4gICAgeyBpZDogJ29ydGhvZG9udGljcycsIGxhYmVsOiAnQ2xlYXIgQWxpZ25lcnMnIH0sXG4gICAgeyBpZDogJ2Nvc21ldGljJywgbGFiZWw6ICdDb3NtZXRpYyAmIFZlbmVlcnMnIH0sXG4gICAgeyBpZDogJ3Jlc3RvcmF0aXZlJywgbGFiZWw6ICdSb290IENhbmFsICYgQ3Jvd25zJyB9LFxuICAgIHsgaWQ6ICdlbWVyZ2VuY3knLCBsYWJlbDogJ0VtZXJnZW5jeSBDYXJlJyB9LFxuICBdO1xuXG4gIGNvbnN0IGZpbHRlcmVkU2VydmljZXMgPSBhY3RpdmVDYXRlZ29yeSA9PT0gJ2FsbCcgXG4gICAgPyBjb25maWcuc2VydmljZXMgXG4gICAgOiBjb25maWcuc2VydmljZXMuZmlsdGVyKHMgPT4gcy5jYXRlZ29yeSA9PT0gYWN0aXZlQ2F0ZWdvcnkpO1xuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gaWQ9XCJzZXJ2aWNlc1wiIGNsYXNzTmFtZT1cInB5LTIwIHJlbGF0aXZlXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTd4bCBteC1hdXRvIHB4LTQgc206cHgtNiBsZzpweC04XCI+XG4gICAgICAgIFxuICAgICAgICB7LyogU2VjdGlvbiBIZWFkZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgbWF4LXctM3hsIG14LWF1dG8gc3BhY2UteS00XCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCBiZy10ZWFsLTEwMCBkYXJrOmJnLXRlYWwtOTUwLzgwIHRleHQtdGVhbC04MDAgZGFyazp0ZXh0LXRlYWwtMzAwIHRleHQteHMgZm9udC1ib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgIFdvcmxkLUNsYXNzIENsaW5pY2FsIE9mZmVyaW5nc1xuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LTN4bCBzbTp0ZXh0LTR4bCBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgdHJhY2tpbmctdGlnaHRcIj5cbiAgICAgICAgICAgIFByZWNpc2lvbiBEZW50YWwgVHJlYXRtZW50cywgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1ncmFkaWVudFwiPlplcm8tUGFpbiBHdWFyYW50ZWU8L3NwYW4+XG4gICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHRleHQtc20gc206dGV4dC1iYXNlXCI+XG4gICAgICAgICAgICBFdmVyeSBwcm9jZWR1cmUgaXMgZXhlY3V0ZWQgdXNpbmcgM0QgZGlnaXRhbCBwcmVjaXNpb24sIGxhc2VyIHN0ZXJpbGl6YXRpb24sIGFuZCBiaW9jb21wYXRpYmxlIG1hdGVyaWFscyBmb3IgbG9uZy1sYXN0aW5nIG5hdHVyYWwgYWVzdGhldGljcy5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBDYXRlZ29yeSBUYWJzICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktc3RhcnQgc206anVzdGlmeS1jZW50ZXIgZ2FwLTIgb3ZlcmZsb3cteC1hdXRvIHBiLTQgc2Nyb2xsYmFyLW5vbmVcIj5cbiAgICAgICAgICB7Y2F0ZWdvcmllcy5tYXAoKGNhdCkgPT4gKFxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBrZXk9e2NhdC5pZH1cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlQ2F0ZWdvcnkoY2F0LmlkKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yLjUgcm91bmRlZC14bCB0ZXh0LXhzIHNtOnRleHQtc20gZm9udC1zZW1pYm9sZCB3aGl0ZXNwYWNlLW5vd3JhcCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciAke1xuICAgICAgICAgICAgICAgIGFjdGl2ZUNhdGVnb3J5ID09PSBjYXQuaWRcbiAgICAgICAgICAgICAgICAgID8gJ2JnLXNreS01MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQgc2hhZG93LXNreS01MDAvMjUgc2NhbGUtMTA1J1xuICAgICAgICAgICAgICAgICAgOiAnYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAgaG92ZXI6Ym9yZGVyLXNreS00MDAnXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7Y2F0LmxhYmVsfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBTZXJ2aWNlcyBHcmlkICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEwIGdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cbiAgICAgICAgICB7ZmlsdGVyZWRTZXJ2aWNlcy5tYXAoKHNlcnZpY2UpID0+IChcbiAgICAgICAgICAgIDxtb3Rpb24uZGl2XG4gICAgICAgICAgICAgIGtleT17c2VydmljZS5pZH1cbiAgICAgICAgICAgICAgbGF5b3V0XG4gICAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgc2NhbGU6IDAuOTUgfX1cbiAgICAgICAgICAgICAgYW5pbWF0ZT17eyBvcGFjaXR5OiAxLCBzY2FsZTogMSB9fVxuICAgICAgICAgICAgICBleGl0PXt7IG9wYWNpdHk6IDAsIHNjYWxlOiAwLjk1IH19XG4gICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuMyB9fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnbGFzcy1jYXJkIHJvdW5kZWQtMnhsIHAtNiByZWxhdGl2ZSBmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBncm91cFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHsvKiBQb3B1bGFyIEJhZGdlICovfVxuICAgICAgICAgICAgICB7c2VydmljZS5wb3B1bGFyICYmIChcbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNCByaWdodC00IGlubGluZS1mbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSB0ZXh0LVsxMHB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIGJnLWFtYmVyLTUwMCB0ZXh0LXNsYXRlLTk1MCBweC0yLjUgcHktMSByb3VuZGVkLWZ1bGwgc2hhZG93LXNtXCI+XG4gICAgICAgICAgICAgICAgICA8RmxhbWUgY2xhc3NOYW1lPVwidy0zIGgtM1wiIC8+IE1vc3QgUG9wdWxhclxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIHsvKiBJY29uICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHJvdW5kZWQteGwgYmctZ3JhZGllbnQtdG8tdHIgZnJvbS1za3ktNTAwLzEwIHRvLXRlYWwtNTAwLzIwIGJvcmRlciBib3JkZXItc2t5LTMwMC80MCBkYXJrOmJvcmRlci1za3ktODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc2t5LTYwMCBkYXJrOnRleHQtc2t5LTQwMCBtYi00IGdyb3VwLWhvdmVyOnNjYWxlLTExMCB0cmFuc2l0aW9uLXRyYW5zZm9ybVwiPlxuICAgICAgICAgICAgICAgICAgPER5bmFtaWNJY29uIG5hbWU9e3NlcnZpY2UuaWNvbk5hbWV9IGNsYXNzTmFtZT1cInctNiBoLTZcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIFRpdGxlICovfVxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGUgZ3JvdXAtaG92ZXI6dGV4dC1za3ktNTAwIHRyYW5zaXRpb24tY29sb3JzXCI+XG4gICAgICAgICAgICAgICAgICB7c2VydmljZS50aXRsZX1cbiAgICAgICAgICAgICAgICA8L2gzPlxuXG4gICAgICAgICAgICAgICAgey8qIFNob3J0IERlc2NyaXB0aW9uICovfVxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBtdC0yIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgICAge3NlcnZpY2Uuc2hvcnREZXNjfVxuICAgICAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgICAgIHsvKiBEZXRhaWxzIFBpbGxzICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBwdC00IGJvcmRlci10IGJvcmRlci1zbGF0ZS0xMDAgZGFyazpib3JkZXItc2xhdGUtODAwIHNwYWNlLXktMiB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0ZXh0LXNsYXRlLTUwMCBkYXJrOnRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8Q2xvY2sgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjUgdGV4dC1za3ktNTAwXCIgLz4gRHVyYXRpb246XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTgwMCBkYXJrOnRleHQtc2xhdGUtMjAwXCI+e3NlcnZpY2UuZHVyYXRpb259PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtNTAwIGRhcms6dGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxTaGllbGRDaGVjayBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LXRlYWwtNTAwXCIgLz4gUGFpbmxlc3MgVGVjaDpcbiAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkIHRleHQtdGVhbC02MDAgZGFyazp0ZXh0LXRlYWwtNDAwXCI+e3NlcnZpY2UucGFpbmxlc3NUZWNofTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIEhpZ2hsaWdodHMgKi99XG4gICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cIm10LTQgc3BhY2UteS0xLjVcIj5cbiAgICAgICAgICAgICAgICAgIHtzZXJ2aWNlLmhpZ2hsaWdodHMuc2xpY2UoMCwgMykubWFwKChpdGVtLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGxpIGtleT17aWR4fSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTMuNSBoLTMuNSB0ZXh0LWVtZXJhbGQtNTAwIGZsZXgtc2hyaW5rLTBcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPntpdGVtfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBQcmljZSBSYW5nZSAmIEFjdGlvbiBCdXR0b25zICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgcHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMCBmb250LW1lZGl1bVwiPkVzdGltYXRlZCBQcmljaW5nOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1leHRyYWJvbGQgdGV4dC1za3ktNjAwIGRhcms6dGV4dC1za3ktNDAwXCI+e3NlcnZpY2UucHJpY2VSYW5nZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRTZXJ2aWNlKHNlcnZpY2UpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweS0yLjUgcHgtMyByb3VuZGVkLXhsIHRleHQteHMgZm9udC1zZW1pYm9sZCB0ZXh0LXNsYXRlLTcwMCBkYXJrOnRleHQtc2xhdGUtMjAwIGJnLXNsYXRlLTEwMCBkYXJrOmJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS0yMDAgZGFyazpob3ZlcjpiZy1zbGF0ZS03MDAgdHJhbnNpdGlvbiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMVwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxJbmZvIGNsYXNzTmFtZT1cInctMy41IGgtMy41XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+VmlldyBJbmZvPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25PcGVuQm9va2luZyhzZXJ2aWNlLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHktMi41IHB4LTMgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1za3ktNTAwIHRvLXRlYWwtNTAwIGhvdmVyOmZyb20tc2t5LTYwMCBob3Zlcjp0by10ZWFsLTYwMCBzaGFkb3ctbWQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8Q2FsZW5kYXIgY2xhc3NOYW1lPVwidy0zLjUgaC0zLjVcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5Cb29rIE5vdzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogU2VydmljZSBEZXRhaWxzIE1vZGFsIERyYXdlciAqL31cbiAgICAgIDxBbmltYXRlUHJlc2VuY2U+XG4gICAgICAgIHtzZWxlY3RlZFNlcnZpY2UgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHAtNCBiZy1zbGF0ZS05NTAvNzAgYmFja2Ryb3AtYmx1ci1zbVwiPlxuICAgICAgICAgICAgPG1vdGlvbi5kaXZcbiAgICAgICAgICAgICAgaW5pdGlhbD17eyBvcGFjaXR5OiAwLCBzY2FsZTogMC45IH19XG4gICAgICAgICAgICAgIGFuaW1hdGU9e3sgb3BhY2l0eTogMSwgc2NhbGU6IDEgfX1cbiAgICAgICAgICAgICAgZXhpdD17eyBvcGFjaXR5OiAwLCBzY2FsZTogMC45IH19XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIGRhcms6Ymctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTN4bCBwLTYgc206cC04IG1heC13LTJ4bCB3LWZ1bGwgc2hhZG93LTJ4bCByZWxhdGl2ZSBtYXgtaC1bOTB2aF0gb3ZlcmZsb3cteS1hdXRvXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkU2VydmljZShudWxsKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNSByaWdodC01IHAtMiByb3VuZGVkLWZ1bGwgYmctc2xhdGUtMTAwIGRhcms6Ymctc2xhdGUtODAwIHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtOTAwIGRhcms6aG92ZXI6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBtYi00XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTE0IGgtMTQgcm91bmRlZC0yeGwgYmctc2t5LTUwMC8xMCBib3JkZXIgYm9yZGVyLXNreS0zMDAgZGFyazpib3JkZXItc2t5LTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXNreS02MDAgZGFyazp0ZXh0LXNreS00MDBcIj5cbiAgICAgICAgICAgICAgICAgIDxEeW5hbWljSWNvbiBuYW1lPXtzZWxlY3RlZFNlcnZpY2UuaWNvbk5hbWV9IGNsYXNzTmFtZT1cInctNyBoLTdcIiAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1za3ktNTAwXCI+XG4gICAgICAgICAgICAgICAgICAgIENhdGVnb3J5OiB7c2VsZWN0ZWRTZXJ2aWNlLmNhdGVnb3J5fVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBkYXJrOnRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICAgICAge3NlbGVjdGVkU2VydmljZS50aXRsZX1cbiAgICAgICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1zbGF0ZS02MDAgZGFyazp0ZXh0LXNsYXRlLTMwMCBsZWFkaW5nLXJlbGF4ZWQgbWItNlwiPlxuICAgICAgICAgICAgICAgIHtzZWxlY3RlZFNlcnZpY2UuZnVsbERlc2N9XG4gICAgICAgICAgICAgIDwvcD5cblxuICAgICAgICAgICAgICB7LyogU3BlY3MgR3JpZCAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC00IHAtNCByb3VuZGVkLTJ4bCBiZy1zbGF0ZS01MCBkYXJrOmJnLXNsYXRlLTgwMC82MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCBkYXJrOmJvcmRlci1zbGF0ZS03MDAvODAgbWItNiB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIGZvbnQtbWVkaXVtXCI+VHJlYXRtZW50IFRpbWU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSB0ZXh0LXNtXCI+e3NlbGVjdGVkU2VydmljZS5kdXJhdGlvbn08L3N0cm9uZz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgYmxvY2sgZm9udC1tZWRpdW1cIj5Fc3RpbWF0ZWQgUHJpY2luZzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC1za3ktNjAwIGRhcms6dGV4dC1za3ktNDAwIHRleHQtc21cIj57c2VsZWN0ZWRTZXJ2aWNlLnByaWNlUmFuZ2V9PC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIGJsb2NrIGZvbnQtbWVkaXVtXCI+UGFpbmxlc3MgVGVjaG5vbG9neTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC10ZWFsLTYwMCBkYXJrOnRleHQtdGVhbC00MDAgdGV4dC1zbVwiPntzZWxlY3RlZFNlcnZpY2UucGFpbmxlc3NUZWNofTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBibG9jayBmb250LW1lZGl1bVwiPkVNSSBPcHRpb25zPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJ0ZXh0LWVtZXJhbGQtNjAwIGRhcms6dGV4dC1lbWVyYWxkLTQwMCB0ZXh0LXNtXCI+MCUgRU1JIEF2YWlsYWJsZTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogSGlnaGxpZ2h0cyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02IHNwYWNlLXktMlwiPlxuICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS00MDBcIj5LZXkgQWR2YW50YWdlczwvaDQ+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICB7c2VsZWN0ZWRTZXJ2aWNlLmhpZ2hsaWdodHMubWFwKChoLCBpKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpfSBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXhzIGZvbnQtc2VtaWJvbGQgdGV4dC1zbGF0ZS03MDAgZGFyazp0ZXh0LXNsYXRlLTIwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwidy00IGgtNCB0ZXh0LWVtZXJhbGQtNTAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57aH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIHsvKiBBY3Rpb24gQnV0dG9ucyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGdhcC0zIHB0LTQgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTEwMCBkYXJrOmJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHN2Y0lkID0gc2VsZWN0ZWRTZXJ2aWNlLmlkO1xuICAgICAgICAgICAgICAgICAgICBzZXRTZWxlY3RlZFNlcnZpY2UobnVsbCk7XG4gICAgICAgICAgICAgICAgICAgIG9uT3BlbkJvb2tpbmcoc3ZjSWQpO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBweS0zLjUgcHgtNiByb3VuZGVkLXhsIGZvbnQtYm9sZCB0ZXh0LXdoaXRlIGJnLWdyYWRpZW50LXRvLXIgZnJvbS1za3ktNTAwIHRvLXRlYWwtNTAwIGhvdmVyOmZyb20tc2t5LTYwMCBob3Zlcjp0by10ZWFsLTYwMCBzaGFkb3ctbGcgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgdGV4dC1zbSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPENhbGVuZGFyIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+Qm9vayBBcHBvaW50bWVudCBGb3Ige3NlbGVjdGVkU2VydmljZS50aXRsZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRTZXJ2aWNlKG51bGwpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHktMy41IHB4LTYgcm91bmRlZC14bCBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIGhvdmVyOmJnLXNsYXRlLTEwMCBkYXJrOmhvdmVyOmJnLXNsYXRlLTgwMCB0ZXh0LXNtXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBDbG9zZSBXaW5kb3dcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L21vdGlvbi5kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L0FuaW1hdGVQcmVzZW5jZT5cbiAgICA8L3NlY3Rpb24+XG4gICk7XG59O1xuIl19