import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TestimonialsSection.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=383ccf5c";
import { motion } from "/node_modules/.vite/deps/framer-motion.js?v=d79d3615";
import { Star, Quote, CheckCircle2, MessageSquare } from "/node_modules/.vite/deps/lucide-react.js?v=a18529f7";
import { useTheme } from "/src/context/ThemeContext.tsx";
var _jsxFileName = "D:/Aravind-Works/Dentel clinic/src/components/TestimonialsSection.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=383ccf5c";
var _s = $RefreshSig$();
export const TestimonialsSection = () => {
	_s();
	const { config } = useTheme();
	return /* @__PURE__ */ _jsxDEV("section", {
		id: "reviews",
		className: "py-20 relative",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "text-center max-w-3xl mx-auto space-y-3",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-100 dark:bg-amber-950/80 text-amber-800 dark:text-amber-300 text-xs font-bold uppercase tracking-wider",
							children: [/* @__PURE__ */ _jsxDEV(Star, { className: "w-3.5 h-3.5 fill-amber-500 text-amber-500" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 16,
								columnNumber: 13
							}, this), "Verified Patient Feedback"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 15,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight",
							children: ["Stories Of ", /* @__PURE__ */ _jsxDEV("span", {
								className: "text-gradient",
								children: "Transformed Smiles"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 20,
								columnNumber: 24
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 19,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-slate-600 dark:text-slate-300 text-sm sm:text-base",
							children: "Read authentic reviews from over 18,500+ satisfied local and international patients."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 22,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 14,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-8 max-w-md mx-auto p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm flex items-center justify-between",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-10 h-10 rounded-full bg-sky-500/10 flex items-center justify-center font-bold text-sky-600 dark:text-sky-400",
							children: "G"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 30,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-1",
							children: [[...Array(5)].map((_, i) => /* @__PURE__ */ _jsxDEV(Star, { className: "w-4 h-4 fill-amber-400 text-amber-400" }, i, false, {
								fileName: _jsxFileName,
								lineNumber: 36,
								columnNumber: 19
							}, this)), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-extrabold text-slate-900 dark:text-white ml-1",
								children: [config.metrics.googleRating, " / 5.0"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 38,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 34,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "text-[11px] text-slate-500 dark:text-slate-400",
							children: "Verified Google Business Reviews"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 42,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 33,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 29,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950 px-2.5 py-1 rounded-full border border-emerald-200 dark:border-emerald-800",
						children: [config.metrics.reviewsCount, " Reviews"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-12 grid grid-cols-1 md:grid-cols-3 gap-6",
					children: config.testimonials.map((t, idx) => /* @__PURE__ */ _jsxDEV(motion.div, {
						initial: {
							opacity: 0,
							y: 15
						},
						whileInView: {
							opacity: 1,
							y: 0
						},
						viewport: { once: true },
						transition: {
							duration: .4,
							delay: idx * .1
						},
						className: "glass-card rounded-2xl p-6 border border-slate-200/90 dark:border-slate-800 flex flex-col justify-between relative",
						children: [
							/* @__PURE__ */ _jsxDEV(Quote, { className: "w-8 h-8 text-sky-500/20 absolute top-4 right-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 63,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "space-y-4",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center gap-1",
									children: [...Array(t.rating)].map((_, i) => /* @__PURE__ */ _jsxDEV(Star, { className: "w-4 h-4 fill-amber-400 text-amber-400" }, i, false, {
										fileName: _jsxFileName,
										lineNumber: 69,
										columnNumber: 21
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 67,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed italic",
									children: [
										"\"",
										t.comment,
										"\""
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 73,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-bold text-slate-900 dark:text-white flex items-center gap-1",
									children: [t.name, t.verified && /* @__PURE__ */ _jsxDEV("span", {
										title: "Verified Patient",
										children: /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-3.5 h-3.5 text-sky-500 inline" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 82,
											columnNumber: 67
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 82,
										columnNumber: 36
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 80,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[11px] text-slate-400 block",
									children: t.role
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 84,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 79,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "text-right",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-semibold text-teal-600 dark:text-teal-400 text-[11px] block",
										children: t.treatment
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 88,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-slate-400",
										children: t.date
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 89,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 87,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 78,
								columnNumber: 15
							}, this)
						]
					}, t.id, true, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 10,
		columnNumber: 5
	}, this);
};
_s(TestimonialsSection, "qQ7g6tIEyataPS75zVi2PFhrMqc=", false, function() {
	return [useTheme];
});
_c = TestimonialsSection;
var _c;
$RefreshReg$(_c, "TestimonialsSection");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/TestimonialsSection.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Aravind-Works/Dentel clinic/src/components/TestimonialsSection.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Aravind-Works/Dentel clinic/src/components/TestimonialsSection.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Aravind-Works/Dentel clinic/src/components/TestimonialsSection.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsY0FBYztBQUN2QixTQUFTLE1BQU0sT0FBTyxjQUFjLHFCQUFxQjtBQUN6RCxTQUFTLGdCQUFnQjs7OztBQUV6QixPQUFPLE1BQU0sNEJBQXNDOztDQUNqRCxNQUFNLEVBQUUsV0FBVyxTQUFTO0NBRTVCLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLElBQUc7RUFBVSxXQUFVO1lBQzlCLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFHRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFELEVBQU0sV0FBVSw0Q0FBNkM7Ozs7aUJBQUMsMkJBRTNEOzs7Ozs7TUFDTCx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBZCxDQUFrRyxlQUNyRix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBZ0I7T0FBd0I7Ozs7ZUFDakU7Ozs7OztNQUNKLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUEwRDtNQUVwRTs7Ozs7S0FDQTs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWlIO01BRTNIOzs7O2dCQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNHLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLE1BQ3JCLHdCQUFDLE1BQUQsRUFBYyxXQUFVLHdDQUF5QyxHQUF0RDs7OztjQUFzRCxDQUNsRSxHQUNELHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUNHLE9BQU8sUUFBUSxjQUFhLFFBQ3pCOzs7OztlQUNIOzs7OztnQkFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBaUQ7TUFFM0Q7Ozs7Y0FDRjs7OztjQUNGOzs7OztlQUNMLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQixDQUNHLE9BQU8sUUFBUSxjQUFhLFVBQ3pCOzs7OzthQUNIOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLE9BQU8sYUFBYSxLQUFLLEdBQUcsUUFDM0Isd0JBQUMsT0FBTyxLQUFSO01BRUUsU0FBUztPQUFFLFNBQVM7T0FBRyxHQUFHO01BQUc7TUFDN0IsYUFBYTtPQUFFLFNBQVM7T0FBRyxHQUFHO01BQUU7TUFDaEMsVUFBVSxFQUFFLE1BQU0sS0FBSztNQUN2QixZQUFZO09BQUUsVUFBVTtPQUFLLE9BQU8sTUFBTTtNQUFJO01BQzlDLFdBQVU7Z0JBTlo7T0FRRSx3QkFBQyxPQUFELEVBQU8sV0FBVSxpREFBa0Q7Ozs7O09BRW5FLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBRUUsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQ1osQ0FBQyxHQUFHLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxNQUM1Qix3QkFBQyxNQUFELEVBQWMsV0FBVSx3Q0FBeUMsR0FBdEQ7Ozs7Z0JBQXNELENBQ2xFO1FBQ0U7Ozs7a0JBRUwsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQWI7VUFBNEY7VUFDeEYsRUFBRTtVQUFRO1NBQ1g7Ozs7O2dCQUNBOzs7Ozs7T0FFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBZCxDQUNHLEVBQUUsTUFDRixFQUFFLFlBQVksd0JBQUMsUUFBRDtVQUFNLE9BQU07b0JBQW1CLHdCQUFDLGNBQUQsRUFBYyxXQUFVLGtDQUFtQzs7Ozs7U0FBTzs7OztpQkFDOUc7Ozs7O2tCQUNKLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFvQyxFQUFFO1FBQVc7Ozs7Z0JBQzlEOzs7O2tCQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQW9FLEVBQUU7U0FBZ0I7Ozs7bUJBQ3RHLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE4QixFQUFFO1NBQVc7Ozs7aUJBQ3hEOzs7OztnQkFDRjs7Ozs7O01BQ0s7UUFwQ0wsRUFBRTs7OztZQW9DRyxDQUNiO0lBQ0U7Ozs7O0dBRUY7Ozs7OztDQUNFOzs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlRlc3RpbW9uaWFsc1NlY3Rpb24udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBtb3Rpb24gfSBmcm9tICdmcmFtZXItbW90aW9uJztcbmltcG9ydCB7IFN0YXIsIFF1b3RlLCBDaGVja0NpcmNsZTIsIE1lc3NhZ2VTcXVhcmUgfSBmcm9tICdsdWNpZGUtcmVhY3QnO1xuaW1wb3J0IHsgdXNlVGhlbWUgfSBmcm9tICdAL2NvbnRleHQvVGhlbWVDb250ZXh0JztcblxuZXhwb3J0IGNvbnN0IFRlc3RpbW9uaWFsc1NlY3Rpb246IFJlYWN0LkZDID0gKCkgPT4ge1xuICBjb25zdCB7IGNvbmZpZyB9ID0gdXNlVGhlbWUoKTtcblxuICByZXR1cm4gKFxuICAgIDxzZWN0aW9uIGlkPVwicmV2aWV3c1wiIGNsYXNzTmFtZT1cInB5LTIwIHJlbGF0aXZlXCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1heC13LTd4bCBteC1hdXRvIHB4LTQgc206cHgtNiBsZzpweC04XCI+XG4gICAgICAgIFxuICAgICAgICB7LyogU2VjdGlvbiBIZWFkZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgbWF4LXctM3hsIG14LWF1dG8gc3BhY2UteS0zXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCBiZy1hbWJlci0xMDAgZGFyazpiZy1hbWJlci05NTAvODAgdGV4dC1hbWJlci04MDAgZGFyazp0ZXh0LWFtYmVyLTMwMCB0ZXh0LXhzIGZvbnQtYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cbiAgICAgICAgICAgIDxTdGFyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IGZpbGwtYW1iZXItNTAwIHRleHQtYW1iZXItNTAwXCIgLz5cbiAgICAgICAgICAgIFZlcmlmaWVkIFBhdGllbnQgRmVlZGJhY2tcbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC0zeGwgc206dGV4dC00eGwgZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDAgZGFyazp0ZXh0LXdoaXRlIHRyYWNraW5nLXRpZ2h0XCI+XG4gICAgICAgICAgICBTdG9yaWVzIE9mIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZ3JhZGllbnRcIj5UcmFuc2Zvcm1lZCBTbWlsZXM8L3NwYW4+XG4gICAgICAgICAgPC9oMj5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTYwMCBkYXJrOnRleHQtc2xhdGUtMzAwIHRleHQtc20gc206dGV4dC1iYXNlXCI+XG4gICAgICAgICAgICBSZWFkIGF1dGhlbnRpYyByZXZpZXdzIGZyb20gb3ZlciAxOCw1MDArIHNhdGlzZmllZCBsb2NhbCBhbmQgaW50ZXJuYXRpb25hbCBwYXRpZW50cy5cbiAgICAgICAgICA8L3A+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBHb29nbGUgVHJ1c3QgQmFubmVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTggbWF4LXctbWQgbXgtYXV0byBwLTQgcm91bmRlZC0yeGwgYmctd2hpdGUgZGFyazpiZy1zbGF0ZS04MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0yMDAgZGFyazpib3JkZXItc2xhdGUtNzAwIHNoYWRvdy1zbSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTAgaC0xMCByb3VuZGVkLWZ1bGwgYmctc2t5LTUwMC8xMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBmb250LWJvbGQgdGV4dC1za3ktNjAwIGRhcms6dGV4dC1za3ktNDAwXCI+XG4gICAgICAgICAgICAgIEdcbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgIHtbLi4uQXJyYXkoNSldLm1hcCgoXywgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgPFN0YXIga2V5PXtpfSBjbGFzc05hbWU9XCJ3LTQgaC00IGZpbGwtYW1iZXItNDAwIHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtZXh0cmFib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBtbC0xXCI+XG4gICAgICAgICAgICAgICAgICB7Y29uZmlnLm1ldHJpY3MuZ29vZ2xlUmF0aW5nfSAvIDUuMFxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgZGFyazp0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgIFZlcmlmaWVkIEdvb2dsZSBCdXNpbmVzcyBSZXZpZXdzXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1lbWVyYWxkLTYwMCBkYXJrOnRleHQtZW1lcmFsZC00MDAgYmctZW1lcmFsZC01MCBkYXJrOmJnLWVtZXJhbGQtOTUwIHB4LTIuNSBweS0xIHJvdW5kZWQtZnVsbCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtMjAwIGRhcms6Ym9yZGVyLWVtZXJhbGQtODAwXCI+XG4gICAgICAgICAgICB7Y29uZmlnLm1ldHJpY3MucmV2aWV3c0NvdW50fSBSZXZpZXdzXG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogVGVzdGltb25pYWwgQ2FyZHMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMTIgZ3JpZCBncmlkLWNvbHMtMSBtZDpncmlkLWNvbHMtMyBnYXAtNlwiPlxuICAgICAgICAgIHtjb25maWcudGVzdGltb25pYWxzLm1hcCgodCwgaWR4KSA9PiAoXG4gICAgICAgICAgICA8bW90aW9uLmRpdlxuICAgICAgICAgICAgICBrZXk9e3QuaWR9XG4gICAgICAgICAgICAgIGluaXRpYWw9e3sgb3BhY2l0eTogMCwgeTogMTUgfX1cbiAgICAgICAgICAgICAgd2hpbGVJblZpZXc9e3sgb3BhY2l0eTogMSwgeTogMCB9fVxuICAgICAgICAgICAgICB2aWV3cG9ydD17eyBvbmNlOiB0cnVlIH19XG4gICAgICAgICAgICAgIHRyYW5zaXRpb249e3sgZHVyYXRpb246IDAuNCwgZGVsYXk6IGlkeCAqIDAuMSB9fVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJnbGFzcy1jYXJkIHJvdW5kZWQtMnhsIHAtNiBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMC85MCBkYXJrOmJvcmRlci1zbGF0ZS04MDAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW4gcmVsYXRpdmVcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8UXVvdGUgY2xhc3NOYW1lPVwidy04IGgtOCB0ZXh0LXNreS01MDAvMjAgYWJzb2x1dGUgdG9wLTQgcmlnaHQtNFwiIC8+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTRcIj5cbiAgICAgICAgICAgICAgICB7LyogUmF0aW5nIFN0YXJzICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgICAgIHtbLi4uQXJyYXkodC5yYXRpbmcpXS5tYXAoKF8sIGkpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPFN0YXIga2V5PXtpfSBjbGFzc05hbWU9XCJ3LTQgaC00IGZpbGwtYW1iZXItNDAwIHRleHQtYW1iZXItNDAwXCIgLz5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyBzbTp0ZXh0LXNtIHRleHQtc2xhdGUtNjAwIGRhcms6dGV4dC1zbGF0ZS0zMDAgbGVhZGluZy1yZWxheGVkIGl0YWxpY1wiPlxuICAgICAgICAgICAgICAgICAgXCJ7dC5jb21tZW50fVwiXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgcHQtNCBib3JkZXItdCBib3JkZXItc2xhdGUtMTAwIGRhcms6Ym9yZGVyLXNsYXRlLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIGRhcms6dGV4dC13aGl0ZSBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgICB7dC5uYW1lfVxuICAgICAgICAgICAgICAgICAgICB7dC52ZXJpZmllZCAmJiA8c3BhbiB0aXRsZT1cIlZlcmlmaWVkIFBhdGllbnRcIj48Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctMy41IGgtMy41IHRleHQtc2t5LTUwMCBpbmxpbmVcIiAvPjwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICA8L2g0PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgYmxvY2tcIj57dC5yb2xlfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZCB0ZXh0LXRlYWwtNjAwIGRhcms6dGV4dC10ZWFsLTQwMCB0ZXh0LVsxMXB4XSBibG9ja1wiPnt0LnRyZWF0bWVudH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPnt0LmRhdGV9PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvbW90aW9uLmRpdj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuICAgIDwvc2VjdGlvbj5cbiAgKTtcbn07XG4iXX0=