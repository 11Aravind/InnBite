import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AppointmentModal.tsx");const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=383ccf5c";
import { motion, AnimatePresence } from "/node_modules/.vite/deps/framer-motion.js?v=d79d3615";
import confetti from "/node_modules/.vite/deps/canvas-confetti.js?v=f0872f4a";
import { X, Calendar, Clock, User, CheckCircle2, Building, Phone, Mail, MessageCircle, Sparkles, ArrowRight, ArrowLeft, Share2, Download } from "/node_modules/.vite/deps/lucide-react.js?v=a18529f7";
import { useTheme } from "/src/context/ThemeContext.tsx";
import { DynamicIcon } from "/src/components/DynamicIcon.tsx";
var _jsxFileName = "D:/Aravind-Works/Dentel clinic/src/components/AppointmentModal.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=383ccf5c";
var _s = $RefreshSig$();
export const AppointmentModal = ({ isOpen, onClose, initialServiceId, initialDoctorId }) => {
	_s();
	const { config } = useTheme();
	const [step, setStep] = useState(1);
	const [selectedService, setSelectedService] = useState(initialServiceId || config.services[0].id);
	const [selectedDoctor, setSelectedDoctor] = useState(initialDoctorId || config.doctors[0].id);
	const [selectedBranch, setSelectedBranch] = useState(config.contact.branches[0].name);
	const [selectedDate, setSelectedDate] = useState("2026-10-04");
	const [selectedTimeSlot, setSelectedTimeSlot] = useState("10:30 AM");
	const [patientDetails, setPatientDetails] = useState({
		name: "",
		phone: "",
		email: "",
		isFirstVisit: true,
		requestEmi: false,
		insurancePartner: "None"
	});
	const [isBooked, setIsBooked] = useState(false);
	const [bookingRef, setBookingRef] = useState("");
	useEffect(() => {
		if (initialServiceId) setSelectedService(initialServiceId);
		if (initialDoctorId) setSelectedDoctor(initialDoctorId);
	}, [initialServiceId, initialDoctorId]);
	if (!isOpen) return null;
	const timeSlots = {
		morning: [
			"09:30 AM",
			"10:30 AM",
			"11:15 AM",
			"11:45 AM"
		],
		afternoon: [
			"01:30 PM",
			"02:30 PM",
			"03:15 PM",
			"04:00 PM"
		],
		evening: [
			"05:00 PM",
			"06:00 PM",
			"07:00 PM",
			"07:30 PM"
		]
	};
	const handleBookingSubmit = (e) => {
		e.preventDefault();
		const refCode = `APX-${Math.floor(1e5 + Math.random() * 9e5)}`;
		setBookingRef(refCode);
		setIsBooked(true);
		try {
			confetti({
				particleCount: 120,
				spread: 80,
				origin: { y: .6 }
			});
		} catch (err) {
			console.log("Confetti effect triggered");
		}
	};
	const currentServiceObj = config.services.find((s) => s.id === selectedService) || config.services[0];
	const currentDoctorObj = config.doctors.find((d) => d.id === selectedDoctor) || config.doctors[0];
	const handleWhatsAppSend = () => {
		const text = `*ApexCare Dental Appointment Booking*\nRef: ${bookingRef}\nPatient: ${patientDetails.name}\nPhone: ${patientDetails.phone}\nService: ${currentServiceObj.title}\nDoctor: ${currentDoctorObj.name}\nDate & Time: ${selectedDate} at ${selectedTimeSlot}\nBranch: ${selectedBranch}`;
		window.open(`https://wa.me/${config.contact.whatsapp.number}?text=${encodeURIComponent(text)}`, "_blank");
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto",
		children: /* @__PURE__ */ _jsxDEV(motion.div, {
			initial: {
				opacity: 0,
				scale: .95,
				y: 10
			},
			animate: {
				opacity: 1,
				scale: 1,
				y: 0
			},
			exit: {
				opacity: 0,
				scale: .95,
				y: 10
			},
			className: "bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 max-w-2xl w-full shadow-2xl relative my-8",
			children: [/* @__PURE__ */ _jsxDEV("button", {
				onClick: onClose,
				className: "absolute top-5 right-5 p-2 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900",
				children: /* @__PURE__ */ _jsxDEV(X, { className: "w-5 h-5" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 104,
				columnNumber: 9
			}, this), !isBooked ? /* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-2 mb-6",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center gap-2 text-xs font-extrabold uppercase tracking-wider text-sky-600",
						children: [
							/* @__PURE__ */ _jsxDEV(Sparkles, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 116,
								columnNumber: 17
							}, this),
							"Step ",
							step,
							" of 4 • Online Booking Portal"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 115,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("h3", {
						className: "text-2xl font-black text-slate-900",
						children: [
							step === 1 && "Select Required Dental Treatment",
							step === 2 && "Select Specialist Doctor & Studio Branch",
							step === 3 && "Choose Consultation Date & Time Slot",
							step === 4 && "Enter Patient Contact Details"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 119,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 114,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "w-full bg-slate-100 h-2.5 rounded-full overflow-hidden mb-6",
					children: /* @__PURE__ */ _jsxDEV("div", {
						className: "bg-gradient-to-r from-sky-600 to-teal-600 h-full transition-all duration-300",
						style: { width: `${step / 4 * 100}%` }
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 129,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 128,
					columnNumber: 13
				}, this),
				step === 1 && /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-80 overflow-y-auto pr-1",
						children: config.services.map((svc) => /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => setSelectedService(svc.id),
							className: `p-4 rounded-2xl border text-left flex items-start gap-3 transition cursor-pointer ${selectedService === svc.id ? "border-sky-600 bg-sky-50 ring-2 ring-sky-500/20" : "border-slate-200 bg-white hover:border-sky-300"}`,
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-10 h-10 rounded-xl bg-sky-100 flex items-center justify-center text-sky-700 flex-shrink-0",
								children: /* @__PURE__ */ _jsxDEV(DynamicIcon, {
									name: svc.iconName,
									className: "w-5 h-5"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 151,
									columnNumber: 25
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 150,
								columnNumber: 23
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "font-extrabold text-xs text-slate-900",
									children: svc.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 154,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-[11px] text-slate-500 mt-0.5",
									children: svc.duration
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 155,
									columnNumber: 25
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-[11px] font-extrabold text-sky-700 mt-1",
									children: svc.priceRange
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 156,
									columnNumber: 25
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 23
							}, this)]
						}, svc.id, true, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 21
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 138,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex justify-end pt-4",
						children: /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setStep(2),
							className: "py-3.5 px-6 rounded-xl font-extrabold text-xs text-white bg-sky-600 hover:bg-sky-700 flex items-center gap-2 cursor-pointer shadow-md",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "Next: Select Specialist" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 167,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 168,
								columnNumber: 21
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 19
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 162,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 137,
					columnNumber: 15
				}, this),
				step === 2 && /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-extrabold uppercase tracking-wider text-slate-500 mb-2",
							children: "Choose Specialist Dental Surgeon:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 178,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-3 gap-3",
							children: config.doctors.map((doc) => /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setSelectedDoctor(doc.id),
								className: `p-3.5 rounded-2xl border text-center transition cursor-pointer ${selectedDoctor === doc.id ? "border-sky-600 bg-sky-50 ring-2 ring-sky-500/20" : "border-slate-200 bg-white hover:border-slate-300"}`,
								children: [
									/* @__PURE__ */ _jsxDEV("img", {
										src: doc.image,
										alt: doc.name,
										className: "w-14 h-14 rounded-full object-cover mx-auto mb-2 border border-slate-300 shadow-sm"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 193,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "font-extrabold text-xs text-slate-900 truncate",
										children: doc.name
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 194,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-[10px] text-slate-500 font-semibold truncate",
										children: doc.role.split("&")[0]
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 195,
										columnNumber: 25
									}, this)
								]
							}, doc.id, true, {
								fileName: _jsxFileName,
								lineNumber: 183,
								columnNumber: 23
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 181,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 177,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-extrabold uppercase tracking-wider text-slate-500 mb-2",
							children: "Select Studio Location:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
							children: config.contact.branches.map((b, i) => /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setSelectedBranch(b.name),
								className: `p-4 rounded-2xl border text-left text-xs font-semibold transition cursor-pointer ${selectedBranch === b.name ? "border-sky-600 bg-sky-50 font-bold text-sky-900 ring-2 ring-sky-500/20" : "border-slate-200 text-slate-700 hover:border-slate-300"}`,
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "font-extrabold text-slate-900",
									children: b.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 217,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "text-[11px] text-slate-500 font-normal",
									children: b.address
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 218,
									columnNumber: 25
								}, this)]
							}, i, true, {
								fileName: _jsxFileName,
								lineNumber: 207,
								columnNumber: 23
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 205,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 201,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-between pt-4",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setStep(1),
								className: "py-3.5 px-5 rounded-xl font-bold text-xs text-slate-700 border border-slate-300 flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 229,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Back" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 230,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 225,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setStep(3),
								className: "py-3.5 px-6 rounded-xl font-extrabold text-xs text-white bg-sky-600 hover:bg-sky-700 flex items-center gap-2 cursor-pointer shadow-md",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Next: Select Time Slot" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 236,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 237,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 232,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 224,
							columnNumber: 17
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 176,
					columnNumber: 15
				}, this),
				step === 3 && /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-6",
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-extrabold uppercase tracking-wider text-slate-500 mb-2",
							children: "Select Consultation Date:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 247,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "date",
							value: selectedDate,
							onChange: (e) => setSelectedDate(e.target.value),
							className: "w-full p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 font-extrabold text-sm outline-none focus:ring-2 focus:ring-sky-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 250,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 246,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-extrabold uppercase tracking-wider text-slate-500 mb-2",
							children: "Available Time Slots (Select One):"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 259,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] font-extrabold text-slate-400 uppercase",
									children: "Morning Sessions"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 265,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-4 gap-2 mt-1",
									children: timeSlots.morning.map((slot) => /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setSelectedTimeSlot(slot),
										className: `py-2.5 px-2 rounded-xl text-xs font-extrabold border transition cursor-pointer ${selectedTimeSlot === slot ? "bg-sky-600 text-white border-sky-600 shadow-md" : "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100"}`,
										children: slot
									}, slot, false, {
										fileName: _jsxFileName,
										lineNumber: 268,
										columnNumber: 27
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 266,
									columnNumber: 23
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 264,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] font-extrabold text-slate-400 uppercase",
									children: "Afternoon Sessions"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 285,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-4 gap-2 mt-1",
									children: timeSlots.afternoon.map((slot) => /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setSelectedTimeSlot(slot),
										className: `py-2.5 px-2 rounded-xl text-xs font-extrabold border transition cursor-pointer ${selectedTimeSlot === slot ? "bg-sky-600 text-white border-sky-600 shadow-md" : "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100"}`,
										children: slot
									}, slot, false, {
										fileName: _jsxFileName,
										lineNumber: 288,
										columnNumber: 27
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 286,
									columnNumber: 23
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 284,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] font-extrabold text-slate-400 uppercase",
									children: "Evening Sessions"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 305,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "grid grid-cols-4 gap-2 mt-1",
									children: timeSlots.evening.map((slot) => /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										onClick: () => setSelectedTimeSlot(slot),
										className: `py-2.5 px-2 rounded-xl text-xs font-extrabold border transition cursor-pointer ${selectedTimeSlot === slot ? "bg-sky-600 text-white border-sky-600 shadow-md" : "bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100"}`,
										children: slot
									}, slot, false, {
										fileName: _jsxFileName,
										lineNumber: 308,
										columnNumber: 27
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 306,
									columnNumber: 23
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 304,
									columnNumber: 21
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 263,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 258,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-between pt-4",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setStep(2),
								className: "py-3.5 px-5 rounded-xl font-bold text-xs text-slate-700 border border-slate-300 flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 331,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Back" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 332,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 327,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setStep(4),
								className: "py-3.5 px-6 rounded-xl font-extrabold text-xs text-white bg-sky-600 hover:bg-sky-700 flex items-center gap-2 cursor-pointer shadow-md",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: "Next: Patient Info" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 338,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV(ArrowRight, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 339,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 334,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 326,
							columnNumber: 17
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 245,
					columnNumber: 15
				}, this),
				step === 4 && /* @__PURE__ */ _jsxDEV("form", {
					onSubmit: handleBookingSubmit,
					className: "space-y-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-bold text-slate-700 mb-1",
								children: "Patient Full Name *"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 350,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								required: true,
								placeholder: "e.g. Meera Nair",
								value: patientDetails.name,
								onChange: (e) => setPatientDetails({
									...patientDetails,
									name: e.target.value
								}),
								className: "w-full p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold text-slate-900 outline-none focus:ring-2 focus:ring-sky-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 353,
								columnNumber: 21
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 349,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
								className: "block text-xs font-bold text-slate-700 mb-1",
								children: "Mobile Number (For WhatsApp Pass) *"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 364,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "tel",
								required: true,
								placeholder: "+91 98765 43210",
								value: patientDetails.phone,
								onChange: (e) => setPatientDetails({
									...patientDetails,
									phone: e.target.value
								}),
								className: "w-full p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold text-slate-900 outline-none focus:ring-2 focus:ring-sky-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 367,
								columnNumber: 21
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 363,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 348,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-bold text-slate-700 mb-1",
							children: "Email Address"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 379,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "email",
							placeholder: "meera@example.com",
							value: patientDetails.email,
							onChange: (e) => setPatientDetails({
								...patientDetails,
								email: e.target.value
							}),
							className: "w-full p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-bold text-slate-900 outline-none focus:ring-2 focus:ring-sky-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 382,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 378,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center gap-4 pt-2",
							children: /* @__PURE__ */ _jsxDEV("label", {
								className: "flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer",
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "checkbox",
									checked: patientDetails.requestEmi,
									onChange: (e) => setPatientDetails({
										...patientDetails,
										requestEmi: e.target.checked
									}),
									className: "rounded text-sky-600 focus:ring-sky-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 393,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Request 0% Interest EMI Consultation" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 399,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 392,
								columnNumber: 19
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 391,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-4 rounded-2xl bg-sky-50 border border-sky-200 space-y-2 text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "font-extrabold text-sky-900 flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "Summary:" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 406,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-[10px] text-emerald-700 font-extrabold bg-emerald-100 px-2 py-0.5 rounded border border-emerald-300",
										children: "Instant Slot Reserved"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 407,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 405,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-slate-800 font-bold",
									children: [
										currentServiceObj.title,
										" with ",
										currentDoctorObj.name
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 409,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-slate-600 font-medium",
									children: [
										"📅 ",
										selectedDate,
										" at ",
										selectedTimeSlot,
										" (",
										selectedBranch,
										")"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 412,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 404,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-between pt-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setStep(3),
								className: "py-3.5 px-5 rounded-xl font-bold text-xs text-slate-700 border border-slate-300 flex items-center gap-1.5",
								children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 423,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Back" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 424,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 418,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								className: "py-4 px-8 rounded-xl font-extrabold text-xs text-white bg-gradient-to-r from-sky-600 to-teal-600 hover:from-sky-700 hover:to-teal-700 shadow-xl flex items-center gap-2 cursor-pointer",
								children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-4 h-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 430,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Confirm & Generate Digital Pass" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 431,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 426,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 417,
							columnNumber: 17
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 347,
					columnNumber: 15
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 112,
				columnNumber: 11
			}, this) : 
			/* APPOINTMENT CONFIRMATION DIGITAL PASS */
			/* @__PURE__ */ _jsxDEV("div", {
				className: "text-center space-y-6 py-4",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-md",
						children: /* @__PURE__ */ _jsxDEV(CheckCircle2, { className: "w-8 h-8" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 441,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 440,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-1",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-extrabold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200",
								children: "Booking Confirmed!"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 445,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("h3", {
								className: "text-2xl font-black text-slate-900",
								children: "Your Appointment Pass Is Ready"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 448,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-500 font-medium",
								children: "A confirmation SMS & email have been dispatched to your contact number."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 451,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 444,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "p-6 rounded-3xl bg-gradient-to-br from-slate-900 to-slate-950 text-white text-left space-y-4 border border-slate-800 shadow-2xl relative overflow-hidden",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-between items-start border-b border-slate-800 pb-3",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "text-[10px] font-bold text-sky-400 uppercase tracking-widest",
								children: "ApexCare Dental Pass"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 460,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-lg font-extrabold text-white",
								children: currentServiceObj.title
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 461,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 459,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-right",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "text-[10px] text-slate-400",
									children: "Ref Code"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 464,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "text-xs font-mono font-bold text-amber-400",
									children: bookingRef
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 465,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 463,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 458,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-2 gap-4 text-xs",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400 text-[10px] block",
									children: "Patient Name"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 471,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("strong", {
									className: "text-white font-extrabold",
									children: patientDetails.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 472,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 470,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400 text-[10px] block",
									children: "Doctor Assigned"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 475,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("strong", {
									className: "text-white font-extrabold",
									children: currentDoctorObj.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 476,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 474,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400 text-[10px] block",
									children: "Date & Time"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 479,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("strong", {
									className: "text-emerald-400 font-extrabold",
									children: [
										selectedDate,
										" @ ",
										selectedTimeSlot
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 480,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 478,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400 text-[10px] block",
									children: "Studio Location"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 483,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("strong", {
									className: "text-white font-extrabold",
									children: selectedBranch
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 484,
									columnNumber: 19
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 482,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 469,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 457,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col sm:flex-row gap-3",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							onClick: handleWhatsAppSend,
							className: "flex-1 py-4 px-4 rounded-xl font-extrabold text-xs text-white bg-emerald-600 hover:bg-emerald-700 shadow-md flex items-center justify-center gap-2 cursor-pointer",
							children: [/* @__PURE__ */ _jsxDEV(MessageCircle, { className: "w-4 h-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 495,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Send Pass To WhatsApp" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 496,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 491,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: onClose,
							className: "py-4 px-6 rounded-xl font-bold text-xs text-slate-700 border border-slate-300 hover:bg-slate-100",
							children: "Close & Return"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 499,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 490,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 439,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 97,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 96,
		columnNumber: 5
	}, this);
};
_s(AppointmentModal, "pT2Axl+qLkBWsUO1D1bMtF2KUvE=", false, function() {
	return [useTheme];
});
_c = AppointmentModal;
var _c;
$RefreshReg$(_c, "AppointmentModal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/AppointmentModal.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Aravind-Works/Dentel clinic/src/components/AppointmentModal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Aravind-Works/Dentel clinic/src/components/AppointmentModal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Aravind-Works/Dentel clinic/src/components/AppointmentModal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsaUJBQWlCO0FBQzNDLFNBQVMsUUFBUSx1QkFBdUI7QUFDeEMsT0FBTyxjQUFjO0FBQ3JCLFNBQ0UsR0FDQSxVQUNBLE9BQ0EsTUFDQSxjQUNBLFVBQ0EsT0FDQSxNQUNBLGVBQ0EsVUFDQSxZQUNBLFdBQ0EsUUFDQSxnQkFDSztBQUNQLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsbUJBQW1COzs7O0FBUzVCLE9BQU8sTUFBTSxvQkFBcUQsRUFDaEUsUUFDQSxTQUNBLGtCQUNBLHNCQUNJOztDQUNKLE1BQU0sRUFBRSxXQUFXLFNBQVM7Q0FFNUIsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFpQixDQUFDO0NBQzFDLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQWlCLG9CQUFvQixPQUFPLFNBQVMsRUFBRSxDQUFDLEVBQUU7Q0FDeEcsTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBaUIsbUJBQW1CLE9BQU8sUUFBUSxFQUFFLENBQUMsRUFBRTtDQUNwRyxNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUFpQixPQUFPLFFBQVEsU0FBUyxFQUFFLENBQUMsSUFBSTtDQUM1RixNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBaUIsWUFBWTtDQUNyRSxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUFpQixVQUFVO0NBRTNFLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQVM7RUFDbkQsTUFBTTtFQUNOLE9BQU87RUFDUCxPQUFPO0VBQ1AsY0FBYztFQUNkLFlBQVk7RUFDWixrQkFBa0I7Q0FDcEIsQ0FBQztDQUVELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxLQUFLO0NBQzlDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEVBQUU7Q0FFL0MsZ0JBQWdCO0VBQ2QsSUFBSSxrQkFBa0IsbUJBQW1CLGdCQUFnQjtFQUN6RCxJQUFJLGlCQUFpQixrQkFBa0IsZUFBZTtDQUN4RCxHQUFHLENBQUMsa0JBQWtCLGVBQWUsQ0FBQztDQUV0QyxJQUFJLENBQUMsUUFBUSxPQUFPO0NBRXBCLE1BQU0sWUFBWTtFQUNoQixTQUFTO0dBQUM7R0FBWTtHQUFZO0dBQVk7RUFBVTtFQUN4RCxXQUFXO0dBQUM7R0FBWTtHQUFZO0dBQVk7RUFBVTtFQUMxRCxTQUFTO0dBQUM7R0FBWTtHQUFZO0dBQVk7RUFBVTtDQUMxRDtDQUVBLE1BQU0sdUJBQXVCLE1BQXVCO0VBQ2xELEVBQUUsZUFBZTtFQUNqQixNQUFNLFVBQVUsT0FBTyxLQUFLLE1BQU0sTUFBUyxLQUFLLE9BQU8sSUFBSSxHQUFNO0VBQ2pFLGNBQWMsT0FBTztFQUNyQixZQUFZLElBQUk7RUFFaEIsSUFBSTtHQUNGLFNBQVM7SUFDUCxlQUFlO0lBQ2YsUUFBUTtJQUNSLFFBQVEsRUFBRSxHQUFHLEdBQUk7R0FDbkIsQ0FBQztFQUNILFNBQVMsS0FBSztHQUNaLFFBQVEsSUFBSSwyQkFBMkI7RUFDekM7Q0FDRjtDQUVBLE1BQU0sb0JBQW9CLE9BQU8sU0FBUyxNQUFLLE1BQUssRUFBRSxPQUFPLGVBQWUsS0FBSyxPQUFPLFNBQVM7Q0FDakcsTUFBTSxtQkFBbUIsT0FBTyxRQUFRLE1BQUssTUFBSyxFQUFFLE9BQU8sY0FBYyxLQUFLLE9BQU8sUUFBUTtDQUU3RixNQUFNLDJCQUEyQjtFQUMvQixNQUFNLE9BQU8sK0NBQStDLFdBQVcsYUFBYSxlQUFlLEtBQUssV0FBVyxlQUFlLE1BQU0sYUFBYSxrQkFBa0IsTUFBTSxZQUFZLGlCQUFpQixLQUFLLGlCQUFpQixhQUFhLE1BQU0saUJBQWlCLFlBQVk7RUFDaFIsT0FBTyxLQUFLLGlCQUFpQixPQUFPLFFBQVEsU0FBUyxPQUFPLFFBQVEsbUJBQW1CLElBQUksS0FBSyxRQUFRO0NBQzFHO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE9BQU8sS0FBUjtHQUNFLFNBQVM7SUFBRSxTQUFTO0lBQUcsT0FBTztJQUFNLEdBQUc7R0FBRztHQUMxQyxTQUFTO0lBQUUsU0FBUztJQUFHLE9BQU87SUFBRyxHQUFHO0dBQUU7R0FDdEMsTUFBTTtJQUFFLFNBQVM7SUFBRyxPQUFPO0lBQU0sR0FBRztHQUFHO0dBQ3ZDLFdBQVU7YUFKWixDQU9FLHdCQUFDLFVBQUQ7SUFDRSxTQUFTO0lBQ1QsV0FBVTtjQUVWLHdCQUFDLEdBQUQsRUFBRyxXQUFVLFVBQVc7Ozs7O0dBQ2xCOzs7O2FBRVAsQ0FBQyxXQUNBLHdCQUFDLE9BQUQ7SUFFRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxVQUFELEVBQVUsV0FBVSxVQUFXOzs7OztPQUFDO09BQzFCO09BQUs7TUFDUjs7Ozs7ZUFDTCx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZDtPQUNHLFNBQVMsS0FBSztPQUNkLFNBQVMsS0FBSztPQUNkLFNBQVMsS0FBSztPQUNkLFNBQVMsS0FBSztNQUNiOzs7OzthQUNEOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLE9BQUQ7TUFDRSxXQUFVO01BQ1YsT0FBTyxFQUFFLE9BQU8sR0FBSSxPQUFPLElBQUssSUFBSSxHQUFHO0tBQ3hDOzs7OztJQUNFOzs7OztJQUdKLFNBQVMsS0FDUix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQ1osT0FBTyxTQUFTLEtBQUssUUFDcEIsd0JBQUMsVUFBRDtPQUVFLE1BQUs7T0FDTCxlQUFlLG1CQUFtQixJQUFJLEVBQUU7T0FDeEMsV0FBVyxxRkFDVCxvQkFBb0IsSUFBSSxLQUNwQixvREFDQTtpQkFQUixDQVVFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLGFBQUQ7U0FBYSxNQUFNLElBQUk7U0FBVSxXQUFVO1FBQVc7Ozs7O09BQ25EOzs7O2lCQUNMLHdCQUFDLE9BQUQ7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBeUMsSUFBSTtRQUFXOzs7OztRQUN2RSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBcUMsSUFBSTtRQUFjOzs7OztRQUN0RSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZ0QsSUFBSTtRQUFnQjs7Ozs7T0FDaEY7Ozs7ZUFDQztTQWpCRCxJQUFJOzs7O2FBaUJILENBQ1Q7S0FDRTs7OztlQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLFFBQVEsQ0FBQztPQUN4QixXQUFVO2lCQUZaLENBSUUsd0JBQUMsUUFBRCxZQUFNLDBCQUE2Qjs7OztpQkFDbkMsd0JBQUMsWUFBRCxFQUFZLFdBQVUsVUFBVzs7OztlQUMzQjs7Ozs7O0tBQ0w7Ozs7YUFDRjs7Ozs7O0lBSU4sU0FBUyxLQUNSLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQTRFO01BRXRGOzs7O2dCQUNQLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLE9BQU8sUUFBUSxLQUFLLFFBQ25CLHdCQUFDLFVBQUQ7UUFFRSxNQUFLO1FBQ0wsZUFBZSxrQkFBa0IsSUFBSSxFQUFFO1FBQ3ZDLFdBQVcsa0VBQ1QsbUJBQW1CLElBQUksS0FDbkIsb0RBQ0E7a0JBUFI7U0FVRSx3QkFBQyxPQUFEO1VBQUssS0FBSyxJQUFJO1VBQU8sS0FBSyxJQUFJO1VBQU0sV0FBVTtTQUFzRjs7Ozs7U0FDcEksd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWtELElBQUk7U0FBVTs7Ozs7U0FDL0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQXFELElBQUksS0FBSyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1NBQVE7Ozs7O1FBQzFGO1VBWkQsSUFBSTs7OztjQVlILENBQ1Q7TUFDRTs7OztjQUNGOzs7OztNQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO09BQU8sV0FBVTtpQkFBNEU7TUFFdEY7Ozs7Z0JBQ1Asd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1osT0FBTyxRQUFRLFNBQVMsS0FBSyxHQUFHLE1BQy9CLHdCQUFDLFVBQUQ7UUFFRSxNQUFLO1FBQ0wsZUFBZSxrQkFBa0IsRUFBRSxJQUFJO1FBQ3ZDLFdBQVcsb0ZBQ1QsbUJBQW1CLEVBQUUsT0FDakIsMkVBQ0E7a0JBUFIsQ0FVRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBaUMsRUFBRTtRQUFVOzs7O2tCQUM1RCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBMEMsRUFBRTtRQUFhOzs7O2dCQUNsRTtVQVhEOzs7O2NBV0MsQ0FDVDtNQUNFOzs7O2NBQ0Y7Ozs7O01BRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1FBQ0UsZUFBZSxRQUFRLENBQUM7UUFDeEIsV0FBVTtrQkFGWixDQUlFLHdCQUFDLFdBQUQsRUFBVyxXQUFVLFVBQVc7Ozs7a0JBQ2hDLHdCQUFDLFFBQUQsWUFBTSxPQUFVOzs7O2dCQUNWOzs7OztpQkFDUix3QkFBQyxVQUFEO1FBQ0UsZUFBZSxRQUFRLENBQUM7UUFDeEIsV0FBVTtrQkFGWixDQUlFLHdCQUFDLFFBQUQsWUFBTSx5QkFBNEI7Ozs7a0JBQ2xDLHdCQUFDLFlBQUQsRUFBWSxXQUFVLFVBQVc7Ozs7Z0JBQzNCOzs7OztlQUNMOzs7Ozs7S0FDRjs7Ozs7O0lBSU4sU0FBUyxLQUNSLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQTRFO01BRXRGOzs7O2dCQUNQLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsT0FBTztPQUNQLFdBQVcsTUFBTSxnQkFBZ0IsRUFBRSxPQUFPLEtBQUs7T0FDL0MsV0FBVTtNQUNYOzs7O2NBQ0U7Ozs7O01BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUE0RTtNQUV0Rjs7OztnQkFFUCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBc0Q7UUFBc0I7Ozs7a0JBQzVGLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaLFVBQVUsUUFBUSxLQUFJLFNBQ3JCLHdCQUFDLFVBQUQ7VUFFRSxNQUFLO1VBQ0wsZUFBZSxvQkFBb0IsSUFBSTtVQUN2QyxXQUFXLGtGQUNULHFCQUFxQixPQUNqQixtREFDQTtvQkFHTDtTQUNLLEdBVkQ7Ozs7Z0JBVUMsQ0FDVDtRQUNFOzs7O2dCQUNGOzs7OztRQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBc0Q7UUFBd0I7Ozs7a0JBQzlGLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaLFVBQVUsVUFBVSxLQUFJLFNBQ3ZCLHdCQUFDLFVBQUQ7VUFFRSxNQUFLO1VBQ0wsZUFBZSxvQkFBb0IsSUFBSTtVQUN2QyxXQUFXLGtGQUNULHFCQUFxQixPQUNqQixtREFDQTtvQkFHTDtTQUNLLEdBVkQ7Ozs7Z0JBVUMsQ0FDVDtRQUNFOzs7O2dCQUNGOzs7OztRQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBc0Q7UUFBc0I7Ozs7a0JBQzVGLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaLFVBQVUsUUFBUSxLQUFJLFNBQ3JCLHdCQUFDLFVBQUQ7VUFFRSxNQUFLO1VBQ0wsZUFBZSxvQkFBb0IsSUFBSTtVQUN2QyxXQUFXLGtGQUNULHFCQUFxQixPQUNqQixtREFDQTtvQkFHTDtTQUNLLEdBVkQ7Ozs7Z0JBVUMsQ0FDVDtRQUNFOzs7O2dCQUNGOzs7OztPQUNGOzs7OztjQUNGOzs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRDtRQUNFLGVBQWUsUUFBUSxDQUFDO1FBQ3hCLFdBQVU7a0JBRlosQ0FJRSx3QkFBQyxXQUFELEVBQVcsV0FBVSxVQUFXOzs7O2tCQUNoQyx3QkFBQyxRQUFELFlBQU0sT0FBVTs7OztnQkFDVjs7Ozs7aUJBQ1Isd0JBQUMsVUFBRDtRQUNFLGVBQWUsUUFBUSxDQUFDO1FBQ3hCLFdBQVU7a0JBRlosQ0FJRSx3QkFBQyxRQUFELFlBQU0scUJBQXdCOzs7O2tCQUM5Qix3QkFBQyxZQUFELEVBQVksV0FBVSxVQUFXOzs7O2dCQUMzQjs7Ozs7ZUFDTDs7Ozs7O0tBQ0Y7Ozs7OztJQUlOLFNBQVMsS0FDUix3QkFBQyxRQUFEO0tBQU0sVUFBVTtLQUFxQixXQUFVO2VBQS9DO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQThDO09BRXhEOzs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0w7UUFDQSxhQUFZO1FBQ1osT0FBTyxlQUFlO1FBQ3RCLFdBQVcsTUFBTSxrQkFBa0I7U0FBRSxHQUFHO1NBQWdCLE1BQU0sRUFBRSxPQUFPO1FBQU0sQ0FBQztRQUM5RSxXQUFVO09BQ1g7Ozs7ZUFDRTs7OztpQkFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQThDO09BRXhEOzs7O2lCQUNQLHdCQUFDLFNBQUQ7UUFDRSxNQUFLO1FBQ0w7UUFDQSxhQUFZO1FBQ1osT0FBTyxlQUFlO1FBQ3RCLFdBQVcsTUFBTSxrQkFBa0I7U0FBRSxHQUFHO1NBQWdCLE9BQU8sRUFBRSxPQUFPO1FBQU0sQ0FBQztRQUMvRSxXQUFVO09BQ1g7Ozs7ZUFDRTs7OztlQUNGOzs7Ozs7TUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQThDO01BRXhEOzs7O2dCQUNQLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsYUFBWTtPQUNaLE9BQU8sZUFBZTtPQUN0QixXQUFXLE1BQU0sa0JBQWtCO1FBQUUsR0FBRztRQUFnQixPQUFPLEVBQUUsT0FBTztPQUFNLENBQUM7T0FDL0UsV0FBVTtNQUNYOzs7O2NBQ0U7Ozs7O01BRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsU0FBRDtRQUFPLFdBQVU7a0JBQWpCLENBQ0Usd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxTQUFTLGVBQWU7U0FDeEIsV0FBVyxNQUFNLGtCQUFrQjtVQUFFLEdBQUc7VUFBZ0IsWUFBWSxFQUFFLE9BQU87U0FBUSxDQUFDO1NBQ3RGLFdBQVU7UUFDWDs7OztrQkFDRCx3QkFBQyxRQUFELFlBQU0sdUNBQTBDOzs7O2dCQUMzQzs7Ozs7O01BQ0o7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxXQUFjOzs7O21CQUNwQix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBMkc7U0FBMkI7Ozs7aUJBQ25KOzs7Ozs7UUFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNHLGtCQUFrQjtVQUFNO1VBQU8saUJBQWlCO1NBQzlDOzs7Ozs7UUFDTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUE0QztVQUN0QztVQUFhO1VBQUs7VUFBaUI7VUFBRztVQUFlO1NBQ3REOzs7Ozs7T0FDRjs7Ozs7O01BRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLGVBQWUsUUFBUSxDQUFDO1FBQ3hCLFdBQVU7a0JBSFosQ0FLRSx3QkFBQyxXQUFELEVBQVcsV0FBVSxVQUFXOzs7O2tCQUNoQyx3QkFBQyxRQUFELFlBQU0sT0FBVTs7OztnQkFDVjs7Ozs7aUJBQ1Isd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxXQUFVO2tCQUZaLENBSUUsd0JBQUMsY0FBRCxFQUFjLFdBQVUsVUFBVzs7OztrQkFDbkMsd0JBQUMsUUFBRCxZQUFNLGtDQUFxQzs7OztnQkFDckM7Ozs7O2VBQ0w7Ozs7OztLQUNEOzs7Ozs7R0FFTDs7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLGNBQUQsRUFBYyxXQUFVLFVBQVc7Ozs7O0tBQ2hDOzs7OztLQUVMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWtJO09BRTVJOzs7OztPQUNOLHdCQUFDLE1BQUQ7UUFBSSxXQUFVO2tCQUFxQztPQUUvQzs7Ozs7T0FDSix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBcUM7T0FFL0M7Ozs7O01BQ0E7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQStEO09BQXlCOzs7O2lCQUN2Ryx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBcUMsa0JBQWtCO09BQVc7Ozs7ZUFDOUU7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBNkI7UUFBYTs7OztrQkFDekQsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQThDO1FBQWdCOzs7O2dCQUMxRTs7Ozs7ZUFDRjs7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQW1DO1FBQWtCOzs7O2tCQUNyRSx3QkFBQyxVQUFEO1NBQVEsV0FBVTttQkFBNkIsZUFBZTtRQUFhOzs7O2dCQUN4RTs7Ozs7UUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQW1DO1FBQXFCOzs7O2tCQUN4RSx3QkFBQyxVQUFEO1NBQVEsV0FBVTttQkFBNkIsaUJBQWlCO1FBQWE7Ozs7Z0JBQzFFOzs7OztRQUNMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBbUM7UUFBaUI7Ozs7a0JBQ3BFLHdCQUFDLFVBQUQ7U0FBUSxXQUFVO21CQUFsQjtVQUFxRDtVQUFhO1VBQUk7U0FBeUI7Ozs7O2dCQUM1Rjs7Ozs7UUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQW1DO1FBQXFCOzs7O2tCQUN4RSx3QkFBQyxVQUFEO1NBQVEsV0FBVTttQkFBNkI7UUFBdUI7Ozs7Z0JBQ25FOzs7OztPQUNGOzs7OztjQUNGOzs7Ozs7S0FHTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQ7T0FDRSxTQUFTO09BQ1QsV0FBVTtpQkFGWixDQUlFLHdCQUFDLGVBQUQsRUFBZSxXQUFVLFVBQVc7Ozs7aUJBQ3BDLHdCQUFDLFFBQUQsWUFBTSx3QkFBMkI7Ozs7ZUFDM0I7Ozs7O2dCQUVSLHdCQUFDLFVBQUQ7T0FDRSxTQUFTO09BQ1QsV0FBVTtpQkFDWDtNQUVPOzs7O2NBQ0w7Ozs7OztJQUNGOzs7OztXQUVHOzs7Ozs7Q0FDVDs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHBvaW50bWVudE1vZGFsLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IG1vdGlvbiwgQW5pbWF0ZVByZXNlbmNlIH0gZnJvbSAnZnJhbWVyLW1vdGlvbic7XG5pbXBvcnQgY29uZmV0dGkgZnJvbSAnY2FudmFzLWNvbmZldHRpJztcbmltcG9ydCB7IFxuICBYLCBcbiAgQ2FsZW5kYXIsIFxuICBDbG9jaywgXG4gIFVzZXIsIFxuICBDaGVja0NpcmNsZTIsIFxuICBCdWlsZGluZywgXG4gIFBob25lLCBcbiAgTWFpbCwgXG4gIE1lc3NhZ2VDaXJjbGUsIFxuICBTcGFya2xlcyxcbiAgQXJyb3dSaWdodCxcbiAgQXJyb3dMZWZ0LFxuICBTaGFyZTIsXG4gIERvd25sb2FkXG59IGZyb20gJ2x1Y2lkZS1yZWFjdCc7XG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gJ0AvY29udGV4dC9UaGVtZUNvbnRleHQnO1xuaW1wb3J0IHsgRHluYW1pY0ljb24gfSBmcm9tICdAL2NvbXBvbmVudHMvRHluYW1pY0ljb24nO1xuXG5pbnRlcmZhY2UgQXBwb2ludG1lbnRNb2RhbFByb3BzIHtcbiAgaXNPcGVuOiBib29sZWFuO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICBpbml0aWFsU2VydmljZUlkPzogc3RyaW5nO1xuICBpbml0aWFsRG9jdG9ySWQ/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBjb25zdCBBcHBvaW50bWVudE1vZGFsOiBSZWFjdC5GQzxBcHBvaW50bWVudE1vZGFsUHJvcHM+ID0gKHtcbiAgaXNPcGVuLFxuICBvbkNsb3NlLFxuICBpbml0aWFsU2VydmljZUlkLFxuICBpbml0aWFsRG9jdG9ySWRcbn0pID0+IHtcbiAgY29uc3QgeyBjb25maWcgfSA9IHVzZVRoZW1lKCk7XG5cbiAgY29uc3QgW3N0ZXAsIHNldFN0ZXBdID0gdXNlU3RhdGU8bnVtYmVyPigxKTtcbiAgY29uc3QgW3NlbGVjdGVkU2VydmljZSwgc2V0U2VsZWN0ZWRTZXJ2aWNlXSA9IHVzZVN0YXRlPHN0cmluZz4oaW5pdGlhbFNlcnZpY2VJZCB8fCBjb25maWcuc2VydmljZXNbMF0uaWQpO1xuICBjb25zdCBbc2VsZWN0ZWREb2N0b3IsIHNldFNlbGVjdGVkRG9jdG9yXSA9IHVzZVN0YXRlPHN0cmluZz4oaW5pdGlhbERvY3RvcklkIHx8IGNvbmZpZy5kb2N0b3JzWzBdLmlkKTtcbiAgY29uc3QgW3NlbGVjdGVkQnJhbmNoLCBzZXRTZWxlY3RlZEJyYW5jaF0gPSB1c2VTdGF0ZTxzdHJpbmc+KGNvbmZpZy5jb250YWN0LmJyYW5jaGVzWzBdLm5hbWUpO1xuICBjb25zdCBbc2VsZWN0ZWREYXRlLCBzZXRTZWxlY3RlZERhdGVdID0gdXNlU3RhdGU8c3RyaW5nPignMjAyNi0xMC0wNCcpO1xuICBjb25zdCBbc2VsZWN0ZWRUaW1lU2xvdCwgc2V0U2VsZWN0ZWRUaW1lU2xvdF0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcxMDozMCBBTScpO1xuICBcbiAgY29uc3QgW3BhdGllbnREZXRhaWxzLCBzZXRQYXRpZW50RGV0YWlsc10gPSB1c2VTdGF0ZSh7XG4gICAgbmFtZTogJycsXG4gICAgcGhvbmU6ICcnLFxuICAgIGVtYWlsOiAnJyxcbiAgICBpc0ZpcnN0VmlzaXQ6IHRydWUsXG4gICAgcmVxdWVzdEVtaTogZmFsc2UsXG4gICAgaW5zdXJhbmNlUGFydG5lcjogJ05vbmUnXG4gIH0pO1xuXG4gIGNvbnN0IFtpc0Jvb2tlZCwgc2V0SXNCb29rZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbYm9va2luZ1JlZiwgc2V0Qm9va2luZ1JlZl0gPSB1c2VTdGF0ZSgnJyk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoaW5pdGlhbFNlcnZpY2VJZCkgc2V0U2VsZWN0ZWRTZXJ2aWNlKGluaXRpYWxTZXJ2aWNlSWQpO1xuICAgIGlmIChpbml0aWFsRG9jdG9ySWQpIHNldFNlbGVjdGVkRG9jdG9yKGluaXRpYWxEb2N0b3JJZCk7XG4gIH0sIFtpbml0aWFsU2VydmljZUlkLCBpbml0aWFsRG9jdG9ySWRdKTtcblxuICBpZiAoIWlzT3BlbikgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgdGltZVNsb3RzID0ge1xuICAgIG1vcm5pbmc6IFsnMDk6MzAgQU0nLCAnMTA6MzAgQU0nLCAnMTE6MTUgQU0nLCAnMTE6NDUgQU0nXSxcbiAgICBhZnRlcm5vb246IFsnMDE6MzAgUE0nLCAnMDI6MzAgUE0nLCAnMDM6MTUgUE0nLCAnMDQ6MDAgUE0nXSxcbiAgICBldmVuaW5nOiBbJzA1OjAwIFBNJywgJzA2OjAwIFBNJywgJzA3OjAwIFBNJywgJzA3OjMwIFBNJ11cbiAgfTtcblxuICBjb25zdCBoYW5kbGVCb29raW5nU3VibWl0ID0gKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBjb25zdCByZWZDb2RlID0gYEFQWC0ke01hdGguZmxvb3IoMTAwMDAwICsgTWF0aC5yYW5kb20oKSAqIDkwMDAwMCl9YDtcbiAgICBzZXRCb29raW5nUmVmKHJlZkNvZGUpO1xuICAgIHNldElzQm9va2VkKHRydWUpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbmZldHRpKHtcbiAgICAgICAgcGFydGljbGVDb3VudDogMTIwLFxuICAgICAgICBzcHJlYWQ6IDgwLFxuICAgICAgICBvcmlnaW46IHsgeTogMC42IH1cbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgY29uc29sZS5sb2coJ0NvbmZldHRpIGVmZmVjdCB0cmlnZ2VyZWQnKTtcbiAgICB9XG4gIH07XG5cbiAgY29uc3QgY3VycmVudFNlcnZpY2VPYmogPSBjb25maWcuc2VydmljZXMuZmluZChzID0+IHMuaWQgPT09IHNlbGVjdGVkU2VydmljZSkgfHwgY29uZmlnLnNlcnZpY2VzWzBdO1xuICBjb25zdCBjdXJyZW50RG9jdG9yT2JqID0gY29uZmlnLmRvY3RvcnMuZmluZChkID0+IGQuaWQgPT09IHNlbGVjdGVkRG9jdG9yKSB8fCBjb25maWcuZG9jdG9yc1swXTtcblxuICBjb25zdCBoYW5kbGVXaGF0c0FwcFNlbmQgPSAoKSA9PiB7XG4gICAgY29uc3QgdGV4dCA9IGAqQXBleENhcmUgRGVudGFsIEFwcG9pbnRtZW50IEJvb2tpbmcqXFxuUmVmOiAke2Jvb2tpbmdSZWZ9XFxuUGF0aWVudDogJHtwYXRpZW50RGV0YWlscy5uYW1lfVxcblBob25lOiAke3BhdGllbnREZXRhaWxzLnBob25lfVxcblNlcnZpY2U6ICR7Y3VycmVudFNlcnZpY2VPYmoudGl0bGV9XFxuRG9jdG9yOiAke2N1cnJlbnREb2N0b3JPYmoubmFtZX1cXG5EYXRlICYgVGltZTogJHtzZWxlY3RlZERhdGV9IGF0ICR7c2VsZWN0ZWRUaW1lU2xvdH1cXG5CcmFuY2g6ICR7c2VsZWN0ZWRCcmFuY2h9YDtcbiAgICB3aW5kb3cub3BlbihgaHR0cHM6Ly93YS5tZS8ke2NvbmZpZy5jb250YWN0LndoYXRzYXBwLm51bWJlcn0/dGV4dD0ke2VuY29kZVVSSUNvbXBvbmVudCh0ZXh0KX1gLCAnX2JsYW5rJyk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBwLTQgYmctc2xhdGUtOTAwLzYwIGJhY2tkcm9wLWJsdXItc20gb3ZlcmZsb3cteS1hdXRvXCI+XG4gICAgICA8bW90aW9uLmRpdlxuICAgICAgICBpbml0aWFsPXt7IG9wYWNpdHk6IDAsIHNjYWxlOiAwLjk1LCB5OiAxMCB9fVxuICAgICAgICBhbmltYXRlPXt7IG9wYWNpdHk6IDEsIHNjYWxlOiAxLCB5OiAwIH19XG4gICAgICAgIGV4aXQ9e3sgb3BhY2l0eTogMCwgc2NhbGU6IDAuOTUsIHk6IDEwIH19XG4gICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHJvdW5kZWQtM3hsIHAtNiBzbTpwLTggbWF4LXctMnhsIHctZnVsbCBzaGFkb3ctMnhsIHJlbGF0aXZlIG15LThcIlxuICAgICAgPlxuICAgICAgICB7LyogQ2xvc2UgTW9kYWwgQnV0dG9uICovfVxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtNSByaWdodC01IHAtMiByb3VuZGVkLWZ1bGwgYmctc2xhdGUtMTAwIHRleHQtc2xhdGUtNTAwIGhvdmVyOnRleHQtc2xhdGUtOTAwXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInctNSBoLTVcIiAvPlxuICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICB7IWlzQm9va2VkID8gKFxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICB7LyogTW9kYWwgU3RlcCBIZWFkZXIgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktMiBtYi02XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBmb250LWV4dHJhYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1za3ktNjAwXCI+XG4gICAgICAgICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgIFN0ZXAge3N0ZXB9IG9mIDQg4oCiIE9ubGluZSBCb29raW5nIFBvcnRhbFxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYmxhY2sgdGV4dC1zbGF0ZS05MDBcIj5cbiAgICAgICAgICAgICAgICB7c3RlcCA9PT0gMSAmJiBcIlNlbGVjdCBSZXF1aXJlZCBEZW50YWwgVHJlYXRtZW50XCJ9XG4gICAgICAgICAgICAgICAge3N0ZXAgPT09IDIgJiYgXCJTZWxlY3QgU3BlY2lhbGlzdCBEb2N0b3IgJiBTdHVkaW8gQnJhbmNoXCJ9XG4gICAgICAgICAgICAgICAge3N0ZXAgPT09IDMgJiYgXCJDaG9vc2UgQ29uc3VsdGF0aW9uIERhdGUgJiBUaW1lIFNsb3RcIn1cbiAgICAgICAgICAgICAgICB7c3RlcCA9PT0gNCAmJiBcIkVudGVyIFBhdGllbnQgQ29udGFjdCBEZXRhaWxzXCJ9XG4gICAgICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFN0ZXAgUHJvZ3Jlc3MgQmFyICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtMTAwIGgtMi41IHJvdW5kZWQtZnVsbCBvdmVyZmxvdy1oaWRkZW4gbWItNlwiPlxuICAgICAgICAgICAgICA8ZGl2IFxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWdyYWRpZW50LXRvLXIgZnJvbS1za3ktNjAwIHRvLXRlYWwtNjAwIGgtZnVsbCB0cmFuc2l0aW9uLWFsbCBkdXJhdGlvbi0zMDBcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBgJHsoc3RlcCAvIDQpICogMTAwfSVgIH19XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFNURVAgMTogU0VSVklDRSBTRUxFQ1RJT04gKi99XG4gICAgICAgICAgICB7c3RlcCA9PT0gMSAmJiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS00XCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC0zIG1heC1oLTgwIG92ZXJmbG93LXktYXV0byBwci0xXCI+XG4gICAgICAgICAgICAgICAgICB7Y29uZmlnLnNlcnZpY2VzLm1hcCgoc3ZjKSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBrZXk9e3N2Yy5pZH1cbiAgICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZFNlcnZpY2Uoc3ZjLmlkKX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTQgcm91bmRlZC0yeGwgYm9yZGVyIHRleHQtbGVmdCBmbGV4IGl0ZW1zLXN0YXJ0IGdhcC0zIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkU2VydmljZSA9PT0gc3ZjLmlkXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1za3ktNjAwIGJnLXNreS01MCByaW5nLTIgcmluZy1za3ktNTAwLzIwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdib3JkZXItc2xhdGUtMjAwIGJnLXdoaXRlIGhvdmVyOmJvcmRlci1za3ktMzAwJ1xuICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEwIGgtMTAgcm91bmRlZC14bCBiZy1za3ktMTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc2t5LTcwMCBmbGV4LXNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8RHluYW1pY0ljb24gbmFtZT17c3ZjLmljb25OYW1lfSBjbGFzc05hbWU9XCJ3LTUgaC01XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXhzIHRleHQtc2xhdGUtOTAwXCI+e3N2Yy50aXRsZX08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgbXQtMC41XCI+e3N2Yy5kdXJhdGlvbn08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gZm9udC1leHRyYWJvbGQgdGV4dC1za3ktNzAwIG10LTFcIj57c3ZjLnByaWNlUmFuZ2V9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1lbmQgcHQtNFwiPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTdGVwKDIpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweS0zLjUgcHgtNiByb3VuZGVkLXhsIGZvbnQtZXh0cmFib2xkIHRleHQteHMgdGV4dC13aGl0ZSBiZy1za3ktNjAwIGhvdmVyOmJnLXNreS03MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXIgc2hhZG93LW1kXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+TmV4dDogU2VsZWN0IFNwZWNpYWxpc3Q8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDxBcnJvd1JpZ2h0IGNsYXNzTmFtZT1cInctNCBoLTRcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgey8qIFNURVAgMjogRE9DVE9SICYgQlJBTkNIIFNFTEVDVElPTiAqL31cbiAgICAgICAgICAgIHtzdGVwID09PSAyICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTZcIj5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1leHRyYWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNTAwIG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgQ2hvb3NlIFNwZWNpYWxpc3QgRGVudGFsIFN1cmdlb246XG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0zIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIHtjb25maWcuZG9jdG9ycy5tYXAoKGRvYykgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17ZG9jLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTZWxlY3RlZERvY3Rvcihkb2MuaWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0zLjUgcm91bmRlZC0yeGwgYm9yZGVyIHRleHQtY2VudGVyIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWREb2N0b3IgPT09IGRvYy5pZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JvcmRlci1za3ktNjAwIGJnLXNreS01MCByaW5nLTIgcmluZy1za3ktNTAwLzIwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci1zbGF0ZS0yMDAgYmctd2hpdGUgaG92ZXI6Ym9yZGVyLXNsYXRlLTMwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtkb2MuaW1hZ2V9IGFsdD17ZG9jLm5hbWV9IGNsYXNzTmFtZT1cInctMTQgaC0xNCByb3VuZGVkLWZ1bGwgb2JqZWN0LWNvdmVyIG14LWF1dG8gbWItMiBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBzaGFkb3ctc21cIiAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXhzIHRleHQtc2xhdGUtOTAwIHRydW5jYXRlXCI+e2RvYy5uYW1lfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LXNlbWlib2xkIHRydW5jYXRlXCI+e2RvYy5yb2xlLnNwbGl0KCcmJylbMF19PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1leHRyYWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNTAwIG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgU2VsZWN0IFN0dWRpbyBMb2NhdGlvbjpcbiAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAge2NvbmZpZy5jb250YWN0LmJyYW5jaGVzLm1hcCgoYiwgaSkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRCcmFuY2goYi5uYW1lKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtNCByb3VuZGVkLTJ4bCBib3JkZXIgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1zZW1pYm9sZCB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkQnJhbmNoID09PSBiLm5hbWVcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdib3JkZXItc2t5LTYwMCBiZy1za3ktNTAgZm9udC1ib2xkIHRleHQtc2t5LTkwMCByaW5nLTIgcmluZy1za3ktNTAwLzIwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JvcmRlci1zbGF0ZS0yMDAgdGV4dC1zbGF0ZS03MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTMwMCdcbiAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS05MDBcIj57Yi5uYW1lfTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTUwMCBmb250LW5vcm1hbFwiPntiLmFkZHJlc3N9PC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHB0LTRcIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U3RlcCgxKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHktMy41IHB4LTUgcm91bmRlZC14bCBmb250LWJvbGQgdGV4dC14cyB0ZXh0LXNsYXRlLTcwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPEFycm93TGVmdCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+QmFjazwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTdGVwKDMpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweS0zLjUgcHgtNiByb3VuZGVkLXhsIGZvbnQtZXh0cmFib2xkIHRleHQteHMgdGV4dC13aGl0ZSBiZy1za3ktNjAwIGhvdmVyOmJnLXNreS03MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXIgc2hhZG93LW1kXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+TmV4dDogU2VsZWN0IFRpbWUgU2xvdDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPEFycm93UmlnaHQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApfVxuXG4gICAgICAgICAgICB7LyogU1RFUCAzOiBEQVRFICYgVElNRSBTTE9UICovfVxuICAgICAgICAgICAge3N0ZXAgPT09IDMgJiYgKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNlwiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWV4dHJhYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1zbGF0ZS01MDAgbWItMlwiPlxuICAgICAgICAgICAgICAgICAgICBTZWxlY3QgQ29uc3VsdGF0aW9uIERhdGU6XG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJkYXRlXCJcbiAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdGVkRGF0ZX1cbiAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTZWxlY3RlZERhdGUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zLjUgcm91bmRlZC14bCBiZy1zbGF0ZS01MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCB0ZXh0LXNsYXRlLTkwMCBmb250LWV4dHJhYm9sZCB0ZXh0LXNtIG91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1za3ktNTAwXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1leHRyYWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtc2xhdGUtNTAwIG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgQXZhaWxhYmxlIFRpbWUgU2xvdHMgKFNlbGVjdCBPbmUpOlxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2VcIj5Nb3JuaW5nIFNlc3Npb25zPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtNCBnYXAtMiBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7dGltZVNsb3RzLm1vcm5pbmcubWFwKHNsb3QgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtzbG90fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkVGltZVNsb3Qoc2xvdCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHktMi41IHB4LTIgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtZXh0cmFib2xkIGJvcmRlciB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZFRpbWVTbG90ID09PSBzbG90XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXNreS02MDAgdGV4dC13aGl0ZSBib3JkZXItc2t5LTYwMCBzaGFkb3ctbWQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTUwIGJvcmRlci1zbGF0ZS0yMDAgdGV4dC1zbGF0ZS03MDAgaG92ZXI6Ymctc2xhdGUtMTAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nsb3R9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1leHRyYWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlXCI+QWZ0ZXJub29uIFNlc3Npb25zPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtNCBnYXAtMiBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7dGltZVNsb3RzLmFmdGVybm9vbi5tYXAoc2xvdCA9PiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e3Nsb3R9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRUaW1lU2xvdChzbG90KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweS0yLjUgcHgtMiByb3VuZGVkLXhsIHRleHQteHMgZm9udC1leHRyYWJvbGQgYm9yZGVyIHRyYW5zaXRpb24gY3Vyc29yLXBvaW50ZXIgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNlbGVjdGVkVGltZVNsb3QgPT09IHNsb3RcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctc2t5LTYwMCB0ZXh0LXdoaXRlIGJvcmRlci1za3ktNjAwIHNoYWRvdy1tZCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtNTAgYm9yZGVyLXNsYXRlLTIwMCB0ZXh0LXNsYXRlLTcwMCBob3ZlcjpiZy1zbGF0ZS0xMDAnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2xvdH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWV4dHJhYm9sZCB0ZXh0LXNsYXRlLTQwMCB1cHBlcmNhc2VcIj5FdmVuaW5nIFNlc3Npb25zPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtNCBnYXAtMiBtdC0xXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7dGltZVNsb3RzLmV2ZW5pbmcubWFwKHNsb3QgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtzbG90fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkVGltZVNsb3Qoc2xvdCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHktMi41IHB4LTIgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtZXh0cmFib2xkIGJvcmRlciB0cmFuc2l0aW9uIGN1cnNvci1wb2ludGVyICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZFRpbWVTbG90ID09PSBzbG90XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXNreS02MDAgdGV4dC13aGl0ZSBib3JkZXItc2t5LTYwMCBzaGFkb3ctbWQnXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTUwIGJvcmRlci1zbGF0ZS0yMDAgdGV4dC1zbGF0ZS03MDAgaG92ZXI6Ymctc2xhdGUtMTAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nsb3R9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHB0LTRcIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U3RlcCgyKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHktMy41IHB4LTUgcm91bmRlZC14bCBmb250LWJvbGQgdGV4dC14cyB0ZXh0LXNsYXRlLTcwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41XCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPEFycm93TGVmdCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+QmFjazwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRTdGVwKDQpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweS0zLjUgcHgtNiByb3VuZGVkLXhsIGZvbnQtZXh0cmFib2xkIHRleHQteHMgdGV4dC13aGl0ZSBiZy1za3ktNjAwIGhvdmVyOmJnLXNreS03MDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXIgc2hhZG93LW1kXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+TmV4dDogUGF0aWVudCBJbmZvPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8QXJyb3dSaWdodCBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgIHsvKiBTVEVQIDQ6IFBBVElFTlQgQ09OVEFDVCAmIFNVQk1JVCAqL31cbiAgICAgICAgICAgIHtzdGVwID09PSA0ICYmIChcbiAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUJvb2tpbmdTdWJtaXR9IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtNFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNzAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICBQYXRpZW50IEZ1bGwgTmFtZSAqXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiZS5nLiBNZWVyYSBOYWlyXCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGF0aWVudERldGFpbHMubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFBhdGllbnREZXRhaWxzKHsgLi4ucGF0aWVudERldGFpbHMsIG5hbWU6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBwLTMuNSByb3VuZGVkLXhsIGJnLXNsYXRlLTUwIGJvcmRlciBib3JkZXItc2xhdGUtMjAwIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtOTAwIG91dGxpbmUtbm9uZSBmb2N1czpyaW5nLTIgZm9jdXM6cmluZy1za3ktNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAgIE1vYmlsZSBOdW1iZXIgKEZvciBXaGF0c0FwcCBQYXNzKSAqXG4gICAgICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZWxcIlxuICAgICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCIrOTEgOTg3NjUgNDMyMTBcIlxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwYXRpZW50RGV0YWlscy5waG9uZX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFBhdGllbnREZXRhaWxzKHsgLi4ucGF0aWVudERldGFpbHMsIHBob25lOiBlLnRhcmdldC52YWx1ZSB9KX1cbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zLjUgcm91bmRlZC14bCBiZy1zbGF0ZS01MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctc2t5LTUwMFwiXG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS03MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICBFbWFpbCBBZGRyZXNzXG4gICAgICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJlbWFpbFwiXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwibWVlcmFAZXhhbXBsZS5jb21cIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17cGF0aWVudERldGFpbHMuZW1haWx9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGF0aWVudERldGFpbHMoeyAuLi5wYXRpZW50RGV0YWlscywgZW1haWw6IGUudGFyZ2V0LnZhbHVlIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zLjUgcm91bmRlZC14bCBiZy1zbGF0ZS01MCBib3JkZXIgYm9yZGVyLXNsYXRlLTIwMCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTkwMCBvdXRsaW5lLW5vbmUgZm9jdXM6cmluZy0yIGZvY3VzOnJpbmctc2t5LTUwMFwiXG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNCBwdC0yXCI+XG4gICAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgdGV4dC14cyBmb250LXNlbWlib2xkIHRleHQtc2xhdGUtNzAwIGN1cnNvci1wb2ludGVyXCI+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17cGF0aWVudERldGFpbHMucmVxdWVzdEVtaX1cbiAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFBhdGllbnREZXRhaWxzKHsgLi4ucGF0aWVudERldGFpbHMsIHJlcXVlc3RFbWk6IGUudGFyZ2V0LmNoZWNrZWQgfSl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZCB0ZXh0LXNreS02MDAgZm9jdXM6cmluZy1za3ktNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+UmVxdWVzdCAwJSBJbnRlcmVzdCBFTUkgQ29uc3VsdGF0aW9uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBCb29raW5nIFN1bW1hcnkgQm94ICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IHJvdW5kZWQtMnhsIGJnLXNreS01MCBib3JkZXIgYm9yZGVyLXNreS0yMDAgc3BhY2UteS0yIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1za3ktOTAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5TdW1tYXJ5Ojwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1lbWVyYWxkLTcwMCBmb250LWV4dHJhYm9sZCBiZy1lbWVyYWxkLTEwMCBweC0yIHB5LTAuNSByb3VuZGVkIGJvcmRlciBib3JkZXItZW1lcmFsZC0zMDBcIj5JbnN0YW50IFNsb3QgUmVzZXJ2ZWQ8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS04MDAgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgIHtjdXJyZW50U2VydmljZU9iai50aXRsZX0gd2l0aCB7Y3VycmVudERvY3Rvck9iai5uYW1lfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNjAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgICAgIPCfk4Uge3NlbGVjdGVkRGF0ZX0gYXQge3NlbGVjdGVkVGltZVNsb3R9ICh7c2VsZWN0ZWRCcmFuY2h9KVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHB0LTJcIj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFN0ZXAoMyl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB5LTMuNSBweC01IHJvdW5kZWQteGwgZm9udC1ib2xkIHRleHQteHMgdGV4dC1zbGF0ZS03MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS0zMDAgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxBcnJvd0xlZnQgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkJhY2s8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB5LTQgcHgtOCByb3VuZGVkLXhsIGZvbnQtZXh0cmFib2xkIHRleHQteHMgdGV4dC13aGl0ZSBiZy1ncmFkaWVudC10by1yIGZyb20tc2t5LTYwMCB0by10ZWFsLTYwMCBob3Zlcjpmcm9tLXNreS03MDAgaG92ZXI6dG8tdGVhbC03MDAgc2hhZG93LXhsIGZsZXggaXRlbXMtY2VudGVyIGdhcC0yIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPENoZWNrQ2lyY2xlMiBjbGFzc05hbWU9XCJ3LTQgaC00XCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+Q29uZmlybSAmIEdlbmVyYXRlIERpZ2l0YWwgUGFzczwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApIDogKFxuICAgICAgICAgIC8qIEFQUE9JTlRNRU5UIENPTkZJUk1BVElPTiBESUdJVEFMIFBBU1MgKi9cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIHNwYWNlLXktNiBweS00XCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTYgaC0xNiByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC0xMDAgdGV4dC1lbWVyYWxkLTYwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBteC1hdXRvIHNoYWRvdy1tZFwiPlxuICAgICAgICAgICAgICA8Q2hlY2tDaXJjbGUyIGNsYXNzTmFtZT1cInctOCBoLThcIiAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0xXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1leHRyYWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyIHRleHQtZW1lcmFsZC03MDAgYmctZW1lcmFsZC01MCBweC0zIHB5LTEgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItZW1lcmFsZC0yMDBcIj5cbiAgICAgICAgICAgICAgICBCb29raW5nIENvbmZpcm1lZCFcbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ibGFjayB0ZXh0LXNsYXRlLTkwMFwiPlxuICAgICAgICAgICAgICAgIFlvdXIgQXBwb2ludG1lbnQgUGFzcyBJcyBSZWFkeVxuICAgICAgICAgICAgICA8L2gzPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgICAgQSBjb25maXJtYXRpb24gU01TICYgZW1haWwgaGF2ZSBiZWVuIGRpc3BhdGNoZWQgdG8geW91ciBjb250YWN0IG51bWJlci5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBPZmZpY2lhbCBEaWdpdGFsIFBhc3MgQ2FyZCAtIENsZWFuIFdoaXRlIFN0dWRpbyBUaWNrZXQgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNiByb3VuZGVkLTN4bCBiZy1ncmFkaWVudC10by1iciBmcm9tLXNsYXRlLTkwMCB0by1zbGF0ZS05NTAgdGV4dC13aGl0ZSB0ZXh0LWxlZnQgc3BhY2UteS00IGJvcmRlciBib3JkZXItc2xhdGUtODAwIHNoYWRvdy0yeGwgcmVsYXRpdmUgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtc3RhcnQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwYi0zXCI+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2t5LTQwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXN0XCI+QXBleENhcmUgRGVudGFsIFBhc3M8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlXCI+e2N1cnJlbnRTZXJ2aWNlT2JqLnRpdGxlfTwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPlJlZiBDb2RlPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTQwMFwiPntib29raW5nUmVmfTwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTQgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LVsxMHB4XSBibG9ja1wiPlBhdGllbnQgTmFtZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LWV4dHJhYm9sZFwiPntwYXRpZW50RGV0YWlscy5uYW1lfTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LVsxMHB4XSBibG9ja1wiPkRvY3RvciBBc3NpZ25lZDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LWV4dHJhYm9sZFwiPntjdXJyZW50RG9jdG9yT2JqLm5hbWV9PC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQtWzEwcHhdIGJsb2NrXCI+RGF0ZSAmIFRpbWU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC00MDAgZm9udC1leHRyYWJvbGRcIj57c2VsZWN0ZWREYXRlfSBAIHtzZWxlY3RlZFRpbWVTbG90fTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LVsxMHB4XSBibG9ja1wiPlN0dWRpbyBMb2NhdGlvbjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzdHJvbmcgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBmb250LWV4dHJhYm9sZFwiPntzZWxlY3RlZEJyYW5jaH08L3N0cm9uZz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEFjdGlvbiBidXR0b25zICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGdhcC0zXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVXaGF0c0FwcFNlbmR9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB5LTQgcHgtNCByb3VuZGVkLXhsIGZvbnQtZXh0cmFib2xkIHRleHQteHMgdGV4dC13aGl0ZSBiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTcwMCBzaGFkb3ctbWQgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTIgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPE1lc3NhZ2VDaXJjbGUgY2xhc3NOYW1lPVwidy00IGgtNFwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+U2VuZCBQYXNzIFRvIFdoYXRzQXBwPC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweS00IHB4LTYgcm91bmRlZC14bCBmb250LWJvbGQgdGV4dC14cyB0ZXh0LXNsYXRlLTcwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTMwMCBob3ZlcjpiZy1zbGF0ZS0xMDBcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgQ2xvc2UgJiBSZXR1cm5cbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvbW90aW9uLmRpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=