import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/DynamicIcon.tsx");const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=383ccf5c";
import * as LucideIcons from "/node_modules/.vite/deps/lucide-react.js?v=a18529f7";
var _jsxFileName = "D:/Aravind-Works/Dentel clinic/src/components/DynamicIcon.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=383ccf5c";
export const DynamicIcon = ({ name, className = "w-5 h-5", size }) => {
	const IconComponent = LucideIcons[name] || LucideIcons.Sparkles;
	return /* @__PURE__ */ _jsxDEV(IconComponent, {
		className,
		size
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 10
	}, this);
};
_c = DynamicIcon;
var _c;
$RefreshReg$(_c, "DynamicIcon");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/DynamicIcon.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("D:/Aravind-Works/Dentel clinic/src/components/DynamicIcon.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("D:/Aravind-Works/Dentel clinic/src/components/DynamicIcon.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "D:/Aravind-Works/Dentel clinic/src/components/DynamicIcon.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFlBQVksaUJBQWlCOzs7QUFRN0IsT0FBTyxNQUFNLGVBQTJDLEVBQUUsTUFBTSxZQUFZLFdBQVcsV0FBVztDQUNoRyxNQUFNLGdCQUFpQixZQUE2RCxTQUFTLFlBQVk7Q0FFekcsT0FBTyx3QkFBQyxlQUFEO0VBQTBCO0VBQWlCO0NBQU87Ozs7O0FBQzNEIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkR5bmFtaWNJY29uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0ICogYXMgTHVjaWRlSWNvbnMgZnJvbSAnbHVjaWRlLXJlYWN0JztcblxuaW50ZXJmYWNlIER5bmFtaWNJY29uUHJvcHMge1xuICBuYW1lOiBzdHJpbmc7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgc2l6ZT86IG51bWJlcjtcbn1cblxuZXhwb3J0IGNvbnN0IER5bmFtaWNJY29uOiBSZWFjdC5GQzxEeW5hbWljSWNvblByb3BzPiA9ICh7IG5hbWUsIGNsYXNzTmFtZSA9IFwidy01IGgtNVwiLCBzaXplIH0pID0+IHtcbiAgY29uc3QgSWNvbkNvbXBvbmVudCA9IChMdWNpZGVJY29ucyBhcyB1bmtub3duIGFzIFJlY29yZDxzdHJpbmcsIFJlYWN0LkVsZW1lbnRUeXBlPilbbmFtZV0gfHwgTHVjaWRlSWNvbnMuU3BhcmtsZXM7XG5cbiAgcmV0dXJuIDxJY29uQ29tcG9uZW50IGNsYXNzTmFtZT17Y2xhc3NOYW1lfSBzaXplPXtzaXplfSAvPjtcbn07XG4iXX0=